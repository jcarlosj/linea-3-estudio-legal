<?php
/**
 * Linea 3 Estudio Legal Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package linea3-legal-child
 * @since 1.0.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

/**
 * Enqueue theme scripts and styles.
 */
function linea3_legal_child_enqueue_styles(): void
{
	$version = '1.5.0'; // Versión de Estabilización y Diseño Editorial

	wp_enqueue_style(
		'l3-font-awesome',
		'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
		array(),
		'6.4.0'
	);

	wp_enqueue_style(
		'linea3-legal-child-style',
		get_stylesheet_uri(),
		array(),
		filemtime(get_stylesheet_directory() . '/style.css')
	);

	wp_enqueue_script(
		'linea3-legal-child-search',
		get_stylesheet_directory_uri() . '/assets/js/search-toggle.js',
		array(),
		filemtime(get_stylesheet_directory() . '/assets/js/search-toggle.js'),
		true
	);

	wp_enqueue_script(
		'antigravity-modal-strategic',
		get_stylesheet_directory_uri() . '/assets/js/modal-strategic.js',
		array(),
		filemtime(get_stylesheet_directory() . '/assets/js/modal-strategic.js'),
		true
	);
}
add_action('wp_enqueue_scripts', 'linea3_legal_child_enqueue_styles');

/**
 * Perform theme setup.
 */
function linea3_legal_child_setup(): void
{
	add_theme_support('editor-styles');
	add_editor_style('style.css');
	add_theme_support('post-thumbnails');

	// Tamaños de imagen personalizados - Estética Editorial Linea 3
	add_image_size('l3-team-portrait', 800, 1000, true); // Para grilla de equipo y perfil
	add_image_size('l3-author-square', 500, 500, true); // Para tarjetas de autor pequeñas
	add_image_size('l3-blog-cover', 1200, 800, true);  // Para cabecera de artículos
	add_image_size('l3-blog-card', 600, 400, true);    // Para grillas de blog y destacados
	add_image_size('l3-ally-logo', 400, 0, false);     // Para logos de aliados (proporcional)
}
add_action('after_setup_theme', 'linea3_legal_child_setup');

/**
 * Shortcode para Copyright Dinámico
 * Uso: [l3_copyright]
 */
function l3_copyright_shortcode() {
    $start_year = 2026;
    $current_year = date('Y');
    $year_display = ($start_year == $current_year) ? $start_year : $start_year . ' – ' . $current_year;
    
    return '<span class="copyright-part">Línea 3 Estudio Legal © ' . $year_display . '</span>' . 
           '<span class="credits-divider"> | </span>' . 
           '<span class="made-with-part">Hecho con <span class="heart-icon">&#x2764;&#xFE0F;</span> y las manitas</span>';
}
add_shortcode('l3_copyright', 'l3_copyright_shortcode');

/**
 * ==========================================================================
 * GESTIÓN CENTRALIZADA DE INFORMACIÓN CORPORATIVA
 * ==========================================================================
 */

// 1. Crear la página de ajustes
add_action('admin_menu', 'l3_info_menu');
function l3_info_menu() {
    add_options_page(
        'Info. General', 
        'Info. General', 
        'manage_options', 
        'l3_info_settings_page', 
        'l3_info_page_render'
    );
}

// Forzar que aparezca de primero en el submenú de Ajustes
add_action('admin_menu', 'l3_reorder_settings_menu', 999);
function l3_reorder_settings_menu() {
    global $submenu;
    if (isset($submenu['options-general.php'])) {
        $l3_menu = null;
        foreach ($submenu['options-general.php'] as $key => $item) {
            if ($item[2] === 'l3_info_settings_page') {
                $l3_menu = $submenu['options-general.php'][$key];
                unset($submenu['options-general.php'][$key]);
                break;
            }
        }
        if ($l3_menu) {
            array_unshift($submenu['options-general.php'], $l3_menu);
        }
    }
}

// 2. Registrar los ajustes y campos
add_action('admin_init', 'l3_info_init');
function l3_info_init() {
    // Definición de campos y sus visibilidades
    $fields = [
        'l3_info_foto_sede', // Nueva Foto de Sede
        'l3_info_lugar', 'l3_info_direccion', 'l3_info_ciudad',
        'l3_info_telefono', 'l3_info_movil', 'l3_info_email', 'l3_info_horario',
        'l3_info_linkedin', 'l3_info_instagram', 'l3_info_facebook'
    ];

    foreach ($fields as $field) {
        if ($field === 'l3_info_foto_sede') {
            register_setting('l3_options_group', $field . '_id'); // Guardamos el ID
        } else {
            register_setting('l3_options_group', $field);
            register_setting('l3_options_group', $field . '_vis');
        }
    }

    // Registro de Ajustes de API de LinkedIn (Etapa 1 - Clientes)
    register_setting('l3_options_group', 'l3_linkedin_client_id');
    register_setting('l3_options_group', 'l3_linkedin_client_secret');
    
    // Registro de Ajustes de API de LinkedIn (Etapa 3 - Empresa/Organización)
    register_setting('l3_options_group', 'l3_linkedin_org_client_id');
    register_setting('l3_options_group', 'l3_linkedin_org_client_secret');
    register_setting('l3_options_group', 'l3_linkedin_org_id');
    register_setting('l3_options_group', 'l3_linkedin_org_token');

    add_settings_section('l3_location_section', 'Ubicación Física', null, 'l3_info_settings_page');
    add_settings_section('l3_contact_section', 'Datos de Contacto y Horarios', null, 'l3_info_settings_page');
    add_settings_section('l3_social_section', 'Redes Sociales Corporativas', null, 'l3_info_settings_page');

    // Campos Ubicación
    add_settings_field('field_foto_sede', 'Foto de la Sede', 'l3_render_foto_sede', 'l3_info_settings_page', 'l3_location_section');
    add_settings_field('field_lugar', 'Nombre del Lugar / Edificio', 'l3_render_lugar', 'l3_info_settings_page', 'l3_location_section');
    add_settings_field('field_direccion', 'Dirección Física', 'l3_render_direccion', 'l3_info_settings_page', 'l3_location_section');
    add_settings_field('field_ciudad', 'Ciudad', 'l3_render_ciudad', 'l3_info_settings_page', 'l3_location_section');
    
    // Campos Contacto
    add_settings_field('field_telefono', 'Teléfono Fijo', 'l3_render_telefono', 'l3_info_settings_page', 'l3_contact_section');
    add_settings_field('field_movil', 'Teléfono Móvil', 'l3_render_movil', 'l3_info_settings_page', 'l3_contact_section');
    add_settings_field('field_email', 'Correo Electrónico', 'l3_render_email', 'l3_info_settings_page', 'l3_contact_section');
    add_settings_field('field_horario', 'Horario de Atención', 'l3_render_horario', 'l3_info_settings_page', 'l3_contact_section');

    // Campos Redes Sociales
    add_settings_field('field_linkedin', 'LinkedIn (Perfil Empresarial)', 'l3_render_linkedin', 'l3_info_settings_page', 'l3_social_section');
    add_settings_field('field_instagram', 'Instagram', 'l3_render_instagram', 'l3_info_settings_page', 'l3_social_section');
    add_settings_field('field_facebook', 'Facebook', 'l3_render_facebook', 'l3_info_settings_page', 'l3_social_section');

    // Sección y Campos de API de LinkedIn (App Principal)
    add_settings_section('l3_linkedin_api_section', 'Integración de API de LinkedIn (App Principal para Login de Usuarios)', null, 'l3_info_settings_page');
    add_settings_field('field_linkedin_client_id', 'Client ID (App de Login de Usuarios)', 'l3_render_linkedin_client_id', 'l3_info_settings_page', 'l3_linkedin_api_section');
    add_settings_field('field_linkedin_client_secret', 'Client Secret (App de Login de Usuarios)', 'l3_render_linkedin_client_secret', 'l3_info_settings_page', 'l3_linkedin_api_section');
    
    // Sección y Campos de API de LinkedIn (App Secundaria)
    add_settings_section('l3_linkedin_org_api_section', 'Integración de API de LinkedIn (App Secundaria para Página de Empresa)', null, 'l3_info_settings_page');
    add_settings_field('field_linkedin_org_client_id', 'Client ID (App Secundaria para Empresa)', 'l3_render_linkedin_org_client_id', 'l3_info_settings_page', 'l3_linkedin_org_api_section');
    add_settings_field('field_linkedin_org_client_secret', 'Client Secret (App Secundaria para Empresa)', 'l3_render_linkedin_org_client_secret', 'l3_info_settings_page', 'l3_linkedin_org_api_section');
    add_settings_field('field_linkedin_org_id', 'ID de Página de LinkedIn (Organización)', 'l3_render_linkedin_org_id', 'l3_info_settings_page', 'l3_linkedin_org_api_section');
    add_settings_field('field_linkedin_org_token', 'Token de Organización de Larga Duración', 'l3_render_linkedin_org_token', 'l3_info_settings_page', 'l3_linkedin_org_api_section');
}

function l3_render_switch($id, $label = 'Mostrar:') {
    $checked = get_option($id . '_vis') ? 'checked' : '';
    return '<div style="display:inline-block; vertical-align:middle; margin-left:20px;">
                <span style="font-size:12px; color:#666; margin-right:8px;">' . esc_html($label) . '</span>
                <label class="l3-switch">
                    <input type="checkbox" name="' . $id . '_vis" value="1" ' . $checked . '>
                    <span class="l3-slider"></span>
                </label>
            </div>';
}

function l3_render_foto_sede() {
    $id = get_option('l3_info_foto_sede_id');
    $url = wp_get_attachment_image_url($id, 'medium');
    ?>
    <div class="l3-image-preview-wrapper">
        <img id="l3-foto-sede-preview" src="<?php echo esc_url($url); ?>" style="max-width: 250px; display: <?php echo $url ? 'block' : 'none'; ?>; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
        <input type="hidden" name="l3_info_foto_sede_id" id="l3_info_foto_sede_id" value="<?php echo esc_attr($id); ?>">
        <div class="l3-actions" style="display: flex; gap: 10px;">
            <button type="button" class="button l3-upload-button" id="l3_upload_foto_btn">Seleccionar Imagen</button>
            <a href="<?php echo $id ? admin_url('post.php?post=' . $id . '&action=edit') : '#'; ?>" 
               id="l3_edit_foto_btn" 
               class="button" 
               target="_blank" 
               style="<?php echo !$id ? 'display:none;' : ''; ?>">Ajustar Recorte / Editar</a>
            <button type="button" class="button l3-remove-button" id="l3_remove_foto_btn" style="<?php echo !$id ? 'display:none;' : ''; ?>; color: #a00;">Eliminar</button>
        </div>
    </div>
    <p class="description">Selecciona una imagen y usa "Ajustar Recorte" si quieres elegir manualmente qué parte de la foto se muestra.</p>
    
    <script>
    jQuery(document).ready(function($){
        var frame;
        $('#l3_upload_foto_btn').on('click', function(e) {
            e.preventDefault();
            if (frame) { frame.open(); return; }
            frame = wp.media({ title: 'Seleccionar Foto de la Sede', button: { text: 'Usar esta imagen' }, multiple: false });
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                $('#l3_info_foto_sede_id').val(attachment.id);
                $('#l3-foto-sede-preview').attr('src', attachment.url).show();
                $('#l3_edit_foto_btn').attr('href', '<?php echo admin_url('post.php?post='); ?>' + attachment.id + '&action=edit').show();
                $('#l3_remove_foto_btn').show();
            });
            frame.open();
        });
        $('#l3_remove_foto_btn').on('click', function() {
            $('#l3_info_foto_sede_id').val('');
            $('#l3-foto-sede-preview').hide();
            $('#l3_edit_foto_btn').hide();
            $(this).hide();
        });
    });
    </script>
    <?php
}

function l3_render_lugar() { 
    $val = get_option('l3_info_lugar'); 
    echo '<input type="text" name="l3_info_lugar" value="' . esc_attr($val) . '" placeholder="Ej: Edificio Platinum..." class="regular-text">';
    echo l3_render_switch('l3_info_lugar');
}
function l3_render_direccion() { 
    $val = get_option('l3_info_direccion'); 
    echo '<div style="display:flex; align-items:center; gap:20px;">';
    echo '<textarea name="l3_info_direccion" id="l3_info_direccion_field" rows="2" placeholder="Ej: Calle 100 # 15-20" class="regular-text">' . esc_textarea($val) . '</textarea>'; 
    echo l3_render_switch('l3_info_direccion');
    echo '</div>';
    echo '<p id="l3_address_status" style="margin-top:5px; font-weight:600; display:none;"></p>';
    echo '<p class="description">Independientemente de la visibilidad, el dato registrado aquí se utilizará para generar la ubicación en el <strong>Mapa de Google</strong>.</p>';
    ?>
    <script>
    jQuery(document).ready(function($){
        var timeout = null;
        
        function validateAddress() {
            clearTimeout(timeout);
            var address = $('#l3_info_direccion_field').val();
            var city = $('#l3_info_ciudad_field').val() || 'Bogotá, Colombia';
            var $status = $('#l3_address_status');
            
            if (address.length < 5) { $status.hide(); return; }

            timeout = setTimeout(function() {
                $.getJSON('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(address + ', ' + city), function(data) {
                    if (data.length > 0) {
                        $status.text('✓ Dirección localizada correctamente en ' + city).css('color', 'green').show();
                    } else {
                        $status.text('⚠ Aviso: Esta dirección podría no ser exacta en ' + city).css('color', '#dc3232').show();
                    }
                });
            }, 800);
        }

        $('#l3_info_direccion_field, #l3_info_ciudad_field').on('keyup change', function() {
            validateAddress();
        });
    });
    </script>
    <?php
}
function l3_render_ciudad() { 
    $val = get_option('l3_info_ciudad'); 
    echo '<input type="text" name="l3_info_ciudad" id="l3_info_ciudad_field" value="' . esc_attr($val) . '" placeholder="Ej: Bogotá, Colombia" class="regular-text">'; 
    echo l3_render_switch('l3_info_ciudad');
    echo '<p class="description">Ingresa la <strong>Ciudad y el País</strong> (Ej: Bogotá, Colombia). Esto es crucial para que el mapa geolocalice la oficina con precisión y el sistema de validación funcione correctamente.</p>';
}
function l3_render_telefono() { 
    $val = get_option('l3_info_telefono'); 
    echo '<input type="text" name="l3_info_telefono" value="' . esc_attr($val) . '" placeholder="Ej: +57 1 234 5678" class="regular-text">'; 
    echo l3_render_switch('l3_info_telefono');
}
function l3_render_movil() { 
    $val = get_option('l3_info_movil'); 
    echo '<input type="text" name="l3_info_movil" value="' . esc_attr($val) . '" placeholder="Ej: +57 300 123 4567" class="regular-text">';
    echo l3_render_switch('l3_info_movil', 'Mostrar WhatsApp:');
    echo '<p class="description">Este número se utilizará para la futura integración con <strong>WhatsApp</strong>.</p>';
}
function l3_render_email() { 
    $val = get_option('l3_info_email'); 
    echo '<input type="text" name="l3_info_email" value="' . esc_attr($val) . '" placeholder="Ej: contacto@linea3legal.com" class="regular-text">';
    echo l3_render_switch('l3_info_email');
    echo '<p class="description" style="color: #d63638; font-weight: 500; margin-top: 5px;">⚠️ IMPORTANTE: Utiliza únicamente correos bajo el dominio @linea3legal.com.</p>';
}
function l3_render_horario() { 
    $val = get_option('l3_info_horario'); 
    echo '<input type="text" name="l3_info_horario" value="' . esc_attr($val) . '" placeholder="Ej: Lunes a Viernes..." class="regular-text">'; 
    echo l3_render_switch('l3_info_horario');
}
function l3_render_linkedin() { 
    $val = get_option('l3_info_linkedin'); 
    echo '<input type="url" name="l3_info_linkedin" value="' . esc_attr($val) . '" placeholder="https://..." class="regular-text">'; 
    echo l3_render_switch('l3_info_linkedin');
}
function l3_render_instagram() { 
    $val = get_option('l3_info_instagram'); 
    echo '<input type="url" name="l3_info_instagram" value="' . esc_attr($val) . '" placeholder="https://..." class="regular-text">'; 
    echo l3_render_switch('l3_info_instagram');
}
function l3_render_facebook() { 
    $val = get_option('l3_info_facebook'); 
    echo '<input type="url" name="l3_info_facebook" value="' . esc_attr($val) . '" placeholder="https://..." class="regular-text">'; 
    echo l3_render_switch('l3_info_facebook');
}

function l3_render_linkedin_client_id() {
    $val = get_option('l3_linkedin_client_id');
    echo '<input type="text" name="l3_linkedin_client_id" value="' . esc_attr($val) . '" class="regular-text">';
    echo '<p class="description">El Client ID obtenido de tu App en el LinkedIn Developer Portal (para logueo de clientes).</p>';
}

function l3_render_linkedin_client_secret() {
    $val = get_option('l3_linkedin_client_secret');
    echo '<input type="password" name="l3_linkedin_client_secret" value="' . esc_attr($val) . '" class="regular-text">';
    echo '<p class="description">El Client Secret obtenido de tu App en el LinkedIn Developer Portal (para logueo de clientes).</p>';
}

function l3_render_linkedin_org_client_id() {
    $val = get_option('l3_linkedin_org_client_id');
    echo '<input type="text" name="l3_linkedin_org_client_id" value="' . esc_attr($val) . '" class="regular-text">';
    echo '<p class="description">El Client ID obtenido de tu App secundaria en el LinkedIn Developer Portal (dedicada exclusivamente a la Empresa).</p>';
}

function l3_render_linkedin_org_client_secret() {
    $val = get_option('l3_linkedin_org_client_secret');
    echo '<input type="password" name="l3_linkedin_org_client_secret" value="' . esc_attr($val) . '" class="regular-text">';
    echo '<p class="description">El Client Secret obtenido de tu App secundaria en el LinkedIn Developer Portal (dedicada exclusivamente a la Empresa).</p>';
}

function l3_render_linkedin_org_id() {
    $val = get_option('l3_linkedin_org_id');
    echo '<input type="text" name="l3_linkedin_org_id" value="' . esc_attr($val) . '" class="regular-text">';
    echo '<p class="description">El ID numérico de tu página corporativa de LinkedIn (ej: <code>12345678</code>).</p>';
}

function l3_render_linkedin_org_token() {
    $val = get_option('l3_linkedin_org_token');
    $client_id = get_option('l3_linkedin_org_client_id');
    $client_secret = get_option('l3_linkedin_org_client_secret');

    echo '<div style="display: flex; flex-direction: column; gap: 10px; max-width: 600px;">';
    echo '  <textarea name="l3_linkedin_org_token" id="l3_linkedin_org_token" rows="3" class="large-text code" style="font-family: monospace;" readonly>' . esc_textarea($val) . '</textarea>';
    
    if (!empty($client_id) && !empty($client_secret)) {
        $redirect_uri = urlencode(admin_url('options-general.php?page=l3_info_settings_page'));
        $state = wp_create_nonce('l3_linkedin_admin_oauth');
        // Scopes estándar activos en tu App de LinkedIn de Empresa (incluyendo el de Empresa)
        $scope = urlencode('openid profile email w_member_social w_organization_social');
        $auth_url = "https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id={$client_id}&redirect_uri={$redirect_uri}&state={$state}&scope={$scope}";
        
        echo '  <div>';
        echo '    <a href="' . esc_url($auth_url) . '" class="button button-secondary" style="background: #0077b5; color: #fff; border-color: #0077b5; font-weight: 500; display: inline-flex; align-items: center; gap: 5px;">';
        echo '      <span class="dashicons dashicons-linkedin" style="margin-top: 1px;"></span>';
        echo '      Generar / Actualizar Token de LinkedIn (Empresa)';
        echo '    </a>';
        echo '  </div>';
    } else {
        echo '  <p style="color: #d63638; font-weight: 500; margin: 0;">⚠️ Ingresa tu Client ID (Empresa) y Client Secret (Empresa) primero, guarda los cambios y luego podrás generar el Token con un clic.</p>';
    }
    
    echo '  <p class="description" style="margin: 0;">Token de acceso de larga duración con permisos de organización (<code>w_organization_social</code>) para publicar reseñas en el perfil de la empresa.</p>';
    echo '</div>';
}

// 2.5 Capturar Callback de OAuth Administrativo para Token Corporativo
add_action('admin_init', 'l3_linkedin_capture_admin_oauth');
function l3_linkedin_capture_admin_oauth() {
    if (isset($_GET['page']) && $_GET['page'] === 'l3_info_settings_page' && isset($_GET['code'])) {
        // Verificar state de seguridad
        if (!isset($_GET['state']) || !wp_verify_nonce($_GET['state'], 'l3_linkedin_admin_oauth')) {
            wp_die('Error de validación de seguridad (state incorrecto). Por favor, intenta de nuevo.');
        }
        
        $code = sanitize_text_field($_GET['code']);
        $client_id = get_option('l3_linkedin_org_client_id');
        $client_secret = get_option('l3_linkedin_org_client_secret');
        $redirect_uri = admin_url('options-general.php?page=l3_info_settings_page');
        
        // Intercambiar código temporal por token de acceso real
        $response = wp_remote_post('https://www.linkedin.com/oauth/v2/accessToken', array(
            'body' => array(
                'grant_type'    => 'authorization_code',
                'code'          => $code,
                'redirect_uri'  => $redirect_uri,
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
            )
        ));
        
        if (is_wp_error($response)) {
            wp_redirect(admin_url('options-general.php?page=l3_info_settings_page&l3_oauth_error=' . urlencode($response->get_error_message())));
            exit;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['access_token'])) {
            update_option('l3_linkedin_org_token', $body['access_token']);
            wp_redirect(admin_url('options-general.php?page=l3_info_settings_page&l3_oauth_success=1'));
            exit;
        } else {
            $err_msg = isset($body['error_description']) ? $body['error_description'] : 'Error desconocido al canjear el token.';
            wp_redirect(admin_url('options-general.php?page=l3_info_settings_page&l3_oauth_error=' . urlencode($err_msg)));
            exit;
        }
    }
}

// Avisos de éxito/error de OAuth en el panel
add_action('admin_notices', 'l3_linkedin_oauth_notices');
function l3_linkedin_oauth_notices() {
    if (isset($_GET['page']) && $_GET['page'] === 'l3_info_settings_page') {
        if (isset($_GET['l3_oauth_success'])) {
            echo '<div class="notice notice-success is-dismissible"><p><strong>✓ ¡Éxito!</strong> El Token de Organización de LinkedIn se ha generado y guardado correctamente.</p></div>';
        } elseif (isset($_GET['l3_oauth_error'])) {
            echo '<div class="notice notice-error is-dismissible"><p><strong>❌ Error de LinkedIn:</strong> ' . esc_html(sanitize_text_field($_GET['l3_oauth_error'])) . '</p></div>';
        }
    }
}

// 3. Render de la página
function l3_info_page_render() {
    wp_enqueue_media(); // Habilita la biblioteca de medios en esta página
    ?>
    <style>
        .l3-switch { position: relative; display: inline-block; width: 40px; height: 22px; }
        .l3-switch input { opacity: 0; width: 0; height: 0; }
        .l3-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .l3-slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .l3-slider { background-color: #2271b1; }
        input:checked + .l3-slider:before { transform: translateX(18px); }
    </style>
    <div class="wrap">
        <h1>Gestión de Información Corporativa</h1>
        <hr>
        <form method="post" action="options.php">
            <?php
            settings_fields('l3_options_group');
            do_settings_sections('l3_info_settings_page');
            submit_button('Guardar Información');
            ?>
        </form>
    </div>
    <?php
}

// 4. Shortcodes con Lógica de Visibilidad Estricta
function l3_get_dynamic_info($id) {
    $val = get_option($id);
    $vis = get_option($id . '_vis');
    
    // 1. Si no hay nada registrado (está vacío), devolvemos vacío siempre
    if (empty($val)) return '';
    
    // 2. Si hay datos pero el interruptor de "Mostrar" está apagado, devolvemos vacío
    if (!$vis) return ''; 
    
    // 3. Solo si hay datos Y está el interruptor encendido, devolvemos el valor
    return $val;
}

add_shortcode('l3_info_lugar', function() { return l3_get_dynamic_info('l3_info_lugar'); });
add_shortcode('l3_info_direccion', function() { 
    $val = l3_get_dynamic_info('l3_info_direccion');
    return !empty($val) ? nl2br($val) : ''; 
});
add_shortcode('l3_info_ciudad', function() { return l3_get_dynamic_info('l3_info_ciudad'); });
add_shortcode('l3_info_telefono', function() { return l3_get_dynamic_info('l3_info_telefono'); });
add_shortcode('l3_info_movil', function() { return l3_get_dynamic_info('l3_info_movil'); });
add_shortcode('l3_info_email', function() { return l3_get_dynamic_info('l3_info_email'); });
add_shortcode('l3_info_horario', function() { return l3_get_dynamic_info('l3_info_horario'); });

// Shortcodes de Redes Sociales (devuelven la URL solo si hay dato y está visible)
add_shortcode('l3_social_linkedin', function() { return l3_get_dynamic_info('l3_info_linkedin'); });
add_shortcode('l3_social_instagram', function() { return l3_get_dynamic_info('l3_info_instagram'); });
add_shortcode('l3_social_facebook', function() { return l3_get_dynamic_info('l3_info_facebook'); });

/**
 * Shortcode Maestro para Redes Sociales en el Footer
 * Solo renderiza los iconos que tienen datos y están visibles.
 */
add_shortcode('l3_footer_socials', function() {
    $networks = [
        'instagram' => [
            'id' => 'l3_info_instagram',
            'svg' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>'
        ],
        'facebook'  => [
            'id' => 'l3_info_facebook',
            'svg' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/></svg>'
        ],
        'linkedin'  => [
            'id' => 'l3_info_linkedin',
            'svg' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>'
        ]
    ];
    
    $items_html = '';
    foreach ($networks as $service => $data) {
        $url = l3_get_dynamic_info($data['id']);
        if (!empty($url)) {
            $items_html .= '<li style="margin:0;">
                <a href="' . esc_url($url) . '" target="_blank" rel="noopener nofollow" class="l3-social-link">
                    ' . $data['svg'] . '
                </a>
            </li>';
        }
    }
    
    if (empty($items_html)) return '';
    
    $styles = '<style>
        .l3-social-link { 
            color: #b89664 !important; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            width: 40px; 
            height: 40px; 
            border: 1px solid #b89664; 
            border-radius: 4px; 
            padding: 8px; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: transparent;
        }
        .l3-social-link:hover { 
            background: #b89664 !important; 
            color: #0a2233 !important; 
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(184, 150, 100, 0.3);
        }
        .l3-social-link svg { width: 20px; height: 20px; transition: transform 0.3s ease; }
        .l3-social-link:hover svg { transform: scale(1.1); }
    </style>';
    
    return $styles . '<ul class="l3-footer-socials" style="display: flex; gap: 12px; list-style: none; padding: 0; margin: 15px 0 0 0;">' . $items_html . '</ul>';
});


/**
 * Shortcode Maestro para la Sección de la Sede
 * Renderiza dinámicamente toda la sección de ubicación y contacto.
 * Uso: [l3_seccion_sede]
 */
add_shortcode('l3_seccion_sede', function() {
    $img_id = get_option('l3_info_foto_sede_id');
    $img_data = wp_get_attachment_image_src($img_id, 'l3_sede_thumb');
    $default_img = get_stylesheet_directory_uri() . '/assets/images/oficina-bogota.png';
    $img_path = ($img_data) ? $img_data[0] : $default_img;
    
    $direccion = do_shortcode('[l3_info_direccion]');
    $lugar = do_shortcode('[l3_info_lugar]');
    $ciudad = do_shortcode('[l3_info_ciudad]');
    $email = do_shortcode('[l3_info_email]');
    $telefono = do_shortcode('[l3_info_telefono]');
    $horario = do_shortcode('[l3_info_horario]');
    
    // Fallbacks por si los datos están vacíos
    $direccion_display = !empty($direccion) ? $direccion . (!empty($lugar) ? ', ' . $lugar : '') : '<span style="color:red;">(Dirección no configurada)</span>';
    $ciudad_display = !empty($ciudad) ? $ciudad : '';
    $email_display = !empty($email) ? $email : '<span style="color:red;">(Email no configurado)</span>';
    $telefono_display = !empty($telefono) ? $telefono : '';
    $horario_display = !empty($horario) ? $horario : '<span style="color:red;">(Horario no configurado)</span>';

    ob_start();
    ?>
    <div class="wp-block-group alignfull antigravity-location-section l3-sede-dinamica">
        <div class="wp-block-columns alignwide l3-container-standard" style="display: flex; flex-wrap: wrap; gap: 40px;">
            <!-- Columna Información -->
            <div class="wp-block-column location-content-col" style="flex-basis:40%; min-width: 320px;">
                <div class="wp-block-group location-header" style="display: flex; align-items: center; gap: 20px; margin-bottom: 30px;">
                    <div style="width: 4px; height: 60px; background: #b89664;"></div>
                    <div>
                        <p style="margin: 0; font-size: 14px; letter-spacing: 2px; color: #b89664;">UBICACIÓN</p>
                        <h2 style="margin: 0; font-size: 32px; color: #fff;">Nuestra Sede en Bogotá</h2>
                    </div>
                </div>

                <figure class="wp-block-image size-large" style="margin-bottom: 40px;">
                    <img src="<?php echo $img_path; ?>" alt="Sede Linea 3 Bogotá" style="border-radius: 4px; width: 100%; height: auto; display: block;" />
                </figure>

                <div class="location-info-grid" style="display: grid; gap: 30px;">
                    <div>
                        <h3 style="color: #b89664; font-size: 18px; margin-bottom: 10px; font-weight: 600;">Dirección Principal</h3>
                        <p style="margin: 0; line-height: 1.6; color: #fff;"><?php echo $direccion_display; ?><br><?php echo $ciudad_display; ?></p>
                    </div>
                    <div>
                        <h3 style="color: #b89664; font-size: 18px; margin-bottom: 10px; font-weight: 600;">Contacto</h3>
                        <p style="margin: 0; line-height: 1.6; color: #fff;"><?php echo $email_display; ?><br><?php echo $telefono_display; ?></p>
                    </div>
                    <div>
                        <h3 style="color: #b89664; font-size: 18px; margin-bottom: 10px; font-weight: 600;">Horario</h3>
                        <p style="margin: 0; line-height: 1.6; color: #fff;"><?php echo $horario_display; ?></p>
                    </div>
                </div>

                <div style="margin-top: 40px;">
                    <a class="wp-block-button__link wp-element-button antigravity-modal-trigger" style="background: #b89664; color: #fff !important; padding: 15px 30px; border-radius: 2px; text-decoration: none; cursor: pointer; display: inline-block;">Agendar Consulta</a>
                </div>
            </div>

            <!-- Columna Mapa -->
            <div class="wp-block-column" style="flex-basis:55%; min-width: 320px;">
                <?php 
                $map_address = !empty($direccion) ? $direccion . ', ' . $ciudad : 'Bogotá, Colombia';
                echo do_shortcode('[antigravity_map address="' . esc_attr($map_address) . '"]'); 
                ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
});
function linea3_legal_child_limit_search_results($query): void
{
	if ($query->is_search() && !is_admin() && $query->is_main_query()) {
		$query->set('post_type', array('post', 'page'));
	}
}
add_action('pre_get_posts', 'linea3_legal_child_limit_search_results');

/**
 * Helper para obtener el HTML de la imagen destacada con fallback.
 */
function antigravity_get_post_thumbnail_html($post_id, $size = 'medium_large', $attr = array())
{
	$html = get_the_post_thumbnail($post_id, $size, $attr);
	if (empty($html)) {
		$placeholder_url = get_stylesheet_directory_uri() . '/assets/images/placeholder-legal.png';
		$class = isset($attr['class']) ? $attr['class'] . ' fallback-image' : 'wp-post-image fallback-image';

		// Handle dimensions for fallback
		$width_attr = '';
		$height_attr = '';
		if (is_array($size)) {
			$width_attr = sprintf(' width="%d"', $size[0]);
			$height_attr = sprintf(' height="%d"', $size[1]);
		}

		$html = sprintf(
			'<img src="%s" class="%s" alt="" loading="lazy"%s%s />',
			esc_url($placeholder_url),
			esc_attr($class),
			$width_attr,
			$height_attr
		);
	}
	return $html;
}

/**
 * Provides a fallback featured image if a post doesn't have one (Filter version).
 */
function linea3_legal_child_fallback_featured_image($html, $post_id, $post_thumbnail_id, $size, $attr)
{
	if (empty($html)) {
		$placeholder_url = get_stylesheet_directory_uri() . '/assets/images/placeholder-legal.png';

		$width_attr = '';
		$height_attr = '';
		$size_class = '';

		if (is_array($size)) {
			$width_attr = sprintf(' width="%d"', $size[0]);
			$height_attr = sprintf(' height="%d"', $size[1]);
			$size_class = sprintf('size-%dx%d', $size[0], $size[1]);
			$attachment_class = 'custom';
		} else {
			$size_class = 'size-' . (string) $size;
			$attachment_class = (string) $size;
		}

		$html = sprintf(
			'<img src="%s" class="attachment-%s %s wp-post-image fallback-image" alt="" loading="lazy"%s%s />',
			esc_url($placeholder_url),
			esc_attr($attachment_class),
			esc_attr($size_class),
			$width_attr,
			$height_attr
		);
	}
	return $html;
}
add_filter('post_thumbnail_html', 'linea3_legal_child_fallback_featured_image', 10, 5);

/**
 * Shortcode into the search template to display the results count.
 */
function linea3_legal_child_search_result_count()
{
	if (!is_search())
		return '';
	global $wp_query;
	$count = (int) $wp_query->found_posts;
	if ($count === 0)
		return '';
	$label = ($count === 1) ? 'registro encontrado' : 'registros encontrados';
	return sprintf('<p class="search-result-count">Se han visualizado <span class="count-number">%d</span> %s</p>', $count, $label);
}
add_shortcode('search_result_count', 'linea3_legal_child_search_result_count');

/**
 * Fuerza el uso de la nueva cabecera header-v2 para evitar problemas de caché o base de datos.
 */
add_filter('pre_get_block_template', function ($template, $id, $template_type) {
	if ('wp_template_part' === $template_type && 'header' === $id) {
		$template_v2 = get_block_template('linea3-legal-child//header-v2', 'wp_template_part');
		if ($template_v2) {
			return $template_v2;
		}
	}
	return $template;
}, 10, 3);

/**
 * Oculta "Sin categoría" o "Uncategorized" en el frontend en todas las vistas de bloque y shortcodes.
 */
add_filter('get_the_terms', function ($terms, $post_id, $taxonomy) {
	if (is_admin() || 'category' !== $taxonomy || !is_array($terms)) {
		return $terms;
	}
	
	foreach ($terms as $key => $term) {
		if (in_array(strtolower($term->slug), array('uncategorized', 'sin-categoria', 'sin-categoría'))) {
			unset($terms[$key]);
		}
	}
	
	return array_values($terms);
}, 10, 3);

/**
 * Inyecta el contenedor HTML del Modal en el footer.
 */
function antigravity_render_strategic_modal()
{
	?>
	<div class="antigravity-modal-overlay">
		<div class="antigravity-modal-content">
			<button class="antigravity-modal-close" aria-label="Cerrar modal">&times;</button>
			<div class="antigravity-modal-header">
				<h3>Agendar Consulta</h3>
				<p>Complete el siguiente formulario y un especialista de Linea 3 se pondrá en contacto pronto.</p>
			</div>
			<div class="antigravity-modal-body">
				<form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST"
					class="antigravity-modal-form">
					<?php wp_nonce_field('antigravity_consultation_action', 'antigravity_consultation_nonce'); ?>
					<input type="hidden" name="action" value="antigravity_submit_consultation">

					<div class="antigravity-form-grid">
						<div class="antigravity-form-group"><label for="consultation-name">Nombre Completo *</label><input
								type="text" id="consultation-name" name="consultation_name" placeholder="Ej: Juan Pérez"
								required></div>
						<div class="antigravity-form-group"><label for="consultation-email">Correo Electrónico
								*</label><input type="email" id="consultation-email" name="consultation_email"
								placeholder="ejemplo@correo.com" required></div>
						<div class="antigravity-form-group"><label for="consultation-phone">Número de Teléfono
								*</label><input type="tel" id="consultation-phone" name="consultation_phone"
								placeholder="+57 300 000 0000" required></div>
						<div class="antigravity-form-group"><label for="consultation-company">Empresa /
								Organización</label><input type="text" id="consultation-company" name="consultation_company"
								placeholder="Nombre de su empresa"></div>
						<div class="antigravity-form-group full-width"><label for="consultation-message">Detalles de la
								Consulta *</label><textarea id="consultation-message" name="consultation_message" rows="4"
								placeholder="¿En qué podemos ayudarle?" required></textarea></div>
					</div>

					<div class="antigravity-form-group submit-group" style="text-align: right;"><button type="submit"
							class="antigravity-btn-submit">Agendar</button></div>
				</form>
			</div>
		</div>
	</div>
	<?php
}
add_action('wp_footer', 'antigravity_render_strategic_modal');

/**
 * Procesa el envío del formulario de Consulta Estratégica
 */
function antigravity_handle_consultation_form()
{
	if (!isset($_POST['antigravity_consultation_nonce']) || !wp_verify_nonce($_POST['antigravity_consultation_nonce'], 'antigravity_consultation_action')) {
		wp_send_json_error('Fallo de seguridad.');
	}
	$name = sanitize_text_field($_POST['consultation_name'] ?? '');
	$email = sanitize_email($_POST['consultation_email'] ?? '');
	$phone = sanitize_text_field($_POST['consultation_phone'] ?? '');
	$company = sanitize_text_field($_POST['consultation_company'] ?? '');
	$message = sanitize_textarea_field($_POST['consultation_message'] ?? '');
	if (empty($name) || empty($email) || empty($phone) || empty($message) || !is_email($email)) {
		wp_send_json_error('Datos inválidos o incompletos.');
	}
	$to = 'jcarlosj.dev@gmail.com';
	$subject = 'Consulta Agendada: ' . $company . ' - ' . $name;
	$body = "
	<div style='background-color: #0f172a; padding: 40px; font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif;'>
		<div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);'>
			<div style='background-color: #0a2233; padding: 30px; text-align: center; border-bottom: 4px solid #ce9e50;'>
				<a href='" . esc_url(home_url('/')) . "' target='_blank' style='display: inline-block; text-decoration: none;'>
					<img src='" . esc_url(get_stylesheet_directory_uri() . '/assets/images/logo-horizontal-oscuro.png') . "' alt='Linea 3 Estudio Legal' style='max-width: 200px; height: auto; border: none;'>
				</a>
			</div>
			<div style='padding: 40px; color: #334155; line-height: 1.6;'>
				<h2 style='color: #0a2233; margin-top: 0; font-size: 20px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;'>Nueva Consulta</h2>
				
				<div style='margin-bottom: 25px;'>
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Nombre:</strong> " . esc_html($name) . "</p>
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Email:</strong> <a href='mailto:" . esc_attr($email) . "' style='color: #ce9e50; text-decoration: none;'>" . esc_html($email) . "</a></p>
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Teléfono:</strong> " . esc_html($phone) . "</p>
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Empresa:</strong> " . esc_html($company) . "</p>
				</div>

				<div style='background-color: #f8fafc; padding: 25px; border-left: 4px solid #ce9e50; border-radius: 4px;'>
					<h3 style='margin-top: 0; margin-bottom: 10px; font-size: 16px; color: #0a2233; text-transform: uppercase; letter-spacing: 0.5px;'>Detalles de la Consulta</h3>
					<p style='margin: 0; white-space: pre-wrap; color: #475569;'>" . nl2br(esc_html($message)) . "</p>
				</div>
				
				<div style='margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center;'>
					<p style='font-size: 12px; color: #94a3b8; margin: 0;'>Este es un mensaje automático generado desde el portal web de Linea 3 Estudio Legal.</p>
				</div>
			</div>
		</div>
	</div>";
	$headers = array('Content-Type: text/html; charset=UTF-8', 'From: Linea 3 Web <no-reply@linea3legal.com>');
	if (wp_mail($to, $subject, $body, $headers)) {
		wp_send_json_success('Mensaje enviado exitosamente');
	} else {
		wp_send_json_error('Error enviando el correo.');
	}
}
add_action('wp_ajax_nopriv_antigravity_submit_consultation', 'antigravity_handle_consultation_form');
add_action('wp_ajax_antigravity_submit_consultation', 'antigravity_handle_consultation_form');

/**
 * Inyecta el contenedor HTML del Modal de Contacto del Equipo en el footer.
 */
function antigravity_render_team_contact_modal()
{
	?>
	<div class="antigravity-modal-overlay antigravity-team-contact-modal-overlay">
		<div class="antigravity-modal-content team-contact-split-content">
			<button class="antigravity-modal-close" aria-label="Cerrar modal">&times;</button>
			<div class="antigravity-modal-body team-contact-split-layout">
				<div class="team-contact-sidebar">
					<img id="team-contact-modal-image" src="" alt="Profesional" class="team-contact-sidebar-bg">
					<div class="team-contact-sidebar-overlay">
						<h3 id="team-contact-modal-title">Contactar Profesional</h3>
						<p>Envíe un mensaje directo y confidencial. Le responderemos a la brevedad.</p>
					</div>
				</div>
				<div class="team-contact-form-area">
					<form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST"
						class="antigravity-modal-form antigravity-team-contact-form" enctype="multipart/form-data">
						<?php wp_nonce_field('antigravity_team_contact_action', 'antigravity_team_contact_nonce'); ?>
						<input type="hidden" name="action" value="antigravity_submit_team_contact">
						<input type="hidden" name="target_author_id" id="target_author_id" value="">

						<div class="antigravity-form-grid">
							<div class="antigravity-form-group"><label for="team-contact-email">De: (Su Correo) *</label><input 
									type="email" id="team-contact-email" name="contact_email"
									placeholder="ejemplo@correo.com" required></div>
							<div class="antigravity-form-group"><label for="team-contact-phone">Teléfono</label><input 
									type="tel" id="team-contact-phone" name="contact_phone"
									placeholder="Su número de teléfono"></div>
							<div class="antigravity-form-group"><label for="team-contact-subject">Asunto: *</label><input 
									type="text" id="team-contact-subject" name="contact_subject"
									placeholder="Motivo de la consulta" required></div>
							<div class="antigravity-form-group"><label for="team-contact-name">Tu Nombre: *</label><input 
									type="text" id="team-contact-name" name="contact_name"
									placeholder="Ej. Juan Pérez" required></div>
							<div class="antigravity-form-group full-width"><label for="team-contact-message">Mensaje: *</label><textarea 
									id="team-contact-message" name="contact_message" rows="5"
									placeholder="Escriba su mensaje aquí..." required></textarea></div>
							<div class="antigravity-form-group full-width">
								<label for="team-contact-attachment" style="display: flex; justify-content: space-between;">
									<span>Archivos Adjuntos (Opcional)</span>
									<span style="font-size: 0.8em; color: #94a3b8; font-weight: normal;">Máx. Total 15MB (PDF, DOC, DOCX, JPG, PNG)</span>
								</label>
								<input type="file" id="team-contact-attachment" name="contact_attachment[]" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" multiple>
							</div>
						</div>

						<div class="antigravity-form-group submit-group" style="text-align: right;"><button type="submit"
								class="antigravity-btn-submit">Enviar Mensaje</button></div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php
}
add_action('wp_footer', 'antigravity_render_team_contact_modal');

/**
 * Procesa el envío del formulario de Contacto al Equipo
 */
function antigravity_handle_team_contact_form()
{
	if (!isset($_POST['antigravity_team_contact_nonce']) || !wp_verify_nonce($_POST['antigravity_team_contact_nonce'], 'antigravity_team_contact_action')) {
		wp_send_json_error('Fallo de seguridad.');
	}

	$author_id = isset($_POST['target_author_id']) ? intval($_POST['target_author_id']) : 0;
	if ($author_id <= 0) {
		wp_send_json_error('Destinatario no válido.');
	}

	$target_user = get_userdata($author_id);
	if (!$target_user || empty($target_user->user_email)) {
		wp_send_json_error('El profesional seleccionado no está disponible.');
	}

	$email = sanitize_email($_POST['contact_email'] ?? '');
	$phone = sanitize_text_field($_POST['contact_phone'] ?? '');
	$subject_input = sanitize_text_field($_POST['contact_subject'] ?? '');
	$name = sanitize_text_field($_POST['contact_name'] ?? '');
	$message = sanitize_textarea_field($_POST['contact_message'] ?? '');

	if (empty($email) || empty($subject_input) || empty($message) || empty($name) || !is_email($email)) {
		wp_send_json_error('Datos inválidos o incompletos.');
	}

	$to = $target_user->user_email;
	$professional_name = $target_user->display_name;

	$subject = 'Mensaje Directo: ' . $subject_input;
	$body = "
	<div style='background-color: #0f172a; padding: 40px; font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif;'>
		<div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);'>
			<div style='background-color: #0a2233; padding: 30px; text-align: center; border-bottom: 4px solid #ce9e50;'>
				<a href='" . esc_url(home_url('/')) . "' target='_blank' style='display: inline-block; text-decoration: none;'>
					<img src='" . esc_url(get_stylesheet_directory_uri() . '/assets/images/logo-horizontal-oscuro.png') . "' alt='Linea 3 Estudio Legal' style='max-width: 200px; height: auto; border: none;'>
				</a>
			</div>
			<div style='padding: 40px; color: #334155; line-height: 1.6;'>
				<h2 style='color: #0a2233; margin-top: 0; font-size: 20px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;'>Nuevo Mensaje Directo</h2>
				<p style='color: #475569;'>Hola <strong>" . esc_html($professional_name) . "</strong>, has recibido un mensaje a través de tu perfil en Linea 3.</p>
				
				<div style='margin-bottom: 25px;'>
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>De:</strong> " . esc_html($name) . " &lt;<a href='mailto:" . esc_attr($email) . "' style='color: #ce9e50; text-decoration: none;'>" . esc_html($email) . "</a>&gt;</p>
					" . (!empty($phone) ? "<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Teléfono:</strong> " . esc_html($phone) . "</p>" : "") . "
					<p style='margin: 5px 0;'><strong style='color: #0a2233;'>Asunto:</strong> " . esc_html($subject_input) . "</p>
				</div>

				<div style='background-color: #f8fafc; padding: 25px; border-left: 4px solid #ce9e50; border-radius: 4px;'>
					<h3 style='margin-top: 0; margin-bottom: 10px; font-size: 16px; color: #0a2233; text-transform: uppercase; letter-spacing: 0.5px;'>Mensaje</h3>
					<p style='margin: 0; white-space: pre-wrap; color: #475569;'>" . nl2br(esc_html($message)) . "</p>
				</div>
				
				<div style='margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center;'>
					<p style='font-size: 12px; color: #94a3b8; margin: 0;'>Este es un mensaje automático generado desde el portal web de Linea 3 Estudio Legal.</p>
				</div>
			</div>
		</div>
	</div>";
	
	$attachments = array();
	$uploaded_files = array(); // Para limpiar archivos temporales luego del envío

	// Manejo de archivos adjuntos (Múltiples)
	if (isset($_FILES['contact_attachment']) && is_array($_FILES['contact_attachment']['name'])) {
		$files = $_FILES['contact_attachment'];
		$total_size = 0;
		$num_files = count($files['name']);

		// Calcular el tamaño total de todos los archivos
		for ($i = 0; $i < $num_files; $i++) {
			if ($files['error'][$i] === UPLOAD_ERR_OK) {
				$total_size += $files['size'][$i];
			}
		}

		// Validar tamaño global: 15MB (15 * 1024 * 1024)
		if ($total_size > 15728640) {
			wp_send_json_error('El peso total de los archivos adjuntos excede el límite máximo de 15MB.');
		}

		if (!function_exists('wp_handle_upload')) {
			require_once(ABSPATH . 'wp-admin/includes/file.php');
		}

		// Definir mimes permitidos por seguridad
		$mimes = array(
			'pdf' => 'application/pdf',
			'doc' => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png' => 'image/png'
		);

		$upload_overrides = array('test_form' => false, 'mimes' => $mimes);

		// Subir cada archivo temporalmente
		for ($i = 0; $i < $num_files; $i++) {
			if ($files['error'][$i] === UPLOAD_ERR_OK) {
				$single_file = array(
					'name'     => $files['name'][$i],
					'type'     => $files['type'][$i],
					'tmp_name' => $files['tmp_name'][$i],
					'error'    => $files['error'][$i],
					'size'     => $files['size'][$i]
				);

				$movefile = wp_handle_upload($single_file, $upload_overrides);

				if ($movefile && !isset($movefile['error'])) {
					$attachments[] = $movefile['file'];
					$uploaded_files[] = $movefile['file']; // Guardar ruta absoluta para borrar luego
				} else {
					wp_send_json_error('Error procesando el archivo ' . esc_html($single_file['name']) . ': ' . $movefile['error']);
				}
			}
		}
	}

	$headers = array('Content-Type: text/html; charset=UTF-8', 'From: Linea 3 Web <no-reply@linea3legal.com>');
	$mail_sent = wp_mail($to, $subject, $body, $headers, $attachments);

	// Eliminar archivos temporales para no ocupar espacio en el servidor
	if (!empty($uploaded_files)) {
		foreach ($uploaded_files as $file_path) {
			@unlink($file_path);
		}
	}

	if ($mail_sent) {
		wp_send_json_success('Mensaje enviado exitosamente');
	} else {
		wp_send_json_error('Error enviando el correo al profesional.');
	}
}
add_action('wp_ajax_nopriv_antigravity_submit_team_contact', 'antigravity_handle_team_contact_form');
add_action('wp_ajax_antigravity_submit_team_contact', 'antigravity_handle_team_contact_form');

/**
 * Intercepta los correos salientes en desarrollo local.
 */
function antigravity_mailpit_smtp($phpmailer)
{
	$phpmailer->isSMTP();
	$phpmailer->Host = 'mailpit';
	$phpmailer->SMTPAuth = false;
	$phpmailer->Port = 1025;
}
if (isset($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'], 'localhost') !== false) {
	add_action('phpmailer_init', 'antigravity_mailpit_smtp');
}

/**
 * Shortcode para mapa dinámico y fácil de editar.
 * Uso: [antigravity_map address="Calle 93 #11-13, Bogotá"]
 */
function antigravity_map_shortcode($atts)
{
	$atts = shortcode_atts(array(
		'address' => 'Calle 93 #11-13, Bogotá',
		'zoom' => '15'
	), $atts);
	$address = urlencode($atts['address']);
	return '<div class="antigravity-location-map-container">
		<iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
		src="https://maps.google.com/maps?q=' . $address . '&t=&z=' . $atts['zoom'] . '&ie=UTF8&iwloc=&output=embed"></iframe>
	</div>';
}
add_shortcode('antigravity_map', 'antigravity_map_shortcode');

/**
 * Registra categorías y patrones de bloques.
 */
function antigravity_register_block_patterns(): void
{
	register_block_pattern_category('antigravity-patterns', array('label' => 'Linea 3 Patterns'));
	register_block_pattern('antigravity/cta-strategic-consultation', array('title' => 'Agendar Consulta', 'categories' => array('antigravity-patterns'), 'content' => '<!-- wp:group {"layout":{"type":"constrained"}} --><div class="wp-block-group"><!-- wp:template-part {"slug":"cta-strategic-consultation","theme":"' . get_stylesheet() . '"} /--></div><!-- /wp:group -->'));
	register_block_pattern('antigravity/nuestro-equipo', array('title' => 'Equipo Jurídico', 'categories' => array('antigravity-patterns'), 'content' => '<!-- wp:group {"className":"antigravity-team-section","layout":{"type":"constrained"}} --><div class="wp-block-group antigravity-team-section"><!-- wp:shortcode -->[antigravity_team_grid]<!-- /wp:shortcode --></div><!-- /wp:group -->'));
	register_block_pattern('antigravity/publicaciones-destacadas', array('title' => 'Publicaciones Destacadas', 'categories' => array('antigravity-patterns'), 'content' => '<!-- wp:group {"className":"antigravity-featured-posts-section","layout":{"type":"constrained"}} --><div class="wp-block-group antigravity-featured-posts-section"><!-- wp:shortcode -->[antigravity_featured_posts]<!-- /wp:shortcode --></div><!-- /wp:group -->'));
	register_block_pattern('antigravity/hero-editorial', array(
		'title' => 'Hero Editorial',
		'categories' => array('antigravity-patterns'),
		'content' => '<!-- wp:cover {"dimRatio":80,"overlayColor":"base","minHeight":85,"minHeightUnit":"vh","align":"full","className":"antigravity-hero-editorial","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull antigravity-hero-editorial" style="min-height:85vh"><span aria-hidden="true" class="wp-block-cover__background has-base-background-color has-background-dim-80 has-background-dim"></span><div class="wp-block-cover__inner-container">
    <div class="wp-block-group l3-container-standard">
        <!-- wp:group {"className":"hero-content-wrapper","layout":{"type":"constrained","justifyContent":"left"}} -->
        <div class="wp-block-group hero-content-wrapper">
        <!-- wp:separator {"className":"hero-vertical-line"} -->
        <hr class="wp-block-separator has-alpha-channel-opacity hero-vertical-line"/>
        <!-- /wp:separator -->
        <!-- wp:heading {"level":1,"className":"hero-title","style":{"typography":{"lineHeight":"1.1"}},"fontFamily":"serif"} -->
        <h1 class="wp-block-heading hero-title has-serif-font-family" style="line-height:1.1">Nuestra Misión<br>y <span class="accent">Excelencia</span></h1>
        <!-- /wp:heading -->
        <!-- wp:paragraph {"className":"hero-description"} -->
        <p class="hero-description">En Linea 3, concebimos el ejercicio del derecho como un Soberano Archivo de conocimiento. Somos los guardianes de la estructura legal de nuestros representados.</p>
        <!-- /wp:paragraph -->
        <!-- wp:buttons {"className":"hero-buttons"} -->
        <div class="wp-block-buttons hero-buttons">
            <!-- wp:button {"className":"btn-primary-gold"} -->
            <div class="wp-block-button btn-primary-gold"><a class="wp-block-button__link wp-element-button">INICIAR ALIANZA</a></div>
            <!-- /wp:button -->
            <!-- wp:button {"className":"btn-outline-white"} -->
            <div class="wp-block-button btn-outline-white"><a class="wp-block-button__link wp-element-button">NUESTRA FIRMA</a></div>
            <!-- /wp:button -->
        </div>
        <!-- /wp:buttons -->
    </div>
    <!-- /wp:group -->
    </div>
</div></div>
<!-- /wp:cover -->'
	));
	register_block_pattern('antigravity/mapa-sede', array(
		'title'       => 'Mapa - Nuestra Sede (Dinámico)',
		'categories'  => array('antigravity-patterns'),
		'content'     => '<!-- wp:shortcode -->[l3_seccion_sede]<!-- /wp:shortcode -->',
	));
	
	register_block_pattern('antigravity/servicios', array(
		'title' => 'Servicios Legales (Grid Dinámico)',
		'categories' => array('antigravity-patterns'),
		'content' => '<!-- wp:group {"className":"l3-container-standard","layout":{"type":"constrained"}} -->
<div class="wp-block-group l3-container-standard">
    <!-- wp:group {"className":"services-section-header","layout":{"type":"constrained"}} -->
    <div class="wp-block-group services-section-header">
        <!-- wp:group {"className":"section-vertical-line","layout":{"type":"constrained"}} -->
        <div class="wp-block-group section-vertical-line"></div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"services-header-left","layout":{"type":"constrained"}} -->
        <div class="wp-block-group services-header-left">
            <!-- wp:paragraph {"className":"services-eyebrow"} -->
            <p class="services-eyebrow">ESPECIALIZACIÓN Y ESTRATEGIA JURÍDICA</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":2,"className":"services-title"} -->
            <h2 class="wp-block-heading services-title">Nuestras Áreas de Práctica</h2>
            <!-- /wp:heading -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->

    <!-- wp:shortcode -->
    [antigravity_services_grid orderby="date" order="ASC"]
    <!-- /wp:shortcode -->
</div>
<!-- /wp:group -->'
	));

    register_block_pattern('antigravity/aliados', array(
        'title' => 'Nuestros Clientes (Logos)',
        'categories' => array('antigravity-patterns'),
        'content' => '<!-- wp:group {"align":"full","className":"l3-allies-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull l3-allies-section">
    <!-- wp:group {"className":"l3-container-standard","layout":{"type":"constrained"}} -->
    <div class="wp-block-group l3-container-standard">
        <!-- wp:group {"className":"l3-allies-header-centered","layout":{"type":"constrained"}} -->
        <div class="wp-block-group l3-allies-header-centered">
            <!-- wp:paragraph {"className":"services-eyebrow"} -->
            <p class="services-eyebrow">RESPALDO Y COOPERACIÓN</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":2,"className":"services-title"} -->
            <h2 class="wp-block-heading services-title">Nuestros clientes</h2>
            <!-- /wp:heading -->
        </div>
        <!-- /wp:group -->

        <!-- wp:shortcode -->
        [antigravity_allies_grid]
        <!-- /wp:shortcode -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->'
    ));

    register_block_pattern('antigravity/testimonios-slider', array(
        'title' => 'Testimonios de Clientes (Slider)',
        'categories' => array('antigravity-patterns'),
        'content' => '<!-- wp:group {"align":"full","className":"l3-allies-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull l3-allies-section">
    <!-- wp:group {"className":"l3-container-standard","layout":{"type":"constrained"}} -->
    <div class="wp-block-group l3-container-standard">
        <!-- wp:group {"className":"services-section-header","layout":{"type":"constrained"}} -->
        <div class="wp-block-group services-section-header">
            <!-- wp:group {"className":"section-vertical-line","layout":{"type":"constrained"}} -->
            <div class="wp-block-group section-vertical-line"></div>
            <!-- /wp:group -->

            <!-- wp:group {"className":"services-header-left","layout":{"type":"constrained"}} -->
            <div class="wp-block-group services-header-left">
                <!-- wp:paragraph {"className":"services-eyebrow"} -->
                <p class="services-eyebrow">EXPERIENCIAS</p>
                <!-- /wp:paragraph -->

                <!-- wp:heading {"level":2,"className":"services-title"} -->
                <h2 class="wp-block-heading services-title" style="color: #ffffff !important;">Testimonios de nuestros clientes</h2>
                <!-- /wp:heading -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:group -->

        <!-- wp:shortcode -->
        [antigravity_reviews_slider]
        <!-- /wp:shortcode -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->'
    ));
}
add_action('init', 'antigravity_register_block_patterns');

function antigravity_register_enfoque_pattern(): void {
    $content = <<<'PATTERN_HTML'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull l3-enfoque-wrapper">
    <!-- wp:html -->
    <style>
        .l3-enfoque-section, .l3-enfoque-container, .l3-enfoque-table-wrapper {
            background-color: transparent !important;
            background: transparent !important;
        }
    </style>
    <section class="l3-enfoque-section">
        <div class="l3-enfoque-container">
            
        <div class="l3-enfoque-header">
            <span class="l3-enfoque-label">COMPARATIVA DE ENFOQUE</span>
            <h2 class="l3-enfoque-title">Cambiando el enfoque del derecho</h2>
        </div>

            <div class="l3-enfoque-table-wrapper">
                <div class="l3-enfoque-table">
                    <div class="l3-enfoque-row header-row">
                        <div class="l3-enfoque-cell empty-cell"></div>
                        <div class="l3-enfoque-cell label-cell">Tradicional</div>
                        <div class="l3-enfoque-cell label-cell highlight">
                            <img src="/wp-content/themes/linea3-legal-child/assets/images/logo-horizontal-oscuro.png" alt="Linea 3" class="l3-enfoque-logo">
                        </div>
                    </div>

                    <div class="l3-enfoque-row">
                        <div class="l3-enfoque-cell feature-cell">Visión</div>
                        <div class="l3-enfoque-cell content-cell">Trámite y obstáculo postergable</div>
                        <div class="l3-enfoque-cell content-cell highlight">
                            <span class="l3-check-icon l3-check-delay-1"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                            Herramienta estratégica y accesible
                        </div>
                    </div>

                    <div class="l3-enfoque-row">
                        <div class="l3-enfoque-cell feature-cell">Enfoque</div>
                        <div class="l3-enfoque-cell content-cell">Reactivo y enfocado en apagar incendios</div>
                        <div class="l3-enfoque-cell content-cell highlight">
                            <span class="l3-check-icon l3-check-delay-2"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                            Preventivo, organizativo y protector
                        </div>
                    </div>

                    <div class="l3-enfoque-row">
                        <div class="l3-enfoque-cell feature-cell">Lenguaje</div>
                        <div class="l3-enfoque-cell content-cell">Complejo, teórico y distante</div>
                        <div class="l3-enfoque-cell content-cell highlight">
                            <span class="l3-check-icon l3-check-delay-3"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                            Simple, claro y basado en la experiencia
                        </div>
                    </div>
                </div>
            </div>

            <div class="l3-enfoque-footer">
                <div class="l3-enfoque-footer-divider"></div>
                <p class="l3-enfoque-footer-text">
                    En <strong>Línea Tres</strong> convertimos lo jurídico en tu mayor ventaja:<br>
                    prevenimos errores, organizamos tu negocio y protegemos tu crecimiento.
                </p>
            </div>

        </div>
    </section>
    <!-- /wp:html -->
</div>
<!-- /wp:group -->
PATTERN_HTML;

    register_block_pattern(
        'antigravity/enfoque-derecho',
        array(
            'title'       => __( 'Enfoque del Derecho (Comparativa)', 'linea3-legal-child' ),
            'description' => _x( 'Tabla comparativa entre el enfoque tradicional y Linea 3.', 'Block pattern description', 'linea3-legal-child' ),
            'content'     => $content,
            'categories'  => array( 'antigravity-patterns' ),
        )
    );
}
add_action( 'init', 'antigravity_register_enfoque_pattern' );

/**
 * Registra el patrón Síntoma de la Desorganización Jurídica.
 */
function antigravity_register_sintoma_pattern(): void {
    $content = <<<'PATTERN_HTML'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-base-background-color has-background l3-sintoma-wrapper">
    <!-- wp:html -->
    <section class="l3-sintoma-section">
        <div class="l3-sintoma-container">
            <div class="l3-sintoma-header">
                <span class="l3-sintoma-label">DIAGNÓSTICO LEGAL</span>
                <h2 class="l3-sintoma-title">El síntoma de la<br>desorganización jurídica</h2>
            </div>
            <div class="l3-sintoma-diagram">
                <div class="l3-sintoma-card l3-card-tl">
                    <h3 class="l3-sintoma-card-title">Empresas</h3>
                    <p class="l3-sintoma-card-text">Estructuras jurídicas incompletas que limitan el crecimiento.</p>
                </div>
                <div class="l3-sintoma-con l3-con-tl" aria-hidden="true"></div>
                <div class="l3-sintoma-hub">
                    <div class="l3-sintoma-circle">
                        <span>Desorganización<br>Jurídica</span>
                    </div>
                </div>
                <div class="l3-sintoma-con l3-con-tr" aria-hidden="true"></div>
                <div class="l3-sintoma-card l3-card-tr">
                    <h3 class="l3-sintoma-card-title">Emprendedores</h3>
                    <p class="l3-sintoma-card-text">Falta de guía y protección desde el inicio del proyecto.</p>
                </div>
                <div class="l3-sintoma-card l3-card-bl">
                    <h3 class="l3-sintoma-card-title">Personas</h3>
                    <p class="l3-sintoma-card-text">Desconocimiento de sus derechos fundamentales en el día a día.</p>
                </div>
                <div class="l3-sintoma-con l3-con-bl" aria-hidden="true"></div>
                <div class="l3-sintoma-con l3-con-br" aria-hidden="true"></div>
                <div class="l3-sintoma-card l3-card-br">
                    <h3 class="l3-sintoma-card-title">Capital</h3>
                    <p class="l3-sintoma-card-text">Negocios perdiendo dinero por falta de planeación preventiva.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- /wp:html -->
</div>
<!-- /wp:group -->
PATTERN_HTML;

    register_block_pattern(
        'antigravity/sintoma-juridico',
        array(
            'title'       => __( 'Síntoma Jurídico (Diagrama)', 'linea3-legal-child' ),
            'description' => _x( 'Diagrama hub-spoke de la desorganización jurídica.', 'Block pattern description', 'linea3-legal-child' ),
            'content'     => $content,
            'categories'  => array( 'antigravity-patterns' ),
        )
    );
}
add_action( 'init', 'antigravity_register_sintoma_pattern' );

/**
 * Registra el patrón Nuestra Metodología.
 */
function antigravity_register_metodologia_pattern(): void {
    $theme_dir = get_stylesheet_directory();
    $svg_path = $theme_dir . '/assets/images/infinito.svg';
    $svg_content = file_exists( $svg_path ) ? file_get_contents( $svg_path ) : '';

    $content = <<<PATTERN_HTML
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-base-background-color has-background l3-metodologia-wrapper">
    <!-- wp:html -->
    <section class="l3-metodologia-section">
        <div class="l3-metodologia-container">
            <div class="l3-metodologia-header">
                <span class="l3-metodologia-label">NUESTRA METODOLOGÍA</span>
                <h2 class="l3-metodologia-title">No solo asesoramos.</h2>
            </div>
            <div class="l3-metodologia-diagram">
                <div class="l3-metodo-card l3-metodo-tl">
                    <h3 class="l3-metodo-card-title"><span class="l3-metodo-number">1.</span> Escuchamos</h3>
                    <p class="l3-metodo-card-text">Antes de proponer una solución legal, escuchamos y diagnosticamos tu realidad.</p>
                </div>
                <div class="l3-metodo-card l3-metodo-bl">
                    <h3 class="l3-metodo-card-title"><span class="l3-metodo-number">2.</span> Entendemos</h3>
                    <p class="l3-metodo-card-text">Analizamos el negocio completo, no solo el problema jurídico aislado.</p>
                </div>
                <div class="l3-metodo-hub" style="display: flex; align-items: center; justify-content: center;">
                    {$svg_content}
                </div>
                <div class="l3-metodo-card l3-metodo-tr">
                    <h3 class="l3-metodo-card-title"><span class="l3-metodo-number">3.</span> Simplificamos</h3>
                    <p class="l3-metodo-card-text">Traducimos la complejidad del ordenamiento jurídico a decisiones claras y accesibles.</p>
                </div>
                <div class="l3-metodo-card l3-metodo-br">
                    <h3 class="l3-metodo-card-title"><span class="l3-metodo-number">4.</span> Acompañamos</h3>
                    <p class="l3-metodo-card-text">Estamos presentes en la ejecución de cada decisión para garantizar la seguridad del proyecto.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- /wp:html -->
</div>
<!-- /wp:group -->
PATTERN_HTML;

    register_block_pattern(
        'antigravity/metodologia-final',
        array(
            'title'       => __( 'Nuestra Metodología', 'linea3-legal-child' ),
            'description' => _x( 'Diagrama de flujo (infinito) de la metodología.', 'Block pattern description', 'linea3-legal-child' ),
            'content'     => $content,
            'categories'  => array( 'antigravity-patterns' ),
        )
    );
}
add_action( 'init', 'antigravity_register_metodologia_pattern' );

/**
 * Registra el patrón de Modalidades de Servicio (Blindaje Continuo e Intervención).
 * Se registra por separado para mantener el código limpio y evitar conflictos de sintaxis.
 */
function antigravity_register_modalidades_pattern(): void {
	$content = <<<'PATTERN_HTML'
<!-- wp:group {"align":"full","className":"l3-modalidades-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull l3-modalidades-section has-base-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

    <!-- wp:group {"className":"l3-container-standard","layout":{"type":"constrained"}} -->
    <div class="wp-block-group l3-container-standard">

        <!-- Encabezado centrado -->
        <!-- wp:group {"className":"l3-modalidades-header","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","justifyContent":"center"}} -->
        <div class="wp-block-group l3-modalidades-header" style="margin-bottom:var(--wp--preset--spacing--50)">
            <!-- wp:paragraph {"align":"center","className":"services-eyebrow","textColor":"primary"} -->
            <p class="has-text-align-center services-eyebrow has-primary-color has-text-color">ADAPTABLES A TU ETAPA</p>
            <!-- /wp:paragraph -->
            <!-- wp:heading {"textAlign":"center","level":2,"className":"services-title","fontFamily":"serif"} -->
            <h2 class="wp-block-heading has-text-align-center services-title has-serif-font-family">Adaptables a la etapa de su negocio</h2>
            <!-- /wp:heading -->
        </div>
        <!-- /wp:group -->

        <!-- Grid de tarjetas -->
        <!-- wp:columns {"isStackedOnMobile":true,"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40","top":"var:preset|spacing|40"}}}} -->
        <div class="wp-block-columns is-layout-flex">

            <!-- ===== TARJETA 1: BLINDAJE CONTINUO ===== -->
            <!-- wp:column {"className":"l3-modalidad-card l3-modalidad-blindaje"} -->
            <div class="wp-block-column l3-modalidad-card l3-modalidad-blindaje">
                <!-- wp:group {"className":"l3-modalidad-inner","layout":{"type":"constrained","justifyContent":"center"}} -->
                <div class="wp-block-group l3-modalidad-inner" style="padding:var(--wp--preset--spacing--50)">
                    <!-- Badge pill -->
                    <!-- wp:paragraph {"align":"center","className":"l3-modalidad-badge"} -->
                    <p class="has-text-align-center l3-modalidad-badge">Retainer<br>(Mensualidad)</p>
                    <!-- /wp:paragraph -->
                    <!-- wp:heading {"textAlign":"center","level":3,"className":"has-serif-font-family"} -->
                    <h3 class="wp-block-heading has-text-align-center has-serif-font-family">Blindaje<br>Continuo.</h3>
                    <!-- /wp:heading -->
                    <!-- wp:separator {"className":"is-style-wide"} -->
                    <hr class="wp-block-separator is-style-wide has-alpha-channel-opacity" />
                    <!-- /wp:separator -->
                    <!-- wp:paragraph {"align":"center"} -->
                    <p class="has-text-align-center">Para empresas que requieren un aliado jurídico constante. Prevención, revisión de contratos del día a día y soporte estratégico permanente para asegurar el crecimiento sin interrupciones.</p>
                    <!-- /wp:paragraph -->
                    
                    <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
                    <div class="wp-block-buttons">
                        <!-- wp:button {"className":"btn-primary-gold"} -->
                        <div class="wp-block-button btn-primary-gold"><a class="wp-block-button__link wp-element-button antigravity-modal-trigger">Iniciar Alianza</a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
            <!-- /wp:column -->

            <!-- ===== TARJETA 2: INTERVENCIÓN ===== -->
            <!-- wp:column {"className":"l3-modalidad-card l3-modalidad-intervencion"} -->
            <div class="wp-block-column l3-modalidad-card l3-modalidad-intervencion">
                <!-- wp:group {"className":"l3-modalidad-inner","layout":{"type":"constrained","justifyContent":"center"}} -->
                <div class="wp-block-group l3-modalidad-inner" style="padding:var(--wp--preset--spacing--50)">
                    <!-- Badge pill -->
                    <!-- wp:paragraph {"align":"center","className":"l3-modalidad-badge"} -->
                    <p class="has-text-align-center l3-modalidad-badge">On-Demand<br>(Por Tarea)</p>
                    <!-- /wp:paragraph -->
                    <!-- wp:heading {"textAlign":"center","level":3,"className":"has-serif-font-family"} -->
                    <h3 class="wp-block-heading has-text-align-center has-serif-font-family">Intervención<br>Estratégica.</h3>
                    <!-- /wp:heading -->
                    <!-- wp:separator {"className":"is-style-wide"} -->
                    <hr class="wp-block-separator is-style-wide has-alpha-channel-opacity" />
                    <!-- /wp:separator -->
                    <!-- wp:paragraph {"align":"center"} -->
                    <p class="has-text-align-center">Para proyectos específicos, estructuraciones puntuales o resolución de contingencias. Acompañamiento experto exactamente cuando y donde el negocio lo necesita.</p>
                    <!-- /wp:paragraph -->
                    
                    <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
                    <div class="wp-block-buttons">
                        <!-- wp:button {"className":"l3-btn-amber"} -->
                        <div class="wp-block-button l3-btn-amber"><a class="wp-block-button__link wp-element-button antigravity-modal-trigger">Consultar Caso</a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
            <!-- /wp:column -->

            <!-- ===== TARJETA 3: LITIGIO ESTRATÉGICO ===== -->
            <!-- wp:column {"className":"l3-modalidad-card l3-modalidad-litigio"} -->
            <div class="wp-block-column l3-modalidad-card l3-modalidad-litigio">
                <!-- wp:group {"className":"l3-modalidad-inner","layout":{"type":"constrained","justifyContent":"center"}} -->
                <div class="wp-block-group l3-modalidad-inner" style="padding:var(--wp--preset--spacing--50)">
                    <!-- Badge pill -->
                    <!-- wp:paragraph {"align":"center","className":"l3-modalidad-badge"} -->
                    <p class="has-text-align-center l3-modalidad-badge">Litigio<br>(Defensa Activa)</p>
                    <!-- /wp:paragraph -->
                    <!-- wp:heading {"textAlign":"center","level":3,"className":"has-serif-font-family"} -->
                    <h3 class="wp-block-heading has-text-align-center has-serif-font-family">Litigio<br>Estratégico.</h3>
                    <!-- /wp:heading -->
                    <!-- wp:separator {"className":"is-style-wide"} -->
                    <hr class="wp-block-separator is-style-wide has-alpha-channel-opacity" />
                    <!-- /wp:separator -->
                    <!-- wp:paragraph {"align":"center"} -->
                    <p class="has-text-align-center">Defensa activa de sus intereses en cualquier instancia judicial. Presencia firme, estrategia de alto nivel y representación comprometida hasta obtener el resultado que su negocio merece.</p>
                    <!-- /wp:paragraph -->
                    
                    <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
                    <div class="wp-block-buttons">
                        <!-- wp:button {"className":"l3-btn-teal"} -->
                        <div class="wp-block-button l3-btn-teal"><a class="wp-block-button__link wp-element-button antigravity-modal-trigger">Evaluar Mi Caso</a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
            <!-- /wp:column -->

        </div>
        <!-- /wp:columns -->

    </div>
    <!-- /wp:group -->

</div>
<!-- /wp:group -->
PATTERN_HTML;

	register_block_pattern( 'antigravity/modalidades-servicio', array(
		'title'       => 'Modalidades de Servicio Legal',
		'description' => 'Tres tarjetas: Blindaje, Intervención y Litigio. Diseño editorial premium.',
		'categories'  => array( 'antigravity-patterns' ),
		'keywords'    => array( 'servicio', 'blindaje', 'intervención', 'modalidades', 'legal' ),
		'content'     => $content,
	) );
}
add_action( 'init', 'antigravity_register_modalidades_pattern' );

/**
 * Registra el patrón "Cobertura Legal Estratégica"
 */
function antigravity_register_cobertura_pattern(): void {
    $content = <<<'PATTERN_HTML'
<!-- wp:group {"tagName":"section","align":"full","className":"l3-cobertura-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull l3-cobertura-section">

    <!-- wp:group {"className":"l3-cobertura-container","layout":{"type":"constrained"}} -->
    <div class="wp-block-group l3-cobertura-container">

        <!-- wp:group {"className":"l3-cobertura-header","layout":{"type":"constrained","justifyContent":"center"}} -->
        <div class="wp-block-group l3-cobertura-header">
            <!-- wp:paragraph {"align":"center","className":"services-eyebrow","textColor":"primary"} -->
            <p class="has-text-align-center services-eyebrow has-primary-color has-text-color">SOLUCIONES INTEGRALES</p>
            <!-- /wp:paragraph -->
            <!-- wp:heading {"textAlign":"center","level":2,"className":"l3-cobertura-title","fontFamily":"serif"} -->
            <h2 class="wp-block-heading has-text-align-center l3-cobertura-title has-serif-font-family">Cobertura Legal Estratégica</h2>
            <!-- /wp:heading -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"l3-cobertura-grid","layout":{"type":"flex","flexWrap":"nowrap"}} -->
        <div class="wp-block-group l3-cobertura-grid">

            <!-- Columna 1 -->
            <!-- wp:group {"className":"l3-cobertura-card","layout":{"type":"constrained"}} -->
            <div class="wp-block-group l3-cobertura-card">
                <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                <h3 class="wp-block-heading has-serif-font-family">Corporativo <br>&amp; Negocios</h3>
                <!-- /wp:heading -->
                <!-- wp:list {"className":"l3-cobertura-list"} -->
                <ul class="wp-block-list l3-cobertura-list">
                    <li>Asuntos corporativos</li>
                    <li>Asuntos civiles y comerciales</li>
                    <li>Laboral</li>
                </ul>
                <!-- /wp:list -->
            </div>
            <!-- /wp:group -->

            <!-- Columna 2 -->
            <!-- wp:group {"className":"l3-cobertura-card","layout":{"type":"constrained"}} -->
            <div class="wp-block-group l3-cobertura-card">
                <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                <h3 class="wp-block-heading has-serif-font-family">Riesgo, Regulación <br>&amp; Estado</h3>
                <!-- /wp:heading -->
                <!-- wp:list {"className":"l3-cobertura-list"} -->
                <ul class="wp-block-list l3-cobertura-list">
                    <li>Tributario y Aduanero</li>
                    <li>Administrativo / Ambiental</li>
                    <li>Regulaciones / Extinción de Dominio</li>
                    <li>Compliance - SAGRILAFT</li>
                </ul>
                <!-- /wp:list -->
            </div>
            <!-- /wp:group -->

            <!-- Columna 3 -->
            <!-- wp:group {"className":"l3-cobertura-card","layout":{"type":"constrained"}} -->
            <div class="wp-block-group l3-cobertura-card">
                <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                <h3 class="wp-block-heading has-serif-font-family">Sectores <br>Especializados</h3>
                <!-- /wp:heading -->
                <!-- wp:list {"className":"l3-cobertura-list"} -->
                <ul class="wp-block-list l3-cobertura-list">
                    <li>Transporte</li>
                    <li>Urbanístico</li>
                    <li>Cannabis</li>
                    <li>Zonas francas</li>
                </ul>
                <!-- /wp:list -->
            </div>
            <!-- /wp:group -->

        </div>
        <!-- /wp:group -->

        <!-- wp:paragraph {"align":"center","className":"l3-cobertura-footer-text","fontFamily":"serif"} -->
        <p class="has-text-align-center l3-cobertura-footer-text has-serif-font-family">Un ecosistema diseñado para rodear tu negocio de seguridad jurídica en cada frente.</p>
        <!-- /wp:paragraph -->

    </div>
    <!-- /wp:group -->

</section>
<!-- /wp:group -->
PATTERN_HTML;

    register_block_pattern( 'antigravity/cobertura-legal', array(
        'title'       => 'Cobertura Legal Estratégica',
        'description' => 'Grid de 3 columnas con watermark de logo y diseño editorial.',
        'categories'  => array( 'antigravity-patterns' ),
        'keywords'    => array( 'cobertura', 'legal', 'estratégica', 'grid' ),
        'content'     => $content,
    ) );
}
add_action( 'init', 'antigravity_register_cobertura_pattern' );

/**
 * Registra el patrón "Experiencia Legal (Filosofía)"
 */
function antigravity_register_experiencia_pattern(): void {
    $content = <<<'PATTERN_HTML'
<!-- wp:group {"tagName":"section","align":"full","className":"l3-experiencia-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull l3-experiencia-section">

    <!-- Marca de agua (Logo Symbol) -->
    <!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"l3-cobertura-watermark"} -->
    <figure class="wp-block-image size-full l3-cobertura-watermark">
        <img src="/wp-content/themes/linea3-legal-child/assets/images/logo-favicon.png" alt="" />
    </figure>
    <!-- /wp:image -->

    <!-- wp:group {"className":"l3-experiencia-container","layout":{"type":"constrained"}} -->
    <div class="wp-block-group l3-experiencia-container">

        <!-- wp:group {"className":"l3-experiencia-grid","layout":{"type":"flex","flexWrap":"nowrap"}} -->
        <div class="wp-block-group l3-experiencia-grid">

            <!-- Columna Izquierda: Filosofía -->
            <!-- wp:group {"className":"l3-experiencia-col-left","layout":{"type":"constrained"}} -->
            <div class="wp-block-group l3-experiencia-col-left">

                <div class="l3-experiencia-header">
                    <!-- wp:paragraph {"className":"l3-experiencia-eyebrow"} -->
                    <p class="l3-experiencia-eyebrow">NUESTRA FILOSOFÍA</p>
                    <!-- /wp:paragraph -->
                    
                    <!-- wp:heading {"level":2,"fontFamily":"serif"} -->
                    <h2 class="wp-block-heading has-serif-font-family">Hablamos desde la experiencia, no solo desde la teoría.</h2>
                    <!-- /wp:heading -->
                    
                    <!-- wp:paragraph -->
                    <p>Somos una firma creada por mujeres que han vivido de cerca lo que significa construir empresa, trabajar, asumir riesgos y buscar crecimiento todos los días.</p>
                    <!-- /wp:paragraph -->
                    <!-- wp:paragraph -->
                    <p>Entendemos que detrás de cada decisión legal hay un negocio, un esfuerzo y un camino.</p>
                    <!-- /wp:paragraph -->
                </div>
            </div>
            <!-- /wp:group -->

            <!-- Separador Vertical -->
            <div class="l3-experiencia-separator"></div>

            <!-- Columna Derecha: Características -->
            <!-- wp:group {"className":"l3-experiencia-col-right","layout":{"type":"constrained"}} -->
            <div class="wp-block-group l3-experiencia-col-right">

                <!-- Feature 1: Empatía -->
                <!-- wp:group {"className":"l3-experiencia-feature","layout":{"type":"constrained"}} -->
                <div class="wp-block-group l3-experiencia-feature">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px; height:40px; margin-bottom:15px; color:#b89664;"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
                    </div>
                    <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                    <h3 class="wp-block-heading has-serif-font-family">Empatía Empresarial</h3>
                    <!-- /wp:heading -->
                    <!-- wp:paragraph -->
                    <p>Entendemos tu necesidad porque también la hemos vivido.</p>
                    <!-- /wp:paragraph -->
                </div>
                <!-- /wp:group -->

                <!-- Feature 2: Simplificación -->
                <!-- wp:group {"className":"l3-experiencia-feature","layout":{"type":"constrained"}} -->
                <div class="wp-block-group l3-experiencia-feature">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px; height:40px; margin-bottom:15px; color:#b89664;"><circle cx="12" cy="12" r="10"></circle><path d="M12 8l-4 4 4 4M16 12H8"></path></svg>
                    </div>
                    <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                    <h3 class="wp-block-heading has-serif-font-family">Simplificación Radical</h3>
                    <!-- /wp:heading -->
                    <!-- wp:paragraph -->
                    <p>Traducimos lo complejo para que tú y tu equipo lo manejen de la mejor manera.</p>
                    <!-- /wp:paragraph -->
                </div>
                <!-- /wp:group -->

                <!-- Feature 3: Acompañamiento -->
                <!-- wp:group {"className":"l3-experiencia-feature","layout":{"type":"constrained"}} -->
                <div class="wp-block-group l3-experiencia-feature">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px; height:40px; margin-bottom:15px; color:#b89664;"><polyline points="13 17 18 12 13 7"></polyline><polyline points="6 17 11 12 6 7"></polyline></svg>
                    </div>
                    <!-- wp:heading {"level":3,"fontFamily":"serif"} -->
                    <h3 class="wp-block-heading has-serif-font-family">Acompañamiento Integral</h3>
                    <!-- /wp:heading -->
                    <!-- wp:paragraph -->
                    <p>No dejamos que recorras el camino solo; reducimos el riesgo de tu desarrollo.</p>
                    <!-- /wp:paragraph -->
                </div>
                <!-- /wp:group -->

            </div>
            <!-- /wp:group -->

        </div>
        <!-- /wp:group -->

    </div>
    <!-- /wp:group -->

</section>
<!-- /wp:group -->
PATTERN_HTML;

    register_block_pattern( 'antigravity/experiencia-legal', array(
        'title'       => 'Experiencia Legal (Filosofía)',
        'description' => 'Patrón de dos columnas con separador vertical y diseño editorial premium.',
        'categories'  => array( 'antigravity-patterns' ),
        'keywords'    => array( 'experiencia', 'filosofía', 'empresa', 'legal' ),
        'content'     => $content,
    ) );
}
add_action( 'init', 'antigravity_register_experiencia_pattern' );


/**
 * Registro de bloques dinámicos.
 */
function antigravity_register_dynamic_blocks(): void
{
	register_block_type('antigravity/author-card', array('render_callback' => 'antigravity_render_author_card', 'uses_context' => array('postId')));
}
add_action('init', 'antigravity_register_dynamic_blocks');

	// La función user_contactmethods fue removida para migrar los campos a Información Adicional con mejor control HTML.

/**
 * Añade campos adicionales al perfil (Extracto Profesional)
 */
function antigravity_show_extra_profile_fields($user)
{
	$prefix = get_the_author_meta('antigravity_user_prefix', $user->ID);
	$specialty = get_the_author_meta('antigravity_user_specialty', $user->ID);
	$job_title = get_the_author_meta('antigravity_user_job_title', $user->ID);
	$order = get_the_author_meta('antigravity_user_order', $user->ID);
	$quote = get_the_author_meta('antigravity_user_quote', $user->ID);
	$quote_visible = get_the_author_meta('antigravity_user_quote_visible', $user->ID);
	$focus = get_the_author_meta('antigravity_user_focus', $user->ID);
	$focus_visible = get_the_author_meta('antigravity_user_focus_visible', $user->ID);
	$languages = get_the_author_meta('antigravity_user_languages', $user->ID);
	$website = get_the_author_meta('antigravity_user_website', $user->ID);
	$website_visible = get_the_author_meta('antigravity_user_website_visible', $user->ID);
	$linkedin = get_the_author_meta('antigravity_user_linkedin', $user->ID);
	$linkedin_visible = get_the_author_meta('antigravity_user_linkedin_visible', $user->ID);
	$twitter = get_the_author_meta('antigravity_user_twitter', $user->ID);
	$twitter_visible = get_the_author_meta('antigravity_user_twitter_visible', $user->ID);
	$email_visible = get_the_author_meta('antigravity_user_email_visible', $user->ID);
	$share_visible = get_the_author_meta('antigravity_user_share_visible', $user->ID);

	// Por defecto, si está vacío y hay URL, lo consideramos visible por compatibilidad con versiones anteriores
	if ($quote_visible === '' && !empty($quote)) $quote_visible = 'yes';
	if ($focus_visible === '' && !empty($focus)) $focus_visible = 'yes';
	if ($website_visible === '' && !empty($website)) $website_visible = 'yes';
	if ($linkedin_visible === '' && !empty($linkedin)) $linkedin_visible = 'yes';
	if ($twitter_visible === '' && !empty($twitter)) $twitter_visible = 'yes';
	if ($email_visible === '') $email_visible = 'yes';
	if ($share_visible === '') $share_visible = 'yes';

	?>
	<style>
		.l3-switch {
			position: relative;
			display: inline-block;
			width: 40px;
			height: 24px;
			vertical-align: middle;
			margin-left: 10px;
		}
		.l3-switch input {
			opacity: 0;
			width: 0;
			height: 0;
		}
		.l3-slider {
			position: absolute;
			cursor: pointer;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background-color: #ccc;
			transition: .4s;
			border-radius: 24px;
		}
		.l3-slider:before {
			position: absolute;
			content: "";
			height: 16px;
			width: 16px;
			left: 4px;
			bottom: 4px;
			background-color: white;
			transition: .4s;
			border-radius: 50%;
		}
		input:checked + .l3-slider {
			background-color: #2271b1;
		}
		input:checked + .l3-slider:before {
			transform: translateX(16px);
		}
		.l3-toggle-wrap {
			display: inline-flex;
			align-items: center;
			margin-left: 15px;
			font-size: 13px;
			color: #646970;
		}
	</style>
	<h3><?php _e('Información Adicional (Linea 3)', 'linea3-legal-child'); ?></h3>
	<table class="form-table">
		<tr>
			<th><label for="antigravity_user_order"><?php _e('Orden de aparición (Equipo)', 'linea3-legal-child'); ?></label></th>
			<td>
				<input type="number" name="antigravity_user_order" id="antigravity_user_order" value="<?php echo esc_attr($order); ?>" class="small-text" min="1" step="1" />
				<p class="description"><?php _e('Define el orden en la cuadrícula de equipo. Los números bajos aparecen primero (ej: 1, 2, 3). Si se deja vacío, se ordena alfabéticamente.', 'linea3-legal-child'); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_prefix"><?php _e('Prefijo Profesional', 'linea3-legal-child'); ?></label></th>
			<td>
				<?php 
				$prefixes = array(
					'' => 'Ninguno',
					'Dr.' => 'Dr.',
					'Dra.' => 'Dra.',
					'Sr.' => 'Sr.',
					'Sra.' => 'Sra.',
					'Abg.' => 'Abg.',
					'Abogado' => 'Abogado',
					'Abogada' => 'Abogada',
					'Mgtr.' => 'Mgtr.',
					'Magíster' => 'Magíster',
					'Esp.' => 'Esp.',
					'Ph.D.' => 'Ph.D.'
				);
				?>
				<select name="antigravity_user_prefix" id="antigravity_user_prefix">
					<?php foreach ($prefixes as $val => $label) : ?>
						<option value="<?php echo esc_attr($val); ?>" <?php selected($prefix, $val); ?>><?php echo esc_html($label); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description"><?php _e('Aparecerá antes del nombre del profesional.', 'linea3-legal-child'); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_job_title"><?php _e('Cargo', 'linea3-legal-child'); ?></label></th>
			<td>
				<input type="text" name="antigravity_user_job_title" id="antigravity_user_job_title" value="<?php echo esc_attr($job_title); ?>" class="regular-text" />
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_specialty"><?php _e('Especialidad', 'linea3-legal-child'); ?></label></th>
			<td>
				<input type="text" name="antigravity_user_specialty" id="antigravity_user_specialty" value="<?php echo esc_attr($specialty); ?>" class="regular-text" />
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_website"><?php _e('Sitio Web URL', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="display: flex; align-items: center; gap: 20px;">
					<input type="url" name="antigravity_user_website" id="antigravity_user_website" value="<?php echo esc_attr($website); ?>" class="regular-text" />
					<div class="l3-toggle-wrap" style="margin: 0;">
						<span style="font-size: 12px; opacity: 0.7;">Mostrar Icono:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_website_visible" value="yes" <?php checked($website_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_linkedin"><?php _e('LinkedIn URL', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="display: flex; align-items: center; gap: 20px;">
					<input type="url" name="antigravity_user_linkedin" id="antigravity_user_linkedin" value="<?php echo esc_attr($linkedin); ?>" class="regular-text" />
					<div class="l3-toggle-wrap" style="margin: 0;">
						<span style="font-size: 12px; opacity: 0.7;">Mostrar Icono:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_linkedin_visible" value="yes" <?php checked($linkedin_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_twitter"><?php _e('Twitter/X URL', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="display: flex; align-items: center; gap: 20px;">
					<input type="url" name="antigravity_user_twitter" id="antigravity_user_twitter" value="<?php echo esc_attr($twitter); ?>" class="regular-text" />
					<div class="l3-toggle-wrap" style="margin: 0;">
						<span style="font-size: 12px; opacity: 0.7;">Mostrar Icono:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_twitter_visible" value="yes" <?php checked($twitter_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_whatsapp"><?php _e('WhatsApp Number', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="display: flex; align-items: center; gap: 20px;">
					<input type="text" name="antigravity_user_whatsapp" id="antigravity_user_whatsapp" value="<?php echo esc_attr(get_the_author_meta('antigravity_user_whatsapp', $user->ID)); ?>" class="regular-text" placeholder="Ej: +573001234567" />
					<div class="l3-toggle-wrap" style="margin: 0;">
						<span style="font-size: 12px; opacity: 0.7;">Mostrar Icono:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_whatsapp_visible" value="yes" <?php checked(get_the_author_meta('antigravity_user_whatsapp_visible', $user->ID), 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<th><label><?php _e('Iconos Base', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="margin-bottom: 10px;">
					<div class="l3-toggle-wrap" style="margin-left: 0;">
						<span style="display:inline-block; width: 120px;">Icono Correo:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_email_visible" value="yes" <?php checked($email_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
				<div>
					<div class="l3-toggle-wrap" style="margin-left: 0;">
						<span style="display:inline-block; width: 120px;">Icono Compartir:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_share_visible" value="yes" <?php checked($share_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
				<p class="description">
					<?php _e('Permite ocultar el botón del formulario de contacto o el botón de compartir enlace.', 'linea3-legal-child'); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_excerpt"><?php _e('Extracto Profesional', 'linea3-legal-child'); ?></label>
			</th>
			<td>
				<textarea name="antigravity_user_excerpt" id="antigravity_user_excerpt" rows="5" cols="30" class="large-text" style="width: 25em; max-width: 100%;"><?php echo esc_textarea(get_the_author_meta('antigravity_user_excerpt', $user->ID)); ?></textarea>
				<p class="description">
					<?php _e('Breve descripción que aparece en la tarjeta del profesional.', 'linea3-legal-child'); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_quote"><?php _e('Cita Destacada', 'linea3-legal-child'); ?></label></th>
			<td>
				<div style="display: flex; align-items: center; gap: 20px;">
					<input type="text" name="antigravity_user_quote" id="antigravity_user_quote" value="<?php echo esc_attr($quote); ?>" class="regular-text" />
					<div class="l3-toggle-wrap" style="margin: 0;">
						<span style="font-size: 12px; opacity: 0.7;">Mostrar Cita:</span>
						<label class="l3-switch">
							<input type="checkbox" name="antigravity_user_quote_visible" value="yes" <?php checked($quote_visible, 'yes'); ?>>
							<span class="l3-slider"></span>
						</label>
					</div>
				</div>
				<p class="description"><?php _e('Ej: "La excelencia jurídica no es un acto..."', 'linea3-legal-child'); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_focus"><?php _e('Enfoque Principal', 'linea3-legal-child'); ?></label></th>
			<td>
				<textarea name="antigravity_user_focus" id="antigravity_user_focus" rows="3" cols="30" class="large-text" style="width: 25em; max-width: 100%;"><?php echo esc_textarea($focus); ?></textarea>
				<div class="l3-toggle-wrap" style="margin-top: 10px;">
					<span style="font-size: 12px; opacity: 0.7;">Mostrar Enfoque:</span>
					<label class="l3-switch">
						<input type="checkbox" name="antigravity_user_focus_visible" value="yes" <?php checked($focus_visible, 'yes'); ?>>
						<span class="l3-slider"></span>
					</label>
				</div>
				<p class="description"><?php _e('Ej: Litigios de Alta Complejidad', 'linea3-legal-child'); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="antigravity_user_languages"><?php _e('Idiomas', 'linea3-legal-child'); ?></label></th>
			<td>
				<textarea name="antigravity_user_languages" id="antigravity_user_languages" rows="3" cols="30" class="large-text" style="width: 25em; max-width: 100%;"><?php echo esc_textarea($languages); ?></textarea>
				<div class="l3-toggle-wrap" style="margin-top: 10px;">
					<span style="font-size: 12px; opacity: 0.7;">Mostrar Idiomas:</span>
					<label class="l3-switch">
						<input type="checkbox" name="antigravity_user_languages_visible" value="yes" <?php checked(get_the_author_meta('antigravity_user_languages_visible', $user->ID), 'yes'); ?>>
						<span class="l3-slider"></span>
					</label>
				</div>
				<p class="description"><?php _e('Uno por línea. Ej: Español (Nativo)', 'linea3-legal-child'); ?> \n <?php _e('Inglés (Avanzado)', 'linea3-legal-child'); ?></p>
			</td>
		</tr>
	</table>
	<?php
}
add_action('show_user_profile', 'antigravity_show_extra_profile_fields');
add_action('edit_user_profile', 'antigravity_show_extra_profile_fields');

/**
 * Guarda los campos adicionales del perfil
 */
function antigravity_save_extra_profile_fields($user_id)
{
	if (!current_user_can('edit_user', $user_id)) {
		return false;
	}
	
	$fields = array(
		'antigravity_user_prefix',
		'antigravity_user_excerpt',
		'antigravity_user_job_title',
		'antigravity_user_specialty',
		'antigravity_user_order',
		'antigravity_user_quote',
		'antigravity_user_focus',
		'antigravity_user_languages',
		'antigravity_user_website',
		'antigravity_user_linkedin',
		'antigravity_user_twitter',
		'antigravity_user_whatsapp'
	);
	
	foreach ($fields as $field) {
		if (isset($_POST[$field])) {
			update_user_meta($user_id, $field, sanitize_textarea_field($_POST[$field]));
		}
	}

	// Toggles (checkboxes: si no están en $_POST, significa que fueron desmarcados)
	$quote_visible = isset($_POST['antigravity_user_quote_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_quote_visible', $quote_visible);

	$focus_visible = isset($_POST['antigravity_user_focus_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_focus_visible', $focus_visible);

	$website_visible = isset($_POST['antigravity_user_website_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_website_visible', $website_visible);

	$languages_visible = isset($_POST['antigravity_user_languages_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_languages_visible', $languages_visible);

	$linkedin_visible = isset($_POST['antigravity_user_linkedin_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_linkedin_visible', $linkedin_visible);

	$twitter_visible = isset($_POST['antigravity_user_twitter_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_twitter_visible', $twitter_visible);

	$email_visible = isset($_POST['antigravity_user_email_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_email_visible', $email_visible);

	$share_visible = isset($_POST['antigravity_user_share_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_share_visible', $share_visible);

	$whatsapp_visible = isset($_POST['antigravity_user_whatsapp_visible']) ? 'yes' : 'no';
	update_user_meta($user_id, 'antigravity_user_whatsapp_visible', $whatsapp_visible);
}
add_action('personal_options_update', 'antigravity_save_extra_profile_fields');
add_action('edit_user_profile_update', 'antigravity_save_extra_profile_fields');

/**
 * Añade la columna "Orden" a la tabla de usuarios
 */
function antigravity_add_user_order_column($columns) {
    $new_columns = array();
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key === 'name') {
            $new_columns['user_order'] = __('Orden', 'linea3-legal-child');
        }
    }
    return $new_columns;
}
add_filter('manage_users_columns', 'antigravity_add_user_order_column', 20);

/**
 * Muestra el valor del orden en la columna de la tabla de usuarios
 */
function antigravity_show_user_order_column_value($value, $column_name, $user_id) {
    if ('user_order' === $column_name) {
        $order = get_the_author_meta('antigravity_user_order', $user_id);
        return !empty($order) ? '<strong>' . esc_html($order) . '</strong>' : '<span style="opacity:0.3">—</span>';
    }
    return $value;
}
add_filter('manage_users_custom_column', 'antigravity_show_user_order_column_value', 20, 3);

/**
 * Hace que la columna "Orden" sea ordenable
 */
function antigravity_make_user_order_column_sortable($columns) {
    $columns['user_order'] = 'antigravity_user_order';
    return $columns;
}
add_filter('manage_users_sortable_columns', 'antigravity_make_user_order_column_sortable');

/**
 * Maneja la lógica de ordenación por el campo meta
 */
function antigravity_user_order_column_orderby($query) {
    if (!is_admin()) return;
    
    $orderby = $query->get('orderby');
    if ('antigravity_user_order' === $orderby) {
        $query->set('meta_key', 'antigravity_user_order');
        $query->set('orderby', 'meta_value_num');
    }
}
add_action('pre_get_users', 'antigravity_user_order_column_orderby');

/**
 * Helper para obtener el HTML de la tarjeta de autor.
 */
function antigravity_get_author_card_html(int $author_id, int $post_id = 0): string
{
	if (!$author_id)
		return '';

	// Si no hay post_id pero estamos en un post individual, intentamos obtenerlo del global
	if (!$post_id && is_singular('post')) {
		$post_id = get_the_ID();
	}

	$avatar_url = get_avatar_url($author_id, array('size' => 120));
	$name = get_the_author_meta('display_name', $author_id);
	$prefix = get_the_author_meta('antigravity_user_prefix', $author_id);

	if (!empty($prefix)) {
		$name = $prefix . ' ' . $name;
	}

	$specialty = get_the_author_meta('antigravity_user_specialty', $author_id);
	$meta_html = '';

	if ($post_id > 0) {
		$date = get_the_date('', $post_id);
		$content = get_post_field('post_content', $post_id);
		$word_count = str_word_count(strip_tags($content));
		$reading_time = max(1, ceil($word_count / 200));
		$meta_html = sprintf('<span class="author-post-meta">%s — %d min de lectura</span>', esc_html($date), $reading_time);
	}

	$author_url = get_author_posts_url($author_id);

	return sprintf(
		'<a href="%s" class="antigravity-author-card"><div class="author-avatar-wrapper"><img src="%s" alt="%s" class="author-avatar" width="500" height="500" /></div><div class="author-data-wrapper"><span class="author-name">%s</span>%s%s</div></a>',
		esc_url($author_url),
		esc_url($avatar_url),
		esc_attr($name),
		esc_html($name),
		(!empty($specialty) ? sprintf('<span class="author-specialty">%s</span>', esc_html($specialty)) : ''),
		$meta_html
	);
}


/**
 * Renderizado de tarjeta de autor para bloques.
 */
function antigravity_render_author_card($attributes, $content, $block): string
{
	if (!isset($block->context['postId']))
		return '';
	return antigravity_get_author_card_html((int) get_post_field('post_author', $block->context['postId']), $block->context['postId']);
}

/**
 * Shortcode para el Cuadro de Autor en Entradas Individuales (Retrocompatibilidad).
 */
function antigravity_post_author_box_shortcode()
{
	global $post;
	$author_id = (int) get_the_author_meta('ID');
	if (!$author_id && $post) {
		$author_id = (int) $post->post_author;
	}
	if (!$author_id)
		return '';

	$html = antigravity_get_author_card_html($author_id, $post ? $post->ID : 0);
	
	// Condicional de extracto manual
	$author_class = 'single-post-author-box';
	if (has_excerpt($post ? $post->ID : 0)) {
		$author_class .= ' has-divider-top';
	}

	// Añadimos las clases para asegurar compatibilidad con estilos específicos de single post
	$html = str_replace('antigravity-author-card', 'antigravity-author-card ' . $author_class, $html);
	
	// Envolvemos en un div contenedor y eliminamos saltos de línea para evitar que wpautop inyecte etiquetas <p> y rompa el tag <a>
	return '<div class="antigravity-author-box-wrapper">' . preg_replace('/>\s+</', '><', str_replace(array("\r", "\n"), '', $html)) . '</div>';
}
add_shortcode('antigravity_post_author_box', 'antigravity_post_author_box_shortcode');

/**
 * Filtro dinámico de bloques para ocultar el extracto autogenerado en posts que no tienen extracto manual.
 */
add_filter('render_block', function ($block_content, $block) {
	if (is_singular('post') && 'core/post-excerpt' === $block['blockName']) {
		if (!has_excerpt()) {
			return ''; // Si no hay extracto manual, no pintamos el bloque en absoluto
		}
	}
	return $block_content;
}, 10, 2);

/**
 * Limpieza de etiquetas <p> inyectadas por wpautop en el bloque de shortcode del autor.
 */
add_filter('render_block', function ($block_content, $block) {
	if ('core/shortcode' === $block['blockName'] && (strpos($block_content, 'antigravity-author-box-wrapper') !== false || strpos($block_content, 'related-posts-section') !== false)) {
		return preg_replace('/<\/?p[^>]*>/i', '', $block_content);
	}
	return $block_content;
}, 99, 2);

/**
 * Renderizado de Publicaciones Relacionadas.
 */
/**
 * Helper function to render the related posts section.
 */
function antigravity_get_related_posts_html($author_id, $current_post_id = 0) {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 3,
        'author' => $author_id,
        'orderby' => 'date',
        'order' => 'DESC'
    );
    if ($current_post_id) {
        $args['post__not_in'] = array($current_post_id);
    }
    
    $posts = get_posts($args);
    if (empty($posts)) return '';

    $author_posts_url = get_author_posts_url($author_id);
    $output = '<!-- ANTIGRAVITY_START --><section class="related-posts-section"><div class="related-posts-header"><div class="section-vertical-line"></div><div class="related-header-content"><div class="related-header-top"><span class="related-subtitle">MÁS DEL MISMO AUTOR</span><a href="' . esc_url($author_posts_url) . '" class="view-all-link">Ver todas sus publicaciones</a></div><div class="related-header-main"><h2 class="related-title">Publicaciones Relacionadas</h2></div></div></div><div class="blog-listing-wrapper"><div class="antigravity-grid is-layout-grid columns-3">';
    foreach ($posts as $p) {
		$cat_list = get_the_term_list($p->ID, 'category', '', ' ', '');
		$cat_html = !empty($cat_list) ? sprintf('<div class="wp-block-post-terms">%s</div>', $cat_list) : '';
        $output .= sprintf('<div class="antigravity-card" onclick="window.location=\'%s\'"><article class="wp-block-group"><div class="wp-block-post-featured-image">%s</div><div class="antigravity-card-content">%s<h3 class="wp-block-post-title">%s</h3>%s</div></article></div>', get_permalink($p->ID), antigravity_get_post_thumbnail_html($p->ID, 'medium_large', array('class' => 'related-post-img')), $cat_html, get_the_title($p->ID), antigravity_get_author_card_html($author_id, $p->ID));
    }
    $output .= '</div></div></section><!-- ANTIGRAVITY_END -->';
    return preg_replace('/>\s+</', '><', $output);
}

/**
 * Renderizado de Publicaciones Relacionadas.
 */
function antigravity_related_posts_shortcode()
{
	if (!is_singular('post'))
		return '';
	$author_id = (int) get_post_field('post_author', get_the_ID());
	return antigravity_get_related_posts_html($author_id, get_the_ID());
}
add_shortcode('antigravity_related_posts', 'antigravity_related_posts_shortcode');

/**
 * Renderizado de la cuadrícula de equipo (Nuestro Cuerpo Jurídico).
 */
function antigravity_render_team_grid($attributes): string
{
	// Filtrar usuarios activos con rol 'author'.
	$args = array(
		'role__in' => array('author'),
		'fields'   => 'all',
	);

	$users = get_users($args);

	// Ordenación personalizada: Prioriza el campo 'antigravity_user_order', luego alfabético
	usort($users, function ($a, $b) {
		$order_a = get_the_author_meta('antigravity_user_order', $a->ID);
		$order_b = get_the_author_meta('antigravity_user_order', $b->ID);

		// Si ambos tienen orden, comparar por orden
		$val_a = ($order_a !== '') ? (int)$order_a : 999;
		$val_b = ($order_b !== '') ? (int)$order_b : 999;

		if ($val_a !== $val_b) {
			return $val_a - $val_b;
		}

		// Si el orden es igual o no tienen, comparar por nombre
		return strcasecmp($a->display_name, $b->display_name);
	});

	// Inyectamos el Header directamente en el renderizado dinámico para asegurar su presencia
	$output = '<div class="antigravity-team-section">';

	$output .= '<div class="team-section-header">';
	$output .= '<div class="section-vertical-line"></div>';
	$output .= '<div class="team-header-content">';
	$output .= '<div class="team-header-left">';
	$output .= '<h2 class="team-title">' . esc_html__('Equipo Jurídico', 'linea3-legal-child') . '</h2>';
	$output .= '<p class="team-subtitle">' . esc_html__('LIDERAZGO Y ESTRATEGIA', 'linea3-legal-child') . '</p>';
	$output .= '</div>';
	$output .= '<div class="team-header-right">';
	$output .= '<p class="team-corporate-phrase">' . esc_html__('“La justicia no es solo una norma, es la arquitectura de una sociedad estable.”', 'linea3-legal-child') . '</p>';
	$output .= '</div>';
	$output .= '</div>'; // .team-header-content
	$output .= '</div>'; // .team-section-header

	if (empty($users)) {
		$output .= '<p class="linea3-team-empty">' . esc_html__('No hay profesionales disponibles para mostrar.', 'linea3-legal-child') . '</p>';
		$output .= '</div>';
		return $output;
	}

	$output .= '<div class="linea3-team-grid">';

	foreach ($users as $user) {
		$user_id = $user->ID;
		// Usamos un tamaño generoso para avatars ya que WP no soporta crop personalizado en get_avatar directamente sin plugins
		$avatar_url = get_avatar_url($user_id, array('size' => 1000));
		$name = $user->display_name;
		$specialty = get_the_author_meta('antigravity_user_specialty', $user_id);
		$job_title = get_the_author_meta('antigravity_user_job_title', $user_id);
		$linkedin = get_the_author_meta('antigravity_user_linkedin', $user_id);
		$twitter = get_the_author_meta('antigravity_user_twitter', $user_id);

		$output .= '<div class="linea3-team-card">';

		$author_url = get_author_posts_url($user_id);
		
		// Imagen (Cuadrada/Rectangular con padding CSS)
		$output .= '<div class="linea3-team-card-image-wrap">';
		$output .= '<a href="' . esc_url($author_url) . '">';
		$output .= sprintf(
			'<img src="%s" alt="%s" class="linea3-team-card-image" width="800" height="1000" />',
			esc_url($avatar_url),
			esc_attr($name)
		);
		$output .= '</a>';
		$output .= '</div>';

		// Contenido interno alineado a la izquierda
		$output .= '<div class="linea3-team-card-content">';

		if (!empty($job_title)) {
			$output .= sprintf('<p class="linea3-team-job-title">%s</p>', esc_html($job_title));
		}

		$prefix = get_the_author_meta('antigravity_user_prefix', $user_id);
		$display_name = !empty($prefix) ? $prefix . ' ' . $name : $name;
		$output .= sprintf('<h3 class="linea3-team-name"><a href="%s" style="color:inherit; text-decoration:none;">%s</a></h3>', esc_url($author_url), esc_html($display_name));

		if (!empty($specialty)) {
			$output .= sprintf('<p class="linea3-team-specialty">%s</p>', esc_html($specialty));
		}

		$website = get_the_author_meta('antigravity_user_website', $user_id);
		$linkedin = get_the_author_meta('antigravity_user_linkedin', $user_id);
		$twitter = get_the_author_meta('antigravity_user_twitter', $user_id);

		$website_visible = get_the_author_meta('antigravity_user_website_visible', $user_id);
		$linkedin_visible = get_the_author_meta('antigravity_user_linkedin_visible', $user_id);
		$twitter_visible = get_the_author_meta('antigravity_user_twitter_visible', $user_id);
		$email_visible = get_the_author_meta('antigravity_user_email_visible', $user_id);
		$share_visible = get_the_author_meta('antigravity_user_share_visible', $user_id);

		// Retrocompatibilidad: Si el valor de visibilidad nunca se guardó, se muestra
		if ($website_visible === '' && !empty($website)) $website_visible = 'yes';
		if ($linkedin_visible === '' && !empty($linkedin)) $linkedin_visible = 'yes';
		if ($twitter_visible === '' && !empty($twitter)) $twitter_visible = 'yes';
		if ($email_visible === '') $email_visible = 'yes';
		if ($share_visible === '') $share_visible = 'yes';

		$output .= '<div class="linea3-team-socials">';
		$output .= '<div class="linea3-team-social-icons">';

		if ($share_visible === 'yes') {
			$output .= sprintf(
				'<a href="#" class="linea3-team-icon-share l3-share-profile-btn" data-share-url="%s" data-share-title="%s" aria-label="Compartir perfil de %s"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg></a>',
				esc_url($author_url),
				esc_attr(sprintf('Perfil Profesional — %s', $display_name)),
				esc_attr($display_name)
			);
		}

		if (!empty($user->user_email) && $email_visible === 'yes') {
			// Se reemplaza el enlace mailto para evitar exponer el correo electrónico
			$output .= sprintf('<a href="#" class="linea3-team-icon-email linea3-team-contact-btn" data-author-id="%d" data-author-name="%s" data-author-image="%s" aria-label="Contactar a %s"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg></a>', $user_id, esc_attr($name), esc_url($avatar_url), esc_attr($name));
		}

		if (!empty($website) && $website_visible === 'yes') {
			$output .= sprintf('<a href="%s" target="_blank" rel="noopener noreferrer" class="linea3-team-icon-website" aria-label="Sitio Web"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></a>', esc_url($website));
		}

		if (!empty($linkedin) && $linkedin_visible === 'yes') {
			$output .= sprintf('<a href="%s" target="_blank" rel="noopener noreferrer" class="linea3-team-icon-linkedin" aria-label="LinkedIn"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></a>', esc_url($linkedin));
		}

		if (!empty($twitter) && $twitter_visible === 'yes') {
			$output .= sprintf('<a href="%s" target="_blank" rel="noopener noreferrer" class="linea3-team-icon-twitter" aria-label="Twitter"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg></a>', esc_url($twitter));
		}

		$output .= '</div>';
		$output .= '</div>';

		$output .= '</div>';
		$output .= '</div>';
	}

	$output .= '</div>'; // .linea3-team-grid
	$output .= '</div>'; // .antigravity-team-section

	return $output;
}
add_shortcode('antigravity_team_grid', 'antigravity_render_team_grid');

/**
 * Columnas personalizadas en el Admin.
 */
function antigravity_add_posts_columns($columns)
{
	$columns['featured_image'] = 'Imagen';
	$columns['has_excerpt'] = 'Extracto';
	return $columns;
}
add_filter('manage_post_posts_columns', 'antigravity_add_posts_columns');
add_filter('manage_servicio_posts_columns', 'antigravity_add_posts_columns');
function antigravity_render_posts_columns($column, $post_id)
{
	if ($column === 'featured_image')
		echo get_the_post_thumbnail($post_id, array(50, 50));
	if ($column === 'has_excerpt')
		echo has_excerpt($post_id) ? '✔' : '✖';
}
add_action('manage_post_posts_custom_column', 'antigravity_render_posts_columns', 10, 2);
add_action('manage_servicio_posts_custom_column', 'antigravity_render_posts_columns', 10, 2);

add_action('after_setup_theme', function() {
    add_image_size('l3_sede_thumb', 800, 500, true);
});

/**
 * Agrega CSS al panel de administración para corregir el tamaño de las imágenes en las columnas.
 */
function antigravity_admin_columns_css() {
    $screen = get_current_screen();
    if ($screen && $screen->base === 'edit' && ($screen->post_type === 'post' || $screen->post_type === 'servicio')) {
        echo '<style>
            .column-featured_image { width: 70px !important; }
            .column-featured_image img {
                width: 50px !important;
                height: 50px !important;
                object-fit: cover;
                border-radius: 4px;
                display: block;
                margin: 0 auto;
                background-color: #f0f0f0;
            }
        </style>';
    }
}
add_action('admin_head', 'antigravity_admin_columns_css');

/**
 * Renderizado de Publicaciones Destacadas.
 */
function antigravity_render_featured_posts_grid(): string
{
	$posts = get_posts(array('post_type' => 'post', 'posts_per_page' => 5, 'orderby' => 'date', 'order' => 'DESC'));
	if (empty($posts))
		return '';
	$output = '<!-- ANTIGRAVITY_START --><section class="antigravity-featured-posts-grid"><div class="featured-posts-container l3-container-standard"><div class="featured-posts-header"><div class="section-vertical-line"></div><div class="featured-header-left"><span class="featured-eyebrow">Publicaciones de los expertos de nuestro equipo</span><h2 class="featured-title">Publicaciones Destacadas</h2><p class="featured-description">Especialización de alto nivel para blindar cada aspecto de tu organización.</p></div><div class="featured-header-right"><a href="' . esc_url(get_permalink(get_option('page_for_posts'))) . '" class="view-all-link">Ver todas</a></div></div><div class="antigravity-grid">';
	foreach ($posts as $p) {
		$cat = get_the_category($p->ID);
		$cat_html = !empty($cat) ? sprintf('<span class="featured-card-category">%s</span>', esc_html($cat[0]->name)) : '';
		$thumb_id = get_post_thumbnail_id($p->ID);
		$thumb_img = wp_get_attachment_image($thumb_id, 'l3-blog-card', false, array('class' => 'featured-card-image'));
		if (empty($thumb_img)) {
			$placeholder_url = get_stylesheet_directory_uri() . '/assets/images/placeholder-legal.png';
			$thumb_img = sprintf('<img src="%s" alt="%s" class="featured-card-image" width="600" height="400">', esc_url($placeholder_url), esc_attr($p->post_title));
		}
		$author_id = (int) $p->post_author;
		$output .= sprintf('<div class="antigravity-card" onclick="window.location=\'%s\'"><div class="featured-card-image-wrap">%s</div><div class="featured-card-overlay"></div><div class="featured-card-content"><div class="featured-card-meta">%s<h3 class="featured-card-title">%s</h3></div><div class="featured-card-author">%s</div><div class="featured-card-accent-line"></div></div></div>', get_permalink($p->ID), $thumb_img, $cat_html, esc_html($p->post_title), antigravity_get_author_card_html($author_id, $p->ID));
	}
	return $output . '</div></div></section><!-- ANTIGRAVITY_END -->';
}
add_shortcode('antigravity_featured_posts', 'antigravity_render_featured_posts_grid');

/**
 * MASTER CLEANER: Elimina párrafos y saltos de línea inyectados.
 */
add_filter('the_content', function ($content) {
	$content = preg_replace_callback('/<!-- ANTIGRAVITY_START -->(.*?)<!-- ANTIGRAVITY_END -->/is', function ($m) {
		return preg_replace('/<\/?p[^>]*>|<br\s*\/?>/i', '', $m[1]);
	}, $content);
	$content = preg_replace('/<p[^>]*>\s*<!-- ANTIGRAVITY_START -->/i', '<!-- ANTIGRAVITY_START -->', $content);
	$content = preg_replace('/<!-- ANTIGRAVITY_END -->\s*<\/p>/i', '<!-- ANTIGRAVITY_END -->', $content);
	return $content;
}, 9999);

/**
 * Desactivar wpautop en la página frontal.
 */
add_action('wp', function () {
	if (is_front_page())
		remove_filter('the_content', 'wpautop');
});

/**
 * Agrega el favicon del sitio desde los assets del tema.
 */
function linea3_legal_child_favicon() {
	$favicon_url = get_stylesheet_directory_uri() . '/assets/images/logo-favicon.png';
	echo '<link rel="icon" href="' . esc_url($favicon_url) . '" type="image/png" />' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url($favicon_url) . '" />' . "\n";
}
add_action('wp_head', 'linea3_legal_child_favicon');
add_action('admin_head', 'linea3_legal_child_favicon');

/**
 * Registrar Custom Post Type: Servicios
 */
function antigravity_register_servicios_cpt() {
    $labels = array(
        'name'                  => _x('Servicios', 'Post Type General Name', 'linea3-legal-child'),
        'singular_name'         => _x('Servicio', 'Post Type Singular Name', 'linea3-legal-child'),
        'menu_name'             => __('Servicios', 'linea3-legal-child'),
        'name_admin_bar'        => __('Servicio', 'linea3-legal-child'),
        'archives'              => __('Archivo de Servicios', 'linea3-legal-child'),
        'attributes'            => __('Atributos del Servicio', 'linea3-legal-child'),
        'parent_item_colon'     => __('Servicio Padre:', 'linea3-legal-child'),
        'all_items'             => __('Todos los servicios', 'linea3-legal-child'),
        'add_new_item'          => __('Añadir nuevo servicio', 'linea3-legal-child'),
        'add_new'               => __('Añadir nuevo', 'linea3-legal-child'),
        'new_item'              => __('Nuevo servicio', 'linea3-legal-child'),
        'edit_item'             => __('Editar servicio', 'linea3-legal-child'),
        'update_item'           => __('Actualizar servicio', 'linea3-legal-child'),
        'view_item'             => __('Ver servicio', 'linea3-legal-child'),
        'view_items'            => __('Ver servicios', 'linea3-legal-child'),
        'search_items'          => __('Buscar servicio', 'linea3-legal-child'),
        'not_found'             => __('No encontrado', 'linea3-legal-child'),
        'not_found_in_trash'    => __('No encontrado en la papelera', 'linea3-legal-child'),
        'featured_image'        => __('Imagen de fondo (Cover)', 'linea3-legal-child'),
        'set_featured_image'    => __('Asignar imagen de fondo', 'linea3-legal-child'),
        'remove_featured_image' => __('Quitar imagen de fondo', 'linea3-legal-child'),
        'use_featured_image'    => __('Usar como imagen de fondo', 'linea3-legal-child'),
        'insert_into_item'      => __('Insertar en servicio', 'linea3-legal-child'),
        'uploaded_to_this_item' => __('Subido a este servicio', 'linea3-legal-child'),
        'items_list'            => __('Lista de servicios', 'linea3-legal-child'),
        'items_list_navigation' => __('Navegación de lista de servicios', 'linea3-legal-child'),
        'filter_items_list'     => __('Filtrar lista de servicios', 'linea3-legal-child'),
    );
    $args = array(
        'label'                 => __('Servicio', 'linea3-legal-child'),
        'description'           => __('Servicios legales ofrecidos', 'linea3-legal-child'),
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 21,
        'menu_icon'             => 'dashicons-portfolio',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
        'show_in_rest'          => true, // Habilita Gutenberg
    );
    register_post_type('servicio', $args);
}
add_action('init', 'antigravity_register_servicios_cpt', 0);

/**
 * Añadir Metabox para el Ícono del Servicio
 */
function antigravity_add_servicio_icon_metabox() {
    add_meta_box(
        'antigravity_servicio_icon',
        __('Ícono del Servicio', 'linea3-legal-child'),
        'antigravity_render_servicio_icon_metabox',
        'servicio',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'antigravity_add_servicio_icon_metabox');

function antigravity_render_servicio_icon_metabox($post) {
    wp_nonce_field('antigravity_save_servicio_icon', 'antigravity_servicio_icon_nonce');
    $icon_id = get_post_meta($post->ID, '_servicio_icon_id', true);
    $icon_url = $icon_id ? wp_get_attachment_image_url($icon_id, 'thumbnail') : '';
    
    echo '<div class="antigravity-icon-wrapper" style="text-align:center;">';
    if ($icon_url) {
        echo '<img id="antigravity-icon-preview" src="' . esc_url($icon_url) . '" style="max-width:100%; height:auto; margin-bottom:15px;" />';
    } else {
        echo '<img id="antigravity-icon-preview" src="" style="max-width:100%; height:auto; margin-bottom:15px; display:none;" />';
    }
    echo '<input type="hidden" id="antigravity_servicio_icon_id" name="antigravity_servicio_icon_id" value="' . esc_attr($icon_id) . '" />';
    echo '<button type="button" class="button" id="antigravity-upload-icon-btn">' . __('Seleccionar / Subir Ícono', 'linea3-legal-child') . '</button>';
    echo '<button type="button" class="button" id="antigravity-remove-icon-btn" style="color:red; margin-top:5px; ' . ($icon_id ? '' : 'display:none;') . '">' . __('Quitar Ícono', 'linea3-legal-child') . '</button>';
    echo '</div>';
    
    // Script nativo de WordPress Media Uploader
    ?>
    <script>
    jQuery(document).ready(function($){
        var frame;
        $('#antigravity-upload-icon-btn').on('click', function(e) {
            e.preventDefault();
            if (frame) {
                frame.open();
                return;
            }
            frame = wp.media({
                title: 'Seleccionar o subir ícono',
                button: { text: 'Usar este ícono' },
                multiple: false
            });
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                $('#antigravity-icon-preview').attr('src', attachment.url).show();
                $('#antigravity_servicio_icon_id').val(attachment.id);
                $('#antigravity-remove-icon-btn').show();
            });
            frame.open();
        });
        
        $('#antigravity-remove-icon-btn').on('click', function(e) {
            e.preventDefault();
            $('#antigravity-icon-preview').attr('src', '').hide();
            $('#antigravity_servicio_icon_id').val('');
            $(this).hide();
        });
    });
    </script>
    <?php
}

function antigravity_save_servicio_icon($post_id) {
    if (!isset($_POST['antigravity_servicio_icon_nonce']) || !wp_verify_nonce($_POST['antigravity_servicio_icon_nonce'], 'antigravity_save_servicio_icon')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    if (isset($_POST['antigravity_servicio_icon_id'])) {
        update_post_meta($post_id, '_servicio_icon_id', sanitize_text_field($_POST['antigravity_servicio_icon_id']));
    }
}
add_action('save_post', 'antigravity_save_servicio_icon');

// Script para encolar medios en admin si no están encolados (para CPT servicio)
function antigravity_enqueue_media_uploader($hook) {
    global $typenow;
    if ($typenow == 'servicio') {
        wp_enqueue_media();
    }
}
add_action('admin_enqueue_scripts', 'antigravity_enqueue_media_uploader');

/**
 * Shortcode Dinámico para Cuadrícula de Servicios
 */
function antigravity_services_grid_shortcode($atts) {
    $atts = shortcode_atts(array(
        'orderby' => 'date', // Puede ser 'date' o 'title'
        'order'   => 'ASC',  // Si es date es ASC (los primeros creados primero), si title es A-Z
    ), $atts);

    $args = array(
        'post_type'      => 'servicio',
        'posts_per_page' => -1, // Mostrar todos
        'orderby'        => $atts['orderby'],
    );
    
    if ($atts['orderby'] === 'title') {
        $args['order'] = isset($atts['order']) ? $atts['order'] : 'ASC';
    } else {
        $args['order'] = isset($atts['order']) ? $atts['order'] : 'ASC'; // Mostrar en el orden en que se van añadiendo
    }

    $query = new WP_Query($args);

    // Contenedor principal de la cuadrícula
    $output = '<!-- ANTIGRAVITY_START --><div class="wp-block-group l3-services-grid">';

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            // Recoger datos
            $title = get_the_title();
            $permalink = get_permalink();
            // Para el contenido, usamos the_excerpt si existe, sino el content cortado.
            $excerpt = has_excerpt() ? get_the_excerpt() : wp_trim_words(get_the_content(), 25);
            $bg_image_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
            // Imagen por defecto si no hay destacada
            if (!$bg_image_url) {
                $bg_image_url = get_stylesheet_directory_uri() . '/assets/images/placeholder-legal.png'; 
            }
            
            // Si hay un icono guardado
            $icon_id = get_post_meta(get_the_ID(), '_servicio_icon_id', true);
            $icon_html = '';
            if ($icon_id) {
                $icon_img = wp_get_attachment_image($icon_id, 'thumbnail', false, array('class' => 'service-icon'));
                if ($icon_img) {
                    $icon_html = $icon_img;
                }
            }

            // HTML de la tarjeta basado en el patrón creado
            $output .= '<div class="wp-block-cover l3-service-card">';
            $output .= '<span aria-hidden="true" class="wp-block-cover__background has-base-background-color has-background-dim-80 has-background-dim"></span>';
            $thumb_id = get_post_thumbnail_id(get_the_ID());
            $bg_img = wp_get_attachment_image($thumb_id, 'l3-blog-card', false, array('class' => 'wp-block-cover__image-background', 'data-object-fit' => 'cover'));
            if (empty($bg_img)) {
                $placeholder_url = get_stylesheet_directory_uri() . '/assets/images/placeholder-legal.png';
                $bg_img = sprintf('<img class="wp-block-cover__image-background" alt="" src="%s" data-object-fit="cover" width="600" height="400" />', esc_url($placeholder_url));
            }
            $output .= $bg_img;
            
            $output .= '<div class="wp-block-cover__inner-container">';
            $output .= '<div class="wp-block-group">';
            if ($icon_html) {
                $output .= $icon_html;
            }
            $output .= '<h3 class="wp-block-heading">' . esc_html($title) . '</h3>';
            $output .= '<div class="service-excerpt">' . esc_html($excerpt) . '</div>';
            $output .= '</div>'; // /wp-block-group
            
            $output .= '</div>'; // /wp-block-cover__inner-container
            $output .= '</div>'; // /wp-block-cover
        }
        wp_reset_postdata();
    } else {
        $output .= '<p>No se han registrado servicios todavía. <a href="' . esc_url(admin_url('post-new.php?post_type=servicio')) . '">Añadir el primero.</a></p>';
    }

    $output .= '</div><!-- ANTIGRAVITY_END -->';
    return $output;
}
add_shortcode('antigravity_services_grid', 'antigravity_services_grid_shortcode');

/**
 * Habilitar soporte para subir archivos SVG de forma segura
 */
function l3_allow_svg_upload($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'l3_allow_svg_upload');

function l3_fix_svg_mime_type($data, $file, $filename, $mimes) {
    $ext = isset($data['ext']) ? $data['ext'] : '';
    if (strlen($ext) < 1) {
        $exploded = explode('.', $filename);
        $ext = strtolower(end($exploded));
    }
    if ($ext === 'svg') {
        $data['type'] = 'image/svg+xml';
        $data['ext'] = 'svg';
    }
    return $data;
}
add_filter('wp_check_filetype_and_ext', 'l3_fix_svg_mime_type', 10, 4);

/**
 * Opciones de Página: Ocultar Título
 */
add_action('init', 'linea3_legal_register_page_meta');
function linea3_legal_register_page_meta() {
    register_post_meta('page', '_linea3_hide_title', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'boolean',
    ));
}

add_action('add_meta_boxes', 'linea3_legal_add_page_options_meta_box');
function linea3_legal_add_page_options_meta_box() {
    add_meta_box(
        'linea3_page_options',
        'Opciones de Visualización',
        'linea3_legal_page_options_html',
        'page',
        'side',
        'low'
    );
}

function linea3_legal_page_options_html($post) {
    $hide_title = get_post_meta($post->ID, '_linea3_hide_title', true);
    wp_nonce_field('linea3_page_options_nonce', 'linea3_page_options_nonce_field');
    ?>
    <p>
        <label>
            <input type="checkbox" name="linea3_hide_title" value="1" <?php checked($hide_title, 1); ?>>
            Ocultar el título de esta página
        </label>
    </p>
    <?php
}

add_action('save_post', 'linea3_legal_save_page_options');
function linea3_legal_save_page_options($post_id) {
    if (!isset($_POST['linea3_page_options_nonce_field']) || !wp_verify_nonce($_POST['linea3_page_options_nonce_field'], 'linea3_page_options_nonce')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_page', $post_id)) return;

    if (isset($_POST['linea3_hide_title'])) {
        update_post_meta($post_id, '_linea3_hide_title', 1);
    } else {
        delete_post_meta($post_id, '_linea3_hide_title');
    }
}

// Inyectar CSS para ocultar el título si la opción está activa
add_action('wp_head', 'linea3_legal_hide_title_css');
function linea3_legal_hide_title_css() {
    if (is_page() && get_post_meta(get_the_ID(), '_linea3_hide_title', true)) {
        echo '<style>.wp-block-post-title { display: none !important; }</style>';
    }
}

/**
 * Registro de Custom Post Type: Clientes.
 */
function l3_register_aliados_cpt(): void
{
	$labels = array(
		'name'                  => 'Clientes',
		'singular_name'         => 'Cliente',
		'menu_name'             => 'Clientes',
		'name_admin_bar'        => 'Cliente',
		'add_new'               => 'Añadir Nuevo',
		'add_new_item'          => 'Añadir Nuevo Cliente',
		'new_item'              => 'Nuevo Cliente',
		'edit_item'             => 'Editar Cliente',
		'view_item'             => 'Ver Cliente',
		'all_items'             => 'Todos los Clientes',
		'search_items'          => 'Buscar Clientes',
		'not_found'             => 'No se encontraron clientes.',
		'not_found_in_trash'    => 'No hay clientes en la papelera.',
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'aliado'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon'          => 'dashicons-groups',
		'supports'           => array('title', 'thumbnail'),
		'show_in_rest'       => true,
	);

	register_post_type('l3_aliado', $args);
}
add_action('init', 'l3_register_aliados_cpt');

/**
 * Meta Box para la URL del Cliente.
 */
function l3_aliados_add_meta_box(): void
{
	add_meta_box(
		'l3_aliado_details',
		'Información del Cliente',
		'l3_aliado_details_callback',
		'l3_aliado',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', 'l3_aliados_add_meta_box');

function l3_aliado_details_callback($post): void
{
	wp_nonce_field('l3_aliado_save_meta', 'l3_aliado_nonce');
	$url = get_post_meta($post->ID, '_l3_aliado_url', true);
	?>
	<p>
		<label for="l3_aliado_url"><strong>URL del Sitio Web:</strong></label><br>
		<input type="url" id="l3_aliado_url" name="l3_aliado_url" value="<?php echo esc_attr($url); ?>" class="widefat" placeholder="https://ejemplo.com">
	</p>
	<?php
}

function l3_aliado_save_meta($post_id): void
{
	if (!isset($_POST['l3_aliado_nonce']) || !wp_verify_nonce($_POST['l3_aliado_nonce'], 'l3_aliado_save_meta')) {
		return;
	}
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}

	if (isset($_POST['l3_aliado_url'])) {
		update_post_meta($post_id, '_l3_aliado_url', esc_url_raw($_POST['l3_aliado_url']));
	}
}
add_action('save_post', 'l3_aliado_save_meta');

/**
 * Shortcode para mostrar el Slider de Clientes.
 */
function l3_allies_grid_shortcode($atts): string
{
	$args = array(
		'post_type'      => 'l3_aliado',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	);

	$query = new WP_Query($args);
	$cards_html = '';
	$valid_count = 0;

	while ($query->have_posts()) {
		$query->the_post();
		$thumb_id = get_post_thumbnail_id(get_the_ID());
		$logo_img = wp_get_attachment_image($thumb_id, 'l3-ally-logo');
		$site_url = get_post_meta(get_the_ID(), '_l3_aliado_url', true);

		if ($logo_img) {
			$valid_count++;
			$cards_html .= '<div class="ally-card">';
			if ($site_url) {
				$cards_html .= '<a href="' . esc_url($site_url) . '" target="_blank" rel="noopener noreferrer">';
			}
			$cards_html .= $logo_img;
			if ($site_url) {
				$cards_html .= '</a>';
			}
			$cards_html .= '</div>';
		}
	}
	wp_reset_postdata();

	if ($valid_count === 0) {
		return '<div class="l3-empty-allies" style="display:none;"></div><script>(function(){ var el = document.currentScript.previousElementSibling; if(el) { var wrapper = el.closest(".l3-allies-section") || el.closest(".alignfull"); if(wrapper) { wrapper.style.display = "none"; } } })();</script>';
	}

	$slider_id = 'l3-slider-' . uniqid();
	
	$container_class = 'l3-allies-slider-container';
	if ($valid_count < 5) {
		$container_class .= ' l3-allies-static';
	}

	$output = '<div class="' . $container_class . '" id="' . $slider_id . '">';
	
	if ($valid_count >= 5) {
		$output .= '<button class="l3-slider-btn prev" aria-label="Anterior"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg></button>';
	}
	
	$output .= '<div class="l3-allies-slider-viewport">';
	$output .= '<div class="l3-allies-slider-track">';
	
	$output .= $cards_html;

	$output .= '</div>'; // End track
	$output .= '</div>'; // End viewport
	
	if ($post_count >= 5) {
		$output .= '<button class="l3-slider-btn next" aria-label="Siguiente"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg></button>';
	}
	$output .= '</div>'; // End container

	if ($post_count >= 5) {
		// JavaScript for the slider
		$output .= "
		<script>
		document.addEventListener('DOMContentLoaded', function() {
			const container = document.getElementById('" . $slider_id . "');
			if (!container) return;

			const track = container.querySelector('.l3-allies-slider-track');
			const viewport = container.querySelector('.l3-allies-slider-viewport');
			const btnPrev = container.querySelector('.l3-slider-btn.prev');
			const btnNext = container.querySelector('.l3-slider-btn.next');
			
			let index = 0;
			let autoplayInterval;

			function getVisibleCards() {
				const cardWidth = container.querySelector('.ally-card').offsetWidth + 20; // 20 is gap
				return Math.floor(viewport.offsetWidth / cardWidth);
			}

			function updateSlider() {
				const cardWidth = container.querySelector('.ally-card').offsetWidth + 20;
				const maxIndex = track.children.length - getVisibleCards();
				
				if (index > maxIndex) index = 0;
				if (index < 0) index = maxIndex > 0 ? maxIndex : 0;

				const offset = index * cardWidth;
				track.style.transform = 'translateX(-' + offset + 'px)';
			}

			function nextSlide() {
				index++;
				updateSlider();
			}

			function prevSlide() {
				index--;
				updateSlider();
			}

			function startAutoplay() {
				stopAutoplay();
				autoplayInterval = setInterval(nextSlide, 5000);
			}

			function stopAutoplay() {
				if (autoplayInterval) clearInterval(autoplayInterval);
			}

			btnNext.addEventListener('click', () => {
				nextSlide();
				startAutoplay();
			});

			btnPrev.addEventListener('click', () => {
				prevSlide();
				startAutoplay();
			});

			// Touch events for mobile
			let touchStartX = 0;
			viewport.addEventListener('touchstart', (e) => {
				touchStartX = e.touches[0].clientX;
				stopAutoplay();
			});

			viewport.addEventListener('touchend', (e) => {
				const touchEndX = e.changedTouches[0].clientX;
				if (touchStartX - touchEndX > 50) nextSlide();
				if (touchStartX - touchEndX < -50) prevSlide();
				startAutoplay();
			});

			window.addEventListener('resize', updateSlider);
			
			// Initial start
			startAutoplay();
		});
		</script>";
	}

	return $output;
}
add_shortcode('antigravity_allies_grid', 'l3_allies_grid_shortcode');

/**
 * Shortcode [antigravity_author_profile] para renderizar el perfil detallado del usuario.
 */
function antigravity_author_profile_shortcode($atts) {
    if (!is_author()) {
        return '';
    }
    
    $author_id = get_queried_object_id();
    $user = get_userdata($author_id);
    
    if (!$user) {
        return '';
    }

    $prefix = get_the_author_meta('antigravity_user_prefix', $author_id);
    $name = $user->display_name;
    $display_name = !empty($prefix) ? $prefix . ' ' . $name : $name;
    
    $website = get_the_author_meta('antigravity_user_website', $author_id);
    $linkedin = get_the_author_meta('antigravity_user_linkedin', $author_id);
    $twitter = get_the_author_meta('antigravity_user_twitter', $author_id);
    $whatsapp = get_the_author_meta('antigravity_user_whatsapp', $author_id);
    
    $website_visible = get_the_author_meta('antigravity_user_website_visible', $author_id);
    $linkedin_visible = get_the_author_meta('antigravity_user_linkedin_visible', $author_id);
    $twitter_visible = get_the_author_meta('antigravity_user_twitter_visible', $author_id);
    $email_visible = get_the_author_meta('antigravity_user_email_visible', $author_id);
    $whatsapp_visible = get_the_author_meta('antigravity_user_whatsapp_visible', $author_id);
    $share_visible = get_the_author_meta('antigravity_user_share_visible', $author_id);
    
    if ($website_visible === '' && !empty($website)) $website_visible = 'yes';
    if ($linkedin_visible === '' && !empty($linkedin)) $linkedin_visible = 'yes';
    if ($twitter_visible === '' && !empty($twitter)) $twitter_visible = 'yes';
    if ($whatsapp_visible === '' && !empty($whatsapp)) $whatsapp_visible = 'yes';
    if ($email_visible === '') $email_visible = 'yes';
    if ($share_visible === '') $share_visible = 'yes';
    
    $job_title = get_the_author_meta('antigravity_user_job_title', $author_id);
    if (empty($job_title)) {
        // Fallback al rol o algo por defecto si está vacío, pero mejor vacío.
        $job_title = 'Especialista Legal';
    }
    
    $quote = get_the_author_meta('antigravity_user_quote', $author_id);
    $quote_visible = get_the_author_meta('antigravity_user_quote_visible', $author_id);
    if ($quote_visible === '' && !empty($quote)) {
        $quote_visible = 'yes';
    }
    
    // Trayectoria construida desde Información Biográfica (description) y Extracto Profesional
    $bio = $user->description;
    $excerpt = get_the_author_meta('antigravity_user_excerpt', $author_id);
    
    $focus = get_the_author_meta('antigravity_user_focus', $author_id);
    $focus_visible = get_the_author_meta('antigravity_user_focus_visible', $author_id);
    if ($focus_visible === '' && !empty($focus)) {
        $focus_visible = 'yes';
    }
    
    $languages = get_the_author_meta('antigravity_user_languages', $author_id);
    
    $avatar_url = get_avatar_url($author_id, array('size' => 1000));
    
    $languages_visible = get_the_author_meta('antigravity_user_languages_visible', $author_id);
    if ($languages_visible === '' && !empty($languages)) {
        $languages_visible = 'yes';
    }
    
    ob_start();
    ?>
    <!-- ANTIGRAVITY_START -->
    <div class="l3-author-profile-wrapper l3-container-standard">
        
        <!-- Header del Perfil -->
        <div class="l3-author-profile-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 60px; gap: 60px;">
            <div class="l3-author-profile-title-col" style="display: flex; gap: 30px; align-items: stretch;">
                <div class="section-vertical-line" style="width: 2px; background: var(--wp--preset--color--primary); flex-shrink: 0;"></div>
                <div class="l3-author-title-content">
                    <p class="l3-author-role-eyebrow" style="margin-bottom: 5px;"><?php echo esc_html($job_title); ?></p>
                    <h1 class="l3-author-name-huge" style="margin-bottom: 15px;"><?php echo esc_html($display_name); ?></h1>
                
                <!-- Iconos de Redes y Contacto -->
                <div class="l3-author-social-header" style="display: flex; gap: 18px; margin-bottom: 25px; align-items: center;">
                    <?php if ($share_visible === 'yes'): ?>
                        <a href="#" class="l3-share-profile-btn" 
                           data-share-url="<?php echo esc_url(get_author_posts_url($author_id)); ?>" 
                           data-share-title="<?php echo esc_attr(sprintf('Perfil Profesional — %s', $display_name)); ?>" 
                           title="Compartir"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s; display: inline-flex; align-items: center; justify-content: center; cursor: pointer;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($user->user_email) && $email_visible === 'yes'): ?>
                        <a href="#" class="linea3-team-icon-email linea3-team-contact-btn" 
                           data-author-id="<?php echo $author_id; ?>" 
                           data-author-name="<?php echo esc_attr($name); ?>" 
                           data-author-image="<?php echo esc_url($avatar_url); ?>" 
                           title="Contactar"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($whatsapp) && $whatsapp_visible === 'yes'): ?>
                        <?php 
                        $wa_link = 'https://wa.me/' . preg_replace('/[^0-9]/', '', $whatsapp);
                        ?>
                        <a href="<?php echo esc_url($wa_link); ?>" target="_blank" rel="noopener noreferrer" title="WhatsApp"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 1 1-7.6-11.7 8.38 8.38 0 0 1 3.8.9L21 3l-1.4 5.4L21 11.5z"></path></svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($linkedin) && $linkedin_visible === 'yes'): ?>
                        <a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer" title="LinkedIn"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($website) && $website_visible === 'yes'): ?>
                        <a href="<?php echo esc_url($website); ?>" target="_blank" rel="noopener noreferrer" title="Sitio Web"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($twitter) && $twitter_visible === 'yes'): ?>
                        <a href="<?php echo esc_url($twitter); ?>" target="_blank" rel="noopener noreferrer" title="Twitter/X"
                           style="color: var(--wp--preset--color--primary); transition: opacity 0.3s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
                        </a>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($quote) && $quote_visible === 'yes'): ?>
                <div class="l3-author-quote-wrapper" style="margin-top: 25px; display: flex; align-items: flex-start; gap: 20px;">
                    <p class="l3-author-quote-text" style="margin: 0; font-style: italic; color: rgba(255, 255, 255, 0.7); line-height: 1.6; font-size: 1.1rem; flex: 1;"><?php echo esc_html($quote); ?></p>
                    <div class="l3-quote-decoration" style="flex-shrink: 0; opacity: 0.15; color: #fff;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor"><path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V12C14.017 12.5523 13.5693 13 13.017 13H11.017C10.4647 13 10.017 12.5523 10.017 12V9C10.017 6.79086 11.8079 5 14.017 5H19.017C21.2261 5 23.017 6.79086 23.017 9V15C23.017 18.3137 20.3307 21 17.017 21H14.017ZM3.017 21L3.017 18C3.017 16.8954 3.91243 16 5.017 16H8.017C8.56928 16 9.017 15.5523 9.017 15V9C9.017 8.44772 8.56928 8 8.017 8H4.017C3.46472 8 3.017 8.44772 3.017 9V12C3.017 12.5523 2.56928 13 2.017 13H0.017C-0.535282 13 -1.017 12.5523 -1.017 12V9C-1.017 6.79086 0.773858 5 3.017 5H8.017C10.2261 5 12.017 6.79086 12.017 9V15C12.017 18.3137 9.33072 21 6.017 21H3.017Z"/></svg>
                    </div>
                </div>
                <?php endif; ?>
                </div>
            </div>

            <div class="l3-author-profile-image-col">
                <div class="linea3-team-card" style="padding: 25px; height: auto; cursor: default; transition: all 0.4s ease;">
                    <div class="linea3-team-card-image-wrap" style="margin-bottom: 0; aspect-ratio: 1/1.2;">
                        <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($display_name); ?>" class="linea3-team-card-image" />
                    </div>
                </div>
            </div>
        </div>

        <!-- Contenido del Perfil -->
        <div class="l3-author-profile-content">
            <?php 
            $has_sidebar_content = (!empty($focus) && $focus_visible === 'yes') || (!empty($languages) && $languages_visible === 'yes');
            if ($has_sidebar_content): 
            ?>
            <div class="l3-author-sidebar">
                <div class="l3-sidebar-title-wrapper" style="margin-bottom: 30px;">
                    <h2 class="l3-sidebar-title" style="margin: 0; font-size: 1.5rem; color: var(--wp--preset--color--primary); text-transform: uppercase; letter-spacing: 1px;">Trayectoria y Visión</h2>
                </div>
                
                <?php if (!empty($focus) && $focus_visible === 'yes'): ?>
                <div class="l3-sidebar-block l3-focus-block">
                    <h3 class="l3-sidebar-subtitle">ENFOQUE PRINCIPAL</h3>
                    <div class="l3-sidebar-text"><?php echo wpautop(esc_html($focus)); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($languages) && $languages_visible === 'yes'): ?>
                <div class="l3-sidebar-block l3-languages-block">
                    <h3 class="l3-sidebar-subtitle">IDIOMAS</h3>
                    <ul class="l3-languages-list">
                        <?php 
                        $langs = explode("\n", $languages);
                        foreach($langs as $lang) {
                            if (trim($lang) !== '') {
                                echo '<li><span class="l3-lang-bullet"></span>' . esc_html(trim($lang)) . '</li>';
                            }
                        }
                        ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <div class="l3-author-main-text">
                <div class="l3-trajectory-text">
                    <?php if (!empty($bio)): ?>
                        <p><?php echo nl2br(esc_html($bio)); ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($excerpt)): ?>
                        <p class="l3-trajectory-excerpt" style="margin-top: 30px;"><?php echo nl2br(esc_html($excerpt)); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        </div>
        
    </div>
    <!-- ANTIGRAVITY_END -->
    <?php
    $output = ob_get_clean();
    return preg_replace('/>\s+</', '><', $output);
}
add_shortcode('antigravity_author_profile', 'antigravity_author_profile_shortcode');

/**
 * Shortcode to render the publication section header in author profile.
 */
/**
 * Shortcode to render the entire publication section in author profile.
 * Identical to the single post related posts section.
 */
function antigravity_author_publications_section_shortcode() {
    $author = get_queried_object();
    if (!$author || !isset($author->ID)) {
        return '';
    }
    return antigravity_get_related_posts_html($author->ID);
}
add_shortcode('antigravity_author_publications_section', 'antigravity_author_publications_section_shortcode');

/**
 * Filtro Maestro de Ortografía de Marca: Fuerza "Linea 3" sin tilde en todo el sitio.
 * Esto corrige el título de la pestaña del navegador y el título del sitio si están en la DB con tilde.
 */
function antigravity_force_brand_spelling($title) {
    if (is_array($title)) {
        return array_map('antigravity_force_brand_spelling', $title);
    }
    if (is_string($title)) {
        $title = str_replace('Línea 3', 'Linea 3', $title);
        $title = str_replace('Línea Tres', 'Linea 3', $title);
    }
    return $title;
}
add_filter('document_title_parts', 'antigravity_force_brand_spelling', 999);
add_filter('pre_get_document_title', 'antigravity_force_brand_spelling', 999);
add_filter('bloginfo', 'antigravity_force_brand_spelling', 999, 2);
add_filter('option_blogname', 'antigravity_force_brand_spelling', 999);

/**
 * Render floating WhatsApp button in the footer using the dynamic "Teléfono Móvil" field and custom prefilled message.
 */
function l3_whatsapp_floating_button(): void
{
	// Check if the WhatsApp toggle switch is enabled in the admin settings panel
	if (!get_option('l3_info_movil_vis')) {
		return;
	}

	// Fetch the user's configured "Teléfono Móvil" option
	$mobile = (string)get_option('l3_info_movil');
	
	// Strip spaces, dashes, +, and other non-digit characters
	$whatsapp_number = preg_replace('/[^0-9]/', '', $mobile);

	// CRITICAL SAFETY CHECK: If there is no number, do NOT show the WhatsApp button under any circumstance!
	if (empty($whatsapp_number)) {
		return;
	}

	// Check if this number is a standard 10-digit mobile (e.g. 3208370098) starting with 3.
	// In Colombia, mobile numbers require country code 57 for WhatsApp links to work.
	if (strlen($whatsapp_number) === 10 && strpos($whatsapp_number, '3') === 0) {
		$whatsapp_number = '57' . $whatsapp_number;
	}

	// Create a premium, friendly pre-filled message
	$message = 'Hola, me gustaría recibir asesoría jurídica. Escribo desde el sitio web de Linea 3 Estudio Legal.';
	$whatsapp_url = 'https://wa.me/' . $whatsapp_number . '?text=' . rawurlencode($message);

	?>
	<div class="l3-whatsapp-container">
		<div class="l3-whatsapp-tooltip">
			<span class="l3-whatsapp-tooltip-text">Contáctanos</span>
			<div class="l3-whatsapp-tooltip-tail"></div>
		</div>
		<a href="<?php echo esc_url($whatsapp_url); ?>" class="l3-whatsapp-floating" target="_blank" rel="noopener nofollow" aria-label="Escríbenos por WhatsApp">
			<i class="fab fa-whatsapp"></i>
		</a>
	</div>
	<?php
}
add_action('wp_footer', 'l3_whatsapp_floating_button', 100);

/**
 * ============================================================================
 * Custom Post Type: Reseñas de Clientes
 * ============================================================================
 * Las reseñas son enviadas por usuarios desde un formulario en el frontend.
 * El administrador NO puede crear reseñas desde el panel; solo puede
 * editar (corregir ortografía), publicar o eliminar.
 *
 * Campos (meta fields):
 *   - _l3_resena_nombre        : Nombre de la persona
 *   - _l3_resena_linkedin_url  : URL del perfil de LinkedIn
 *   - _l3_resena_linkedin_auth : Autoriza publicar en su LinkedIn (checkbox)
 *   - _l3_resena_rating        : Calificación de 0 a 5 (estrellas)
 *   - _l3_resena_contenido     : Texto de la reseña (máx. 140 caracteres)
 * ============================================================================
 */

/**
 * 1. Registro del CPT l3_resena.
 */
function l3_register_resenas_cpt(): void
{
	$labels = array(
		'name'               => 'Reseñas',
		'singular_name'      => 'Reseña',
		'menu_name'          => 'Reseñas',
		'name_admin_bar'     => 'Reseña',
		'add_new'            => 'Añadir Nueva',
		'add_new_item'       => 'Añadir Nueva Reseña',
		'new_item'           => 'Nueva Reseña',
		'edit_item'          => 'Editar Reseña',
		'view_item'          => 'Ver Reseña',
		'all_items'          => 'Todas las Reseñas',
		'search_items'       => 'Buscar Reseñas',
		'not_found'          => 'No se encontraron reseñas.',
		'not_found_in_trash' => 'No hay reseñas en la papelera.',
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'resena'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 22,
		'menu_icon'          => 'dashicons-star-filled',
		'supports'           => array('title'),
		'show_in_rest'       => true,
	);

	register_post_type('l3_resena', $args);
}
add_action('init', 'l3_register_resenas_cpt');

/**
 * 2. Bloquear creación de reseñas desde el admin.
 *    - Oculta el submenú "Añadir Nueva"
 *    - Redirecciona si alguien accede directamente a post-new.php?post_type=l3_resena
 *    - Oculta el botón "Añadir Nueva" por CSS como capa extra
 */
function l3_resenas_remove_add_new_submenu(): void
{
	remove_submenu_page('edit.php?post_type=l3_resena', 'post-new.php?post_type=l3_resena');
}
add_action('admin_menu', 'l3_resenas_remove_add_new_submenu');

function l3_resenas_block_create_screen(): void
{
	global $pagenow, $typenow;

	if ($pagenow === 'post-new.php' && (isset($_GET['post_type']) && $_GET['post_type'] === 'l3_resena')) {
		wp_redirect(admin_url('edit.php?post_type=l3_resena&l3_blocked=1'));
		exit;
	}
}
add_action('admin_init', 'l3_resenas_block_create_screen');

/**
 * Muestra un aviso administrativo cuando se intenta crear una reseña desde admin.
 */
function l3_resenas_blocked_notice(): void
{
	if (isset($_GET['post_type']) && $_GET['post_type'] === 'l3_resena' && isset($_GET['l3_blocked'])) {
		echo '<div class="notice notice-warning is-dismissible">';
		echo '<p><strong>Las reseñas no se pueden crear desde el panel de administración.</strong> ';
		echo 'Las reseñas son enviadas por los clientes a través del formulario en el sitio web. ';
		echo 'Desde aquí solo puede editar, publicar o eliminar reseñas existentes.</p>';
		echo '</div>';
	}
}
add_action('admin_notices', 'l3_resenas_blocked_notice');

/**
 * 3. Meta Box: Datos de la Reseña.
 */
function l3_resenas_add_meta_box(): void
{
	add_meta_box(
		'l3_resena_details',
		'Datos de la Reseña',
		'l3_resena_details_callback',
		'l3_resena',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', 'l3_resenas_add_meta_box');

/**
 * 4. Render del Meta Box con interfaz visual premium enriquecida.
 */
function l3_resena_details_callback($post): void
{
	wp_nonce_field('l3_resena_save_meta', 'l3_resena_nonce');

	$nombre        = get_post_meta($post->ID, '_l3_resena_nombre', true);
	$via_linkedin  = get_post_meta($post->ID, '_l3_resena_via_linkedin', true);
	$linkedin_url  = get_post_meta($post->ID, '_l3_resena_linkedin_url', true);
	$linkedin_auth = get_post_meta($post->ID, '_l3_resena_linkedin_auth', true);
	$empresa       = get_post_meta($post->ID, '_l3_resena_empresa', true);
	$cargo         = get_post_meta($post->ID, '_l3_resena_cargo', true);
	$foto          = get_post_meta($post->ID, '_l3_resena_foto', true);
	$rating        = get_post_meta($post->ID, '_l3_resena_rating', true);
	$contenido     = get_post_meta($post->ID, '_l3_resena_contenido', true);
	
	// Nuevos campos para red social opcional (flujo sin LinkedIn)
	$red_social_tipo = get_post_meta($post->ID, '_l3_resena_red_social_tipo', true);
	$red_social_url  = get_post_meta($post->ID, '_l3_resena_red_social_url', true);

	if ($rating === '') {
		$rating = 0;
	}
	$rating = intval($rating);
	$char_count = mb_strlen($contenido);

	// Avatar por defecto si no hay foto
	$avatar_url = !empty($foto) ? $foto : get_avatar_url(0, array('size' => 120));
	?>
	<div class="l3-resena-metabox">
		
		<!-- Banner de Origen / Flujo -->
		<div class="l3-resena-badge-container">
			<?php if ($via_linkedin === '1'): ?>
				<div class="l3-resena-badge l3-resena-badge--linkedin">
					<span class="dashicons dashicons-linkedin"></span>
					Registrada vía LinkedIn OAuth
				</div>
			<?php else: ?>
				<div class="l3-resena-badge l3-resena-badge--manual">
					<span class="dashicons dashicons-edit"></span>
					Registrada vía Formulario Web (Manual)
				</div>
			<?php endif; ?>
		</div>

		<div class="l3-resena-row">
			<!-- Foto de Perfil (Media Uploader) -->
			<div class="l3-resena-col-avatar">
				<label><strong>Foto del Cliente</strong></label>
				<div class="l3-resena-avatar-preview-wrapper">
					<img src="<?php echo esc_url($avatar_url); ?>" id="l3-resena-avatar-preview" class="l3-resena-avatar-img" alt="Avatar">
					<input type="hidden" id="l3_resena_foto" name="l3_resena_foto" value="<?php echo esc_url($foto); ?>">
					<button type="button" class="button button-secondary" id="l3_resena_upload_btn">Cambiar Imagen</button>
					<button type="button" class="button link-delete" id="l3_resena_remove_btn" style="<?php echo empty($foto) ? 'display:none;' : ''; ?>">Quitar</button>
				</div>
			</div>

			<!-- Nombre y Datos de Empresa -->
			<div class="l3-resena-col-fields">
				<!-- Nombre de la persona -->
				<div class="l3-resena-field">
					<label for="l3_resena_nombre"><strong>Nombre de la persona *</strong></label>
					<input
						type="text"
						id="l3_resena_nombre"
						name="l3_resena_nombre"
						value="<?php echo esc_attr($nombre); ?>"
						class="widefat"
						placeholder="Ej: María García López"
						required
					>
				</div>

				<div class="l3-resena-grid-2">
					<!-- Empresa -->
					<div class="l3-resena-field">
						<label for="l3_resena_empresa"><strong>Empresa (opcional)</strong></label>
						<input
							type="text"
							id="l3_resena_empresa"
							name="l3_resena_empresa"
							value="<?php echo esc_attr($empresa); ?>"
							class="widefat"
							placeholder="Ej: Linea 3 Estudio Legal"
						>
					</div>

					<!-- Cargo -->
					<div class="l3-resena-field">
						<label for="l3_resena_cargo"><strong>Cargo (opcional)</strong></label>
						<input
							type="text"
							id="l3_resena_cargo"
							name="l3_resena_cargo"
							value="<?php echo esc_attr($cargo); ?>"
							class="widefat"
							placeholder="Ej: Director Jurídico"
						>
					</div>
				</div>
			</div>
		</div>

		<hr class="l3-resena-separator">

		<!-- Sección de Redes Sociales (Depende de origen) -->
		<div class="l3-resena-section-title">Enlace a Red Social</div>
		
		<?php if ($via_linkedin === '1'): ?>
			<!-- Flujo LinkedIn (Solo Lectura) -->
			<div class="l3-resena-grid-2">
				<div class="l3-resena-field">
					<label for="l3_resena_linkedin_url">
						<strong>URL del perfil de LinkedIn</strong>
						<?php if (!empty($nombre)): ?>
							<a href="https://www.linkedin.com/search/results/people/?keywords=<?php echo urlencode($nombre); ?>" target="_blank" style="margin-left: 10px; text-decoration: none; font-size: 11px; padding: 0 8px; line-height: 2; height: 22px;" class="button button-secondary">
								<span class="dashicons dashicons-search" style="vertical-align: middle; font-size: 13px; width: 13px; height: 13px; margin-top: -3px;"></span> Buscar en LinkedIn
							</a>
						<?php endif; ?>
					</label>
					<input
						type="url"
						id="l3_resena_linkedin_url"
						name="l3_resena_linkedin_url"
						value="<?php echo esc_attr($linkedin_url); ?>"
						class="widefat"
						placeholder="https://www.linkedin.com/in/usuario"
					>
				</div>

				<div class="l3-resena-field l3-resena-field--checkbox l3-resena-field--readonly">
					<label style="margin-top: 28px;">
						<input
							type="checkbox"
							id="l3_resena_linkedin_auth"
							value="1"
							<?php checked($linkedin_auth, '1'); ?>
							disabled="disabled"
						>
						<strong>Autoriza publicar esta reseña en su perfil de LinkedIn</strong>
					</label>
					<p class="description">Este campo fue definido por el usuario vía OAuth y no puede ser modificado.</p>
				</div>

				<?php 
				$linkedin_logs = get_post_meta($post->ID, '_l3_resena_linkedin_logs', true);
				if (!empty($linkedin_logs) && is_array($linkedin_logs)): 
				?>
					<div class="l3-resena-field" style="grid-column: span 2; margin-top: 20px;">
						<label><strong>Historial de Publicación Automática (LinkedIn API Logs)</strong></label>
						<div style="background: #111; color: #00ff66; padding: 12px 15px; border-radius: 6px; font-family: 'Courier New', Courier, monospace; font-size: 12px; line-height: 1.6; max-height: 250px; overflow-y: auto; border: 1px solid #222; margin-top: 8px; box-shadow: inset 0 0 10px rgba(0,0,0,0.8);">
							<?php foreach ($linkedin_logs as $log): ?>
								<div style="margin-bottom: 5px; border-bottom: 1px solid #222; padding-bottom: 5px;">
									<span style="color: #00bcff;">&gt;</span> <?php echo esc_html($log); ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php else: ?>
			<!-- Flujo Manual (Redes sociales variadas) -->
			<div class="l3-resena-grid-2">
				<div class="l3-resena-field">
					<label for="l3_resena_red_social_tipo"><strong>Red Social Vinculada</strong></label>
					<select name="l3_resena_red_social_tipo" id="l3_resena_red_social_tipo" class="widefat">
						<option value="" <?php selected($red_social_tipo, ''); ?>>Ninguna</option>
						<option value="linkedin" <?php selected($red_social_tipo, 'linkedin'); ?>>LinkedIn</option>
						<option value="instagram" <?php selected($red_social_tipo, 'instagram'); ?>>Instagram</option>
						<option value="facebook" <?php selected($red_social_tipo, 'facebook'); ?>>Facebook</option>
					</select>
				</div>

				<div class="l3-resena-field">
					<label for="l3_resena_red_social_url"><strong>URL del Perfil</strong></label>
					<input
						type="url"
						id="l3_resena_red_social_url"
						name="l3_resena_red_social_url"
						value="<?php echo esc_attr($red_social_url); ?>"
						class="widefat"
						placeholder="https://redsocial.com/perfil"
					>
				</div>
			</div>
		<?php endif; ?>

		<hr class="l3-resena-separator">

		<!-- Calificación con estrellas (solo lectura) -->
		<div class="l3-resena-field l3-resena-field--readonly">
			<label><strong>Calificación</strong></label>
			<div class="l3-resena-stars l3-resena-stars--readonly" id="l3-resena-stars">
				<?php for ($i = 1; $i <= 5; $i++): ?>
					<span
						class="l3-star <?php echo ($i <= $rating) ? 'l3-star--active' : ''; ?>"
						title="<?php echo $i; ?> estrella<?php echo $i > 1 ? 's' : ''; ?>"
					>
						<svg width="28" height="28" viewBox="0 0 24 24" fill="<?php echo ($i <= $rating) ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="1.5">
							<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
						</svg>
					</span>
				<?php endfor; ?>
				<span class="l3-star-label" id="l3-star-label">
					<?php 
					if ($rating > 0) {
						$rating_val = (float)$rating;
						$rating_label = 'Sin calificación';
						if ($rating_val >= 1 && $rating_val < 2) $rating_label = 'Muy insatisfecho';
						elseif ($rating_val >= 2 && $rating_val < 3) $rating_label = 'Insatisfecho';
						elseif ($rating_val >= 3 && $rating_val < 4) $rating_label = 'Satisfecho';
						elseif ($rating_val >= 4 && $rating_val < 5) $rating_label = 'Muy satisfecho';
						elseif ($rating_val == 5) $rating_label = 'Excelente servicio';
						
						echo number_format($rating_val, 1, '.', '') . '/5.0 - ' . $rating_label;
					} else {
						echo 'Sin calificación';
					}
					?>
				</span>
			</div>
			<p class="description">Este campo fue definido por el usuario y no puede ser modificado por el administrador.</p>
		</div>

		<hr class="l3-resena-separator">

		<!-- Contenido de la reseña -->
		<div class="l3-resena-field">
			<label for="l3_resena_contenido"><strong>Contenido de la reseña *</strong></label>
			<textarea
				id="l3_resena_contenido"
				name="l3_resena_contenido"
				class="widefat"
				rows="4"
				maxlength="240"
				placeholder="Texto de la reseña del cliente (máximo 240 caracteres)"
				required
			><?php echo esc_textarea($contenido); ?></textarea>
			<div class="l3-resena-char-counter" id="l3-resena-char-counter">
				<span id="l3-resena-char-count"><?php echo $char_count; ?></span>/240 caracteres
			</div>
		</div>
		</div>
		
		<hr class="l3-resena-separator">

		<!-- Reseña Destacada -->
		<div class="l3-resena-field l3-resena-field--checkbox">
			<label>
				<?php 
				$destacada = get_post_meta($post->ID, '_l3_resena_destacada', true);
				
				// Calcular total de reseñas destacadas actuales (excluyendo esta misma)
				$args_destacadas = array(
					'post_type'      => 'l3_resena',
					'posts_per_page' => -1,
					'post_status'    => 'any',
					'meta_query'     => array(
						array(
							'key'     => '_l3_resena_destacada',
							'value'   => '1',
							'compare' => '='
						)
					),
					'fields' => 'ids',
					'post__not_in' => array($post->ID)
				);
				$destacadas_query = new WP_Query($args_destacadas);
				$current_featured_count = $destacadas_query->found_posts;
				$disable_checkbox = ($destacada !== '1' && $current_featured_count >= 3);
				?>
				<input
					type="checkbox"
					id="l3_resena_destacada"
					name="l3_resena_destacada"
					value="1"
					<?php checked($destacada, '1'); ?>
					<?php echo $disable_checkbox ? 'disabled="disabled"' : ''; ?>
				>
				<strong>Marcar como Reseña Destacada (Fija)</strong>
			</label>
			
			<?php if ($disable_checkbox): ?>
				<p class="description l3-admin-inline-error" style="color: #ce9e50; font-weight: 500; margin-top: 8px;">
					Límite alcanzado: Ya tienes 3 reseñas destacadas. Debes desmarcar otra publicación primero para poder destacar esta.
				</p>
			<?php else: ?>
				<p class="description">Las reseñas marcadas como destacadas aparecerán de primeras en el carrusel (máximo 3).</p>
			<?php endif; ?>
		</div>
	</div>

	<script>
	jQuery(document).ready(function($) {
		// ── WordPress Media Library Uploader ──
		var mediaUploader;
		$('#l3_resena_upload_btn').on('click', function(e) {
			e.preventDefault();
			if (mediaUploader) {
				mediaUploader.open();
				return;
			}
			mediaUploader = wp.media({
				title: 'Seleccionar Foto de Perfil',
				button: {
					text: 'Usar Foto'
				},
				multiple: false
			});
			mediaUploader.on('select', function() {
				var attachment = mediaUploader.state().get('selection').first().toJSON();
				$('#l3_resena_foto').val(attachment.url);
				$('#l3-resena-avatar-preview').attr('src', attachment.url);
				$('#l3_resena_remove_btn').show();
			});
			mediaUploader.open();
		});

		$('#l3_resena_remove_btn').on('click', function(e) {
			e.preventDefault();
			$('#l3_resena_foto').val('');
			$('#l3-resena-avatar-preview').attr('src', '<?php echo esc_js(get_avatar_url(0, array('size' => 120))); ?>');
			$(this).hide();
		});

		// ── Contador de caracteres ──
		var $textarea = $('#l3_resena_contenido');
		var $counter = $('#l3-resena-char-count');
		var $counterWrap = $('#l3-resena-char-counter');

		$textarea.on('input', function() {
			var len = $(this).val().length;
			$counter.text(len);

			if (len > 240) {
				$counterWrap.addClass('l3-resena-char-counter--exceeded');
				$textarea.addClass('l3-resena-textarea--exceeded');
			} else if (len >= 220) {
				$counterWrap.addClass('l3-resena-char-counter--warning');
				$counterWrap.removeClass('l3-resena-char-counter--exceeded');
				$textarea.removeClass('l3-resena-textarea--exceeded');
			} else {
				$counterWrap.removeClass('l3-resena-char-counter--warning l3-resena-char-counter--exceeded');
				$textarea.removeClass('l3-resena-textarea--exceeded');
			}
		});

		// Disparar el evento al cargar para estado inicial
		$textarea.trigger('input');
		// ── Validación de Backend (Admin) al guardar ──
		var $postForm = $('form#post');
		if ($postForm.length) {
			$postForm.on('submit', function(e) {
				var $nombre = $('#l3_resena_nombre');
				var $contenido = $('#l3_resena_contenido');
				var $redSocialTipo = $('#l3_resena_red_social_tipo');
				var $redSocialUrl = $('#l3_resena_red_social_url');
				
				$('.l3-admin-inline-error').remove();
				var hasErrors = false;

				function showError($el, msg) {
					$el.css('border-color', '#ce9e50');
					$el.after('<div class="l3-admin-inline-error" style="color: #ce9e50; font-size: 12px; margin-top: 4px;">' + msg + '</div>');
					hasErrors = true;
				}

				// Reset borders
				$nombre.add($contenido).add($redSocialUrl).css('border-color', '');

				// Validar nombre
				if ($nombre.length && $nombre.val().trim().length < 3) {
					showError($nombre, 'El nombre debe tener al menos 3 caracteres.');
				}

				// Validar contenido
				if ($contenido.length && $contenido.val().trim().length < 10) {
					showError($contenido, 'La reseña debe tener al menos 10 caracteres.');
				}

				// Validar Cargo condicional a Empresa
				var $empresa = $('#l3_resena_empresa');
				var $cargo = $('#l3_resena_cargo');
				$cargo.css('border-color', '');
				if ($empresa.length && $empresa.val().trim() !== '' && $cargo.length && $cargo.val().trim() === '') {
					showError($cargo, 'Es obligatorio especificar el cargo en la empresa');
				}

				// Validar URL según red social
				if ($redSocialTipo.length && $redSocialUrl.length) {
					var tipo = $redSocialTipo.val();
					var url = $redSocialUrl.val().trim();
					
					if (tipo !== '' && url !== '') {
						var regex;
						var expectedPrefix = '';
						if (tipo === 'linkedin') {
							regex = /^https?:\/\/(www\.)?linkedin\.com\/(in|company)\/.+/i;
							expectedPrefix = 'https://linkedin.com/in/ o https://linkedin.com/company/';
						} else if (tipo === 'instagram') {
							regex = /^https?:\/\/(www\.)?instagram\.com\/.+/i;
							expectedPrefix = 'https://instagram.com/';
						} else if (tipo === 'facebook') {
							regex = /^https?:\/\/(www\.)?facebook\.com\/.+/i;
							expectedPrefix = 'https://facebook.com/';
						}

						if (regex && !regex.test(url)) {
							if (tipo === 'linkedin') {
								showError($redSocialUrl, 'Debe contener /in/nombre-usuario o /company/nombre-empresa después de linkedin.com/');
							} else {
								showError($redSocialUrl, 'Debe incluir tu nombre de usuario después de ' + tipo + '.com/');
							}
						}
					} else if (tipo !== '' && url === '') {
						showError($redSocialUrl, 'Debe ingresar la URL si selecciona una red social.');
					} else if (tipo === '' && url !== '') {
						showError($redSocialTipo, 'Seleccione el tipo de red social para la URL ingresada.');
					}
				}

				if (hasErrors) {
					e.preventDefault();
					// Scroll to first error
					$('html, body').animate({
						scrollTop: $('.l3-admin-inline-error').first().offset().top - 60
					}, 300);
					
					// Re-enable publish button
					setTimeout(function() {
						$('#publish').removeClass('button-primary-disabled').prop('disabled', false);
						$('.spinner').removeClass('is-active');
					}, 100);
					
					return false;
				}
			});

			// Limpiar errores al escribir
			$('#l3_resena_nombre, #l3_resena_contenido, #l3_resena_red_social_url, #l3_resena_red_social_tipo').on('input change', function() {
				$(this).css('border-color', '');
				$(this).next('.l3-admin-inline-error').remove();
			});
		}
	});
	</script>
	<?php
}

/**
 * 5. Guardar los meta fields de la reseña.
 */
function l3_resena_save_meta($post_id): void
{
	// Verificar nonce
	if (!isset($_POST['l3_resena_nonce']) || !wp_verify_nonce($_POST['l3_resena_nonce'], 'l3_resena_save_meta')) {
		return;
	}
	// No guardar en autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}
	// Verificar permisos
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}
	// Verificar que es el CPT correcto
	if (get_post_type($post_id) !== 'l3_resena') {
		return;
	}

	// Campos Editables por Admin:
	
	// Nombre
	if (isset($_POST['l3_resena_nombre'])) {
		update_post_meta($post_id, '_l3_resena_nombre', sanitize_text_field($_POST['l3_resena_nombre']));
	}

	// Empresa
	if (isset($_POST['l3_resena_empresa'])) {
		update_post_meta($post_id, '_l3_resena_empresa', sanitize_text_field($_POST['l3_resena_empresa']));
	}

	// Cargo
	if (isset($_POST['l3_resena_cargo'])) {
		update_post_meta($post_id, '_l3_resena_cargo', sanitize_text_field($_POST['l3_resena_cargo']));
	}

	// Foto (URL)
	if (isset($_POST['l3_resena_foto'])) {
		update_post_meta($post_id, '_l3_resena_foto', esc_url_raw($_POST['l3_resena_foto']));
	}

	// LinkedIn URL (Solo si era flujo LinkedIn)
	if (isset($_POST['l3_resena_linkedin_url'])) {
		update_post_meta($post_id, '_l3_resena_linkedin_url', esc_url_raw($_POST['l3_resena_linkedin_url']));
	}

	// Campos Red Social Opcional (Solo si NO es vía LinkedIn)
	if (isset($_POST['l3_resena_red_social_tipo'])) {
		update_post_meta($post_id, '_l3_resena_red_social_tipo', sanitize_text_field($_POST['l3_resena_red_social_tipo']));
	}
	if (isset($_POST['l3_resena_red_social_url'])) {
		update_post_meta($post_id, '_l3_resena_red_social_url', esc_url_raw($_POST['l3_resena_red_social_url']));
	}

	// NOTA: LinkedIn Auth, Rating y Via_LinkedIn NO se guardan desde admin — son datos de usuario (solo lectura)

	// Contenido (máx 140 caracteres)
	if (isset($_POST['l3_resena_contenido'])) {
		$contenido = sanitize_textarea_field($_POST['l3_resena_contenido']);
		$contenido = mb_substr($contenido, 0, 140); // Forzar límite de 140
		update_post_meta($post_id, '_l3_resena_contenido', $contenido);
	}

	// Reseña Destacada
	if (isset($_POST['l3_resena_destacada'])) {
		update_post_meta($post_id, '_l3_resena_destacada', '1');
	} else {
		update_post_meta($post_id, '_l3_resena_destacada', '0');
	}
}
add_action('save_post', 'l3_resena_save_meta');

/**
 * 6. Columnas personalizadas en el listado admin.
 */
function l3_resena_custom_columns($columns): array
{
	$new_columns = array();
	$new_columns['cb']          = $columns['cb'];
	$new_columns['l3_foto']     = 'Foto';
	$new_columns['title']       = 'Nombre';
	$new_columns['l3_empresa']  = 'Empresa / Cargo';
	$new_columns['l3_rating']   = 'Calificación';
	$new_columns['l3_contenido'] = 'Reseña';
	$new_columns['l3_origen']    = 'Procedencia';
	$new_columns['l3_social']    = 'Red Social';
	$new_columns['l3_destacada'] = 'Destacada';
	$new_columns['date']        = $columns['date'];

	return $new_columns;
}
add_filter('manage_l3_resena_posts_columns', 'l3_resena_custom_columns');

function l3_resena_sortable_columns($columns) {
	$columns['l3_destacada'] = 'l3_destacada';
	$columns['l3_rating']    = 'l3_rating';
	$columns['l3_origen']    = 'l3_origen';
	$columns['l3_social']    = 'l3_social';
	return $columns;
}
add_filter('manage_edit-l3_resena_sortable_columns', 'l3_resena_sortable_columns');

function l3_resena_sortable_columns_orderby($query) {
	if (!is_admin() || !$query->is_main_query()) {
		return;
	}
	if ($query->get('post_type') === 'l3_resena') {
		$orderby = $query->get('orderby');
		if ($orderby === 'l3_destacada') {
			$query->set('meta_key', '_l3_resena_destacada');
			$query->set('orderby', 'meta_value');
		} elseif ($orderby === 'l3_rating') {
			$query->set('meta_key', '_l3_resena_rating');
			$query->set('orderby', 'meta_value_num');
		} elseif ($orderby === 'l3_origen') {
			$query->set('meta_key', '_l3_resena_via_linkedin');
			$query->set('orderby', 'meta_value');
		} elseif ($orderby === 'l3_social') {
			$query->set('meta_key', '_l3_resena_red_social_tipo');
			$query->set('orderby', 'meta_value');
		}
	}
}
add_action('pre_get_posts', 'l3_resena_sortable_columns_orderby');

function l3_resena_custom_column_content($column, $post_id): void
{
	switch ($column) {
		case 'l3_foto':
			$foto = get_post_meta($post_id, '_l3_resena_foto', true);
			$avatar_url = !empty($foto) ? $foto : get_avatar_url(0, array('size' => 40));
			echo '<img src="' . esc_url($avatar_url) . '" class="l3-list-avatar-img" alt="avatar">';
			break;

		case 'l3_empresa':
			$empresa = get_post_meta($post_id, '_l3_resena_empresa', true);
			$cargo   = get_post_meta($post_id, '_l3_resena_cargo', true);
			$out = array();
			if (!empty($empresa)) {
				$out[] = '<strong>' . esc_html($empresa) . '</strong>';
			}
			if (!empty($cargo)) {
				$out[] = esc_html($cargo);
			}
			echo !empty($out) ? implode('<br>', $out) : '<span class="l3-col-empty">—</span>';
			break;

		case 'l3_rating':
			$rating = intval(get_post_meta($post_id, '_l3_resena_rating', true));
			$stars_html = '';
			for ($i = 1; $i <= 5; $i++) {
				if ($i <= $rating) {
					$stars_html .= '<span class="l3-col-star l3-col-star--filled">★</span>';
				} else {
					$stars_html .= '<span class="l3-col-star l3-col-star--empty">☆</span>';
				}
			}
			echo '<span class="l3-col-stars">' . $stars_html . '<span class="l3-col-star-numeric">' . number_format($rating, 1) . '/5</span></span>';
			break;

		case 'l3_contenido':
			$contenido = get_post_meta($post_id, '_l3_resena_contenido', true);
			if (!empty($contenido)) {
				echo '<span class="l3-col-contenido">' . esc_html(mb_substr($contenido, 0, 50)) . (mb_strlen($contenido) > 50 ? '…' : '') . '</span>';
			} else {
				echo '<span class="l3-col-empty">—</span>';
			}
			break;

		case 'l3_origen':
			$via_linkedin = get_post_meta($post_id, '_l3_resena_via_linkedin', true);
			if ($via_linkedin === '1') {
				echo '<span class="l3-badge-col l3-badge-col--linkedin"><span class="dashicons dashicons-linkedin"></span> LinkedIn</span>';
			} else {
				echo '<span class="l3-badge-col l3-badge-col--manual"><span class="dashicons dashicons-edit"></span> Web Form</span>';
			}
			break;

		case 'l3_social':
			$via_linkedin = get_post_meta($post_id, '_l3_resena_via_linkedin', true);
			if ($via_linkedin === '1') {
				$url  = get_post_meta($post_id, '_l3_resena_linkedin_url', true);
				$auth = get_post_meta($post_id, '_l3_resena_linkedin_auth', true);
				$tipo = 'linkedin';
			} else {
				$url  = get_post_meta($post_id, '_l3_resena_red_social_url', true);
				$tipo = get_post_meta($post_id, '_l3_resena_red_social_tipo', true);
				$auth = '0';
			}

			if (!empty($url) && !empty($tipo)) {
				$icon_class = 'dashicons-admin-links';
				$title = 'Ver perfil';
				if ($tipo === 'linkedin') {
					$icon_class = 'dashicons-linkedin';
					$title = 'Ver LinkedIn';
				} elseif ($tipo === 'instagram') {
					$icon_class = 'dashicons-instagram';
					$title = 'Ver Instagram';
				} elseif ($tipo === 'facebook') {
					$icon_class = 'dashicons-facebook';
					$title = 'Ver Facebook';
				}
				
				echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer" class="l3-col-social-link l3-social-' . esc_attr($tipo) . '" title="' . esc_attr($title) . '">';
				echo '<span class="dashicons ' . esc_attr($icon_class) . '"></span>';
				echo '</a>';
				
				if ($auth === '1') {
					echo ' <span class="l3-col-linkedin-auth" title="Autoriza publicar en su LinkedIn">✓</span>';
				}
			} else {
				echo '<span class="l3-col-empty">—</span>';
			}
			break;

		case 'l3_destacada':
			$destacada = get_post_meta($post_id, '_l3_resena_destacada', true);
			if ($destacada === '1') {
				echo '<span class="dashicons dashicons-star-filled" style="color: #ce9e50; font-size: 20px;" title="Reseña Destacada"></span>';
			} else {
				echo '<span class="l3-col-empty">—</span>';
			}
			break;
	}
}
add_action('manage_l3_resena_posts_custom_column', 'l3_resena_custom_column_content', 10, 2);

/**
 * 7. CSS y estilos administrativos para el CPT Reseñas.
 */
function l3_resenas_admin_styles(): void
{
	$screen = get_current_screen();
	if (!$screen || ($screen->post_type !== 'l3_resena')) {
		return;
	}

	?>
	<style>
		/* ── Ocultar botón "Añadir Nueva" (capa de seguridad extra) ── */
		.post-type-l3_resena .page-title-action {
			display: none !important;
		}

		/* ── Meta Box: Layout general ── */
		.l3-resena-metabox {
			padding: 12px 0;
		}
		
		/* ── Badge de Origen ── */
		.l3-resena-badge-container {
			margin-bottom: 24px;
		}
		.l3-resena-badge {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			padding: 6px 14px;
			border-radius: 4px;
			font-weight: 600;
			font-size: 13px;
		}
		.l3-resena-badge--linkedin {
			background-color: #e1f0fe;
			color: #0a66c2;
			border: 1px solid #b8dbfd;
		}
		.l3-resena-badge--manual {
			background-color: #f0f0f1;
			color: #50575e;
			border: 1px solid #d0d1d5;
		}
		.l3-resena-badge .dashicons {
			font-size: 17px;
			width: 17px;
			height: 17px;
		}

		/* ── Layout en columnas ── */
		.l3-resena-row {
			display: flex;
			gap: 24px;
			align-items: flex-start;
		}
		.l3-resena-col-avatar {
			flex: 0 0 140px;
			text-align: center;
		}
		.l3-resena-col-fields {
			flex: 1;
		}

		/* ── Avatar Circle Preview ── */
		.l3-resena-avatar-preview-wrapper {
			margin-top: 10px;
			display: flex;
			flex-direction: column;
			align-items: center;
			gap: 10px;
		}
		.l3-resena-avatar-img {
			width: 100px;
			height: 100px;
			border-radius: 50%;
			object-fit: cover;
			border: 3px solid #fff;
			box-shadow: 0 4px 10px rgba(0, 0, 0, 0.12);
			background: #f0f0f1;
		}
		.l3-resena-avatar-preview-wrapper .button {
			width: 100%;
			font-size: 11px;
			height: 28px;
			line-height: 26px;
			text-align: center;
		}
		.l3-resena-avatar-preview-wrapper .link-delete {
			color: #d63638;
			text-decoration: none;
			font-size: 11px;
			cursor: pointer;
		}
		.l3-resena-avatar-preview-wrapper .link-delete:hover {
			color: #a30000;
		}

		/* ── Form Fields y Grid ── */
		.l3-resena-field {
			margin-bottom: 20px;
		}
		.l3-resena-field label {
			display: block;
			margin-bottom: 6px;
			color: #1d2327;
		}
		.l3-resena-field input[type="text"],
		.l3-resena-field input[type="url"],
		.l3-resena-field select {
			font-size: 14px;
			padding: 8px 12px;
			border-radius: 4px;
			height: 38px;
		}
		.l3-resena-grid-2 {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 20px;
		}
		.l3-resena-section-title {
			font-size: 15px;
			font-weight: 600;
			color: #1d2327;
			margin-bottom: 16px;
			border-left: 4px solid #d4a843;
			padding-left: 10px;
		}

		.l3-resena-field--checkbox label {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			cursor: pointer;
		}
		.l3-resena-field--checkbox .description {
			margin-top: 4px;
			color: #646970;
			font-style: italic;
		}

		.l3-resena-separator {
			border: none;
			border-top: 1px solid #e0e0e0;
			margin: 24px 0;
		}

		/* ── Estrellas (solo lectura) ── */
		.l3-resena-stars {
			display: flex;
			align-items: center;
			gap: 4px;
			margin-top: 6px;
		}
		.l3-star {
			color: #ccc;
			display: inline-flex;
		}
		.l3-resena-stars--readonly .l3-star {
			cursor: default;
			pointer-events: none;
		}
		.l3-star--active {
			color: #d4a843;
		}
		.l3-star-label {
			margin-left: 12px;
			font-size: 14px;
			color: #646970;
			font-weight: 500;
		}

		/* ── Campos solo lectura ── */
		.l3-resena-field--readonly {
			opacity: 0.8;
			position: relative;
		}
		.l3-resena-field--readonly .description {
			color: #996800;
			font-style: italic;
			font-size: 12px;
			margin-top: 6px;
		}
		.l3-resena-field--readonly.l3-resena-field--checkbox label {
			cursor: default;
		}

		/* ── Textarea y contador de caracteres ── */
		#l3_resena_contenido {
			font-size: 14px;
			padding: 10px 12px;
			resize: vertical;
			transition: border-color 0.3s ease;
			border-radius: 4px;
		}
		.l3-resena-textarea--exceeded {
			border-color: #d63638 !important;
			box-shadow: 0 0 0 1px #d63638 !important;
		}
		.l3-resena-char-counter {
			text-align: right;
			font-size: 13px;
			color: #646970;
			margin-top: 6px;
			transition: color 0.3s ease;
		}
		.l3-resena-char-counter--warning {
			color: #dba617;
			font-weight: 600;
		}
		.l3-resena-char-counter--exceeded {
			color: #d63638;
			font-weight: 700;
		}

		/* ── Columnas del listado admin ── */
		.l3-col-stars {
			white-space: nowrap;
			font-size: 15px;
		}
		.l3-col-star-numeric {
			font-size: 13px;
			font-weight: 600;
			color: #646970;
			margin-left: 6px;
		}
		.l3-col-star--filled {
			color: #d4a843;
		}
		.l3-col-star--empty {
			color: #ccc;
		}
		.l3-col-contenido {
			color: #50575e;
			font-style: italic;
		}
		.l3-col-empty {
			color: #ccc;
		}
		
		/* Miniatura de avatar en listado */
		.l3-list-avatar-img {
			width: 36px;
			height: 36px;
			border-radius: 50%;
			object-fit: cover;
			border: 1px solid #d0d1d5;
			background: #f0f0f1;
			display: block;
		}

		/* Badges de origen en listado */
		.l3-badge-col {
			display: inline-flex;
			align-items: center;
			gap: 4px;
			padding: 3px 8px;
			border-radius: 3px;
			font-size: 11px;
			font-weight: 600;
		}
		.l3-badge-col--linkedin {
			background: #e1f0fe;
			color: #0a66c2;
		}
		.l3-badge-col--manual {
			background: #f0f0f1;
			color: #50575e;
		}
		.l3-badge-col .dashicons {
			font-size: 14px;
			width: 14px;
			height: 14px;
		}

		/* Enlaces sociales en listado */
		.l3-col-social-link {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			width: 28px;
			height: 28px;
			border-radius: 4px;
			text-decoration: none;
			color: #fff !important;
		}
		.l3-social-linkedin { background-color: #0a66c2; }
		.l3-social-linkedin:hover { background-color: #004182; }
		.l3-social-instagram { background-color: #e1306c; }
		.l3-social-instagram:hover { background-color: #b3104e; }
		.l3-social-facebook { background-color: #1877f2; }
		.l3-social-facebook:hover { background-color: #0d52b3; }

		.l3-col-linkedin-auth {
			color: #00a32a;
			font-weight: 700;
			font-size: 14px;
			margin-left: 4px;
			vertical-align: middle;
		}

		/* Ancho de columnas */
		.column-l3_foto {
			width: 50px;
		}
		.column-l3_rating {
			width: 110px;
		}
		.column-l3_origen {
			width: 110px;
		}
		.column-l3_social {
			width: 90px;
		}
		.column-l3_destacada {
			width: 90px;
			text-align: center;
		}
	</style>
	<?php
}
add_action('admin_head', 'l3_resenas_admin_styles');

/**
 * 8. Encolado de Scripts y Estilos Frontend de Reseñas.
 */
function l3_resenas_frontend_scripts(): void
{
	// Encolar de forma global en el frontend, pero de forma muy ligera.
	// El JS solo actuará si encuentra el contenedor "#l3-resenas-form-container".
	if (!is_admin()) {
		wp_enqueue_style(
			'l3-resenas-frontend',
			get_stylesheet_directory_uri() . '/assets/css/resenas-frontend.css',
			array(),
			filemtime(get_stylesheet_directory() . '/assets/css/resenas-frontend.css')
		);
		wp_enqueue_script(
			'l3-resenas-frontend',
			get_stylesheet_directory_uri() . '/assets/js/resenas-frontend.js',
			array('jquery'),
			filemtime(get_stylesheet_directory() . '/assets/js/resenas-frontend.js'),
			true
		);

		// Pasar variables de AJAX de WordPress al script de JS de forma segura
		wp_localize_script('l3-resenas-frontend', 'l3_resenas_params', array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'nonce'    => wp_create_nonce('l3_resena_submit_nonce'),
			'default_avatar' => get_avatar_url(0, array('size' => 120)),
			'linkedin_auth_url' => l3_get_linkedin_auth_url()
		));
	}
}
add_action('wp_enqueue_scripts', 'l3_resenas_frontend_scripts');

/**
 * 9. AJAX Handler: Procesar el envío de reseñas desde el frontend.
 */
function l3_submit_resena_ajax_handler(): void
{
	// 1. Verificar Nonce de seguridad
	if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'l3_resena_submit_nonce')) {
		wp_send_json_error(array('message' => 'Error de seguridad. Por favor, recarga la página e intenta de nuevo.'));
	}

	// 2. Rate Limiting básico (Evitar spam usando transientes)
	$user_ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
	$transient_key = 'l3_resena_limit_' . md5($user_ip);
	if (get_transient($transient_key)) {
		// wp_send_json_error(array('message' => 'Has enviado una reseña recientemente. Por favor, espera 10 minutos antes de enviar otra.'));
	}

	// 3. Obtener y sanear campos obligatorios
	$nombre = isset($_POST['nombre']) ? sanitize_text_field($_POST['nombre']) : '';
	$contenido = isset($_POST['contenido']) ? sanitize_textarea_field($_POST['contenido']) : '';
	$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
	$via_linkedin = isset($_POST['via_linkedin']) && $_POST['via_linkedin'] === '1' ? '1' : '0';

	if (empty($nombre)) {
		wp_send_json_error(array('message' => 'El campo Nombre es obligatorio.'));
	}
	if (empty($contenido)) {
		wp_send_json_error(array('message' => 'El contenido de la reseña es obligatorio.'));
	}

	// Forzar límite estricto de 140 caracteres
	$contenido = mb_substr($contenido, 0, 140);
	$rating = max(0, min(5, $rating)); // Clamp entre 0 y 5

	// Campos adicionales
	$empresa = isset($_POST['empresa']) ? sanitize_text_field($_POST['empresa']) : '';
	$cargo = isset($_POST['cargo']) ? sanitize_text_field($_POST['cargo']) : '';

	// Validación condicional: Si hay empresa, el cargo es obligatorio
	if (!empty($empresa) && empty($cargo)) {
		wp_send_json_error(array('message' => 'Si introduces una Empresa, el campo Cargo es obligatorio.'));
	}

	$foto_url = '';
	$linkedin_url = '';
	$linkedin_auth = '0';
	$red_social_tipo = '';
	$red_social_url = '';

	// 4. Lógica por Flujos
	if ($via_linkedin === '1') {
		// Flujo A (Con LinkedIn)
		$linkedin_url = isset($_POST['linkedin_url']) ? esc_url_raw($_POST['linkedin_url']) : '';
		$linkedin_auth = isset($_POST['linkedin_auth']) && $_POST['linkedin_auth'] === '1' ? '1' : '0';
		$foto_url = isset($_POST['foto_url']) ? esc_url_raw($_POST['foto_url']) : '';

		if (empty($linkedin_url)) {
			wp_send_json_error(array('message' => 'La URL del perfil de LinkedIn es obligatoria en el flujo verificado.'));
		}
	} else {
		// Flujo B (Manual - Sin LinkedIn)
		$red_social_tipo = isset($_POST['red_social_tipo']) ? sanitize_text_field($_POST['red_social_tipo']) : '';
		$red_social_url = isset($_POST['red_social_url']) ? esc_url_raw($_POST['red_social_url']) : '';

		// Procesar Foto de Perfil si se subió un archivo
		if (isset($_FILES['foto_file']) && !empty($_FILES['foto_file']['name'])) {
			// Cargar archivos de soporte de WordPress para subidas
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';

			// Validar tamaño máximo de archivo (4MB)
			$max_size = 4 * 1024 * 1024; // 4 megabytes
			if ($_FILES['foto_file']['size'] > $max_size) {
				wp_send_json_error(array('message' => 'La imagen de perfil no debe superar el tamaño máximo de 4MB.'));
			}

			// Validar tipo de archivo de imagen
			$file_type = wp_check_filetype(basename($_FILES['foto_file']['name']), null);
			$allowed_types = array('jpg', 'jpeg', 'png', 'webp');
			if (!in_array(strtolower($file_type['ext']), $allowed_types)) {
				wp_send_json_error(array('message' => 'Formato de imagen no permitido. Solo se aceptan archivos JPG, PNG y WEBP.'));
			}

			// Subir archivo a la biblioteca de medios de WordPress
			$attachment_id = media_handle_upload('foto_file', 0); // 0 significa desasociado inicialmente
			if (is_wp_error($attachment_id)) {
				wp_send_json_error(array('message' => 'Error al procesar la imagen: ' . $attachment_id->get_error_message()));
			} else {
				$foto_url = wp_get_attachment_url($attachment_id);
			}
		}
	}

	// 5. Crear el Post en el CPT 'l3_resena' en estado 'pending'
	$post_data = array(
		'post_title'   => $nombre,
		'post_content' => '', // Mantenemos el core vacío ya que guardamos en meta fields
		'post_status'  => 'pending',
		'post_type'    => 'l3_resena',
	);

	$post_id = wp_insert_post($post_data);

	if (is_wp_error($post_id) || $post_id === 0) {
		wp_send_json_error(array('message' => 'Hubo un error al guardar tu reseña en la base de datos. Por favor, intenta más tarde.'));
	}

	// 6. Almacenar los metadatos inmutables del usuario de forma segura
	update_post_meta($post_id, '_l3_resena_nombre', $nombre);
	update_post_meta($post_id, '_l3_resena_contenido', $contenido);
	update_post_meta($post_id, '_l3_resena_rating', $rating);
	update_post_meta($post_id, '_l3_resena_via_linkedin', $via_linkedin);
	update_post_meta($post_id, '_l3_resena_empresa', $empresa);
	update_post_meta($post_id, '_l3_resena_cargo', $cargo);
	update_post_meta($post_id, '_l3_resena_foto', $foto_url);

	if ($via_linkedin === '1') {
		update_post_meta($post_id, '_l3_resena_linkedin_url', $linkedin_url);
		update_post_meta($post_id, '_l3_resena_linkedin_auth', $linkedin_auth);
		if (isset($_POST['resena_linkedin_user_token'])) {
			update_post_meta($post_id, '_l3_resena_linkedin_user_token', sanitize_text_field($_POST['resena_linkedin_user_token']));
		}
	} else {
		update_post_meta($post_id, '_l3_resena_red_social_tipo', $red_social_tipo);
		update_post_meta($post_id, '_l3_resena_red_social_url', $red_social_url);
	}

	// Establecer el limitador de spam por IP (10 minutos)
	set_transient($transient_key, true, 10 * MINUTE_IN_SECONDS);

	// 7. Retornar éxito con diseño premium
	wp_send_json_success(array(
		'message' => '¡Tu reseña ha sido enviada con éxito! Será revisada por nuestro equipo antes de ser publicada.',
		'post_id' => $post_id
	));
}
add_action('wp_ajax_nopriv_l3_submit_resena', 'l3_submit_resena_ajax_handler');
add_action('wp_ajax_l3_submit_resena', 'l3_submit_resena_ajax_handler');

/**
 * 10. Lógica de Autenticación de Usuarios con LinkedIn (Flujo OAuth Real Frontend)
 */
function l3_get_linkedin_auth_url() {
	$client_id = get_option('l3_linkedin_client_id');
	if (empty($client_id)) {
		return '#';
	}
	// URL fija para el Callback (Requerimiento de LinkedIn OAuth)
	$redirect_uri = urlencode(home_url('/'));
	$state = wp_create_nonce('l3_linkedin_user_oauth');
	$scope = urlencode('openid profile email w_member_social');
	
	return "https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id={$client_id}&redirect_uri={$redirect_uri}&state={$state}&scope={$scope}";
}

add_action('wp', 'l3_linkedin_handle_user_callback');
function l3_linkedin_handle_user_callback() {
	if (isset($_GET['code']) && isset($_GET['state']) && !is_admin()) {
		if (wp_verify_nonce($_GET['state'], 'l3_linkedin_user_oauth')) {
			$code = sanitize_text_field($_GET['code']);
			$client_id = get_option('l3_linkedin_client_id');
			$client_secret = get_option('l3_linkedin_client_secret');
			$redirect_uri = home_url('/');
			
			// Intercambiar código por Access Token del usuario
			$response = wp_remote_post('https://www.linkedin.com/oauth/v2/accessToken', array(
				'body' => array(
					'grant_type'    => 'authorization_code',
					'code'          => $code,
					'redirect_uri'  => $redirect_uri,
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
				)
			));
			
			if (is_wp_error($response)) {
				return;
			}
			
			$body = json_decode(wp_remote_retrieve_body($response), true);
			if (isset($body['access_token'])) {
				$user_token = $body['access_token'];
				
				// Obtener perfil mediante OpenID Connect UserInfo
				$profile_response = wp_remote_get('https://api.linkedin.com/v2/userinfo', array(
					'headers' => array(
						'Authorization' => 'Bearer ' . $user_token
					)
				));
				
				if (!is_wp_error($profile_response)) {
					$profile = json_decode(wp_remote_retrieve_body($profile_response), true);
					if (isset($profile['name'])) {
						global $l3_linkedin_user_data;
						$l3_linkedin_user_data = array(
							'name'   => $profile['name'],
							'avatar' => isset($profile['picture']) ? $profile['picture'] : '',
							'url'    => 'https://www.linkedin.com/', // URL base por defecto
							'token'  => $user_token
						);
					}
				}
			}
		}
	}
}

add_action('wp_footer', 'l3_linkedin_inject_user_data_js');
function l3_linkedin_inject_user_data_js() {
	global $l3_linkedin_user_data;
	if (!empty($l3_linkedin_user_data)) {
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			// Inyectar datos en inputs ocultos del formulario
			$('#resena_linkedin_nombre').val(<?php echo wp_json_encode($l3_linkedin_user_data['name']); ?>);
			$('#resena_linkedin_avatar').val(<?php echo wp_json_encode($l3_linkedin_user_data['avatar']); ?>);
			$('#resena_linkedin_url').val(<?php echo wp_json_encode($l3_linkedin_user_data['url']); ?>);
			
			// Previsualizar en la tarjeta interactiva
			$('#l3-card-name').text(<?php echo wp_json_encode($l3_linkedin_user_data['name']); ?>);
			if (<?php echo wp_json_encode($l3_linkedin_user_data['avatar']); ?>) {
				$('#l3-card-avatar').attr('src', <?php echo wp_json_encode($l3_linkedin_user_data['avatar']); ?>);
			}
			$('#l3-card-profile-url').attr('href', <?php echo wp_json_encode($l3_linkedin_user_data['url']); ?>).text(<?php echo wp_json_encode($l3_linkedin_user_data['url']); ?>);
			
			// Ajustar valores del paso y visibilidad
			$('input[name="resena_via_linkedin"]').val('1');
			
			// Cambiar automáticamente al paso del formulario de LinkedIn y abrir el modal choice
			$('#l3-review-choice-modal').addClass('is-visible');
			$('body').addClass('l3-modal-open-lock');
			$('#l3-step-welcome').removeClass('l3-active-step').hide();
			$('#l3-step-linkedin-flow').show().addClass('l3-active-step');
			
			// Añadir campo para pasar el Token de Usuario al AJAX de envío
			$('<input>').attr({
				type: 'hidden',
				id: 'resena_linkedin_user_token',
				name: 'resena_linkedin_user_token',
				value: <?php echo wp_json_encode($l3_linkedin_user_data['token']); ?>
			}).appendTo('#l3-form-linkedin');
		});
		</script>
		<?php
	}
}

/**
 * 11. Registro del Patrón de Reseñas FSE desde el archivo HTML
 */
add_action('init', 'l3_register_formulario_resenas_pattern');
function l3_register_formulario_resenas_pattern(): void {
	$file_path = get_stylesheet_directory() . '/patterns/formulario-resenas.html';
	$content = '';
	if (file_exists($file_path)) {
		$content = file_get_contents($file_path);
		// Eliminar la cabecera PHP para que solo quede el marcado HTML de bloques Gutenberg limpio
		$content = preg_replace('/<\?php.*?\?>/s', '', $content);
	}
	
	register_block_pattern('linea3-legal-child/formulario-resenas', array(
		'title'       => 'Formulario de Registro de Reseñas',
		'description' => 'Formulario interactivo premium de doble flujo para enviar reseñas de clientes.',
		'categories'  => array('antigravity-patterns'),
		'content'     => $content,
	));
}

/**
 * 12. Hook de transiciónd de estado: Detectar aprobación y disparar autopublicación
 */
add_action('transition_post_status', 'l3_resena_status_transition', 10, 3);
function l3_resena_status_transition($new_status, $old_status, $post): void {
	if ($post->post_type !== 'l3_resena') {
		return;
	}

	// Ejecutar únicamente cuando pase de cualquier estado a "Publicado" (aprobación)
	if ($new_status === 'publish' && $old_status !== 'publish') {
		l3_publish_resena_to_linkedin($post->ID);
	}
}

/**
 * 13. Publicación automática a LinkedIn (Personal y Corporativa)
 */
function l3_publish_resena_to_linkedin(int $post_id): void {
	// Prevenir publicaciones duplicadas por guardado concurrente o re-edición
	$already_published = get_post_meta($post_id, '_l3_resena_published_to_linkedin', true);
	if ($already_published === '1') {
		return;
	}
	update_post_meta($post_id, '_l3_resena_published_to_linkedin', '1');

	// Obtener metadatos de la reseña
	$nombre        = get_post_meta($post_id, '_l3_resena_nombre', true);
	$contenido     = get_post_meta($post_id, '_l3_resena_contenido', true);
	$cargo         = get_post_meta($post_id, '_l3_resena_cargo', true);
	$empresa       = get_post_meta($post_id, '_l3_resena_empresa', true);
	$calificacion  = get_post_meta($post_id, '_l3_resena_calificacion', true);
	$via_linkedin  = get_post_meta($post_id, '_l3_resena_via_linkedin', true);
	$linkedin_auth = get_post_meta($post_id, '_l3_resena_linkedin_auth', true);
	$user_token    = get_post_meta($post_id, '_l3_resena_linkedin_user_token', true);

	$logs = array();
	$logs[] = "[" . date('H:i:s') . "] Iniciando motor de publicación para Reseña ID: " . $post_id;

	// Construir mensaje unificado para ambas publicaciones (Corporativa y Personal)
	$calificacion_format = number_format((float)$calificacion, 1, '.', '');
	$company_linkedin_url = get_option('l3_info_linkedin');
	if (empty($company_linkedin_url)) {
		$company_linkedin_url = 'https://www.linkedin.com/company/linea-3-legal';
	}
	$site_url = home_url('/');

	$shared_post_text = "Mi reseña para Linea 3 Estudio Legal es:\n\n\"{$contenido}\"\n\nCalificación: {$calificacion_format}/5.0\n\nLinkedIn: {$company_linkedin_url}\nConoce más en: {$site_url}";

	// ── 1. PUBLICACIÓN CORPORATIVA (Muro de la Empresa) ──
	$org_id    = get_option('l3_linkedin_org_id');
	$org_token = get_option('l3_linkedin_org_token');

	if (!empty($org_id) && !empty($org_token)) {
		$logs[] = "[" . date('H:i:s') . "] Configuración de Organización válida encontrada. ID: " . $org_id;

		$post_text = $shared_post_text;

		$payload = array(
			'author' => 'urn:li:organization:' . trim($org_id),
			'lifecycleState' => 'PUBLISHED',
			'specificContent' => array(
				'com.linkedin.ugc.ShareContent' => array(
					'shareCommentary' => array(
						'text' => $post_text
					),
					'shareMediaCategory' => 'ARTICLE',
					'media' => array(
						array(
							'status' => 'READY',
							'originalUrl' => $site_url,
							'title' => array(
								'text' => get_bloginfo('name')
							)
						)
					)
				)
			),
			'visibility' => array(
				'com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC'
			)
		);

		$response = wp_remote_post('https://api.linkedin.com/v2/ugcPosts', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $org_token,
				'Content-Type'  => 'application/json',
				'X-Restli-Protocol-Version' => '2.0.0'
			),
			'body' => json_encode($payload),
			'timeout' => 15
		));

		if (is_wp_error($response)) {
			$logs[] = "[" . date('H:i:s') . "] ERROR (Organización): " . $response->get_error_message();
		} else {
			$status_code = wp_remote_retrieve_response_code($response);
			$body = wp_remote_retrieve_body($response);
			$logs[] = "[" . date('H:i:s') . "] Respuesta Organización (HTTP {$status_code}): " . esc_html(mb_strimwidth($body, 0, 150, '...'));
		}
	} else {
		$logs[] = "[" . date('H:i:s') . "] Omitiendo publicación en Organización: ID o Token no configurados.";
	}

	// ── 2. PUBLICACIÓN PERSONAL (Muro del Cliente) ──
	if ($via_linkedin === '1' && $linkedin_auth === '1' && !empty($user_token)) {
		$logs[] = "[" . date('H:i:s') . "] Usuario autorizó publicación personal y el token existe.";

		// Recuperar el ID del miembro (sub) dinámicamente mediante el token del usuario
		$profile_response = wp_remote_get('https://api.linkedin.com/v2/userinfo', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $user_token
			),
			'timeout' => 15
		));

		if (is_wp_error($profile_response)) {
			$logs[] = "[" . date('H:i:s') . "] ERROR al recuperar ID de miembro: " . $profile_response->get_error_message();
		} else {
			$profile_status = wp_remote_retrieve_response_code($profile_response);
			if ($profile_status === 200) {
				$profile_data = json_decode(wp_remote_retrieve_body($profile_response), true);
				$member_id    = $profile_data['sub'] ?? '';

				if (!empty($member_id)) {
					$logs[] = "[" . date('H:i:s') . "] ID de Miembro recuperado con éxito: " . $member_id;

					// Utilizar el mensaje unificado
					$user_post_text = $shared_post_text;

					$user_payload = array(
						'author' => 'urn:li:person:' . $member_id,
						'lifecycleState' => 'PUBLISHED',
						'specificContent' => array(
							'com.linkedin.ugc.ShareContent' => array(
								'shareCommentary' => array(
									'text' => $user_post_text
								),
								'shareMediaCategory' => 'ARTICLE',
								'media' => array(
									array(
										'status' => 'READY',
										'originalUrl' => $site_url,
										'title' => array(
											'text' => get_bloginfo('name')
										)
									)
								)
							)
						),
						'visibility' => array(
							'com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC'
						)
					);

					$user_publish_response = wp_remote_post('https://api.linkedin.com/v2/ugcPosts', array(
						'headers' => array(
							'Authorization' => 'Bearer ' . $user_token,
							'Content-Type'  => 'application/json',
							'X-Restli-Protocol-Version' => '2.0.0'
						),
						'body' => json_encode($user_payload),
						'timeout' => 15
					));

					if (is_wp_error($user_publish_response)) {
						$logs[] = "[" . date('H:i:s') . "] ERROR (Perfil Personal): " . $user_publish_response->get_error_message();
					} else {
						$user_status_code = wp_remote_retrieve_response_code($user_publish_response);
						$user_body = wp_remote_retrieve_body($user_publish_response);
						$logs[] = "[" . date('H:i:s') . "] Respuesta Perfil Personal (HTTP {$user_status_code}): " . esc_html(mb_strimwidth($user_body, 0, 150, '...'));
					}
				} else {
					$logs[] = "[" . date('H:i:s') . "] ERROR: No se encontró el campo 'sub' en la respuesta del perfil.";
				}
			} else {
				$logs[] = "[" . date('H:i:s') . "] ERROR (HTTP {$profile_status}) al consultar perfil de usuario.";
			}
		}
	} else {
		$logs[] = "[" . date('H:i:s') . "] Omitiendo publicación personal: No autenticado vía OAuth o no autorizó.";
	}

	$logs[] = "[" . date('H:i:s') . "] Motor de publicación finalizado.";

	// Guardar el historial de ejecución para auditoría del administrador
}

/**
 * 14. Forzar el color de fondo exacto del header (#0a2233) dinámicamente vía PHP
 * Esto evita problemas de caché de archivos estáticos (Nginx sendfile/Docker sync)
 */
add_action('wp_head', function(): void {
	?>
	<style id="l3-header-background-override">
	.header-main-container {
		background-color: #0a2233 !important;
	}
	</style>
	<?php
}, 999);

/**
 * 15. Shortcode para mostrar el Slider de Testimonios/Reseñas de Clientes.
 */
function l3_reviews_slider_shortcode($atts): string
{
	// 1. Obtener hasta 3 reseñas destacadas
	$featured_args = array(
		'post_type'      => 'l3_resena',
		'posts_per_page' => 3,
		'post_status'    => 'publish',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => array(
			array(
				'key'     => '_l3_resena_destacada',
				'value'   => '1',
				'compare' => '='
			)
		)
	);
	$featured_query = new WP_Query($featured_args);
	$featured_posts = $featured_query->posts;

	// Obtener IDs de las destacadas para excluirlas de la siguiente consulta
	$featured_ids = array();
	foreach ($featured_posts as $fp) {
		$featured_ids[] = $fp->ID;
	}

	// 2. Obtener hasta 9 reseñas recientes (que no sean las destacadas)
	$recent_args = array(
		'post_type'      => 'l3_resena',
		'posts_per_page' => 9,
		'post_status'    => 'publish',
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	if (!empty($featured_ids)) {
		$recent_args['post__not_in'] = $featured_ids;
	}
	
	$recent_query = new WP_Query($recent_args);
	$recent_posts = $recent_query->posts;

	// 3. Combinar ambos arreglos (Total máximo: 12)
	$final_posts = array_merge($featured_posts, $recent_posts);
	$total_reviews = count($final_posts);
	
	$slider_id = 'l3-reviews-slider-' . uniqid();
	$output = '';

	$output .= '<div class="l3-reviews-slider-container" id="' . $slider_id . '" data-total-reviews="' . $total_reviews . '">';

	if ($total_reviews === 0) {
		// Estado Vacío: 3 Tarjetas (Esqueleto - Invitación - Esqueleto)
		$output .= '<div class="l3-reviews-slider-viewport">';
		$output .= '<div class="l3-reviews-slider-track">';
		
		// Ghost card izquierdo
		$output .= '<div class="l3-review-card l3-ghost-card" id="l3-ghost-left" data-text="Excelente servicio legal y profesional. Me brindaron un gran apoyo corporativo para mi empresa Corporación Alpha.">';
		$output .= '<div class="l3-review-rating-header" style="margin-bottom: 18px;">';
		$output .= '<span class="l3-review-rating-score l3-ghost-rating-score">5.0</span>';
		$output .= '<div class="l3-review-stars-wrapper" style="display: flex; flex-direction: column; padding-top: 3px;"><div class="l3-review-stars l3-stars-perfect l3-ghost-stars" style="margin-bottom: 2px !important;">';
		for($i=0; $i<5; $i++) {
			$output .= '<svg viewBox="0 0 24 24"><path d="M12 .587l3.668 7.431 8.2 1.191-5.934 5.787 1.4 8.168L12 18.896l-7.334 3.857 1.4-8.168L.132 9.209l8.2-1.191L12 .587z"/></svg>';
		}
		$output .= '</div><div class="l3-review-rating-label l3-ghost-stars" style="margin-bottom: 0 !important;">Excelente servicio</div></div></div>';
		$output .= '<div class="l3-review-quote"><span class="l3-ghost-quote-text"></span><span class="l3-ghost-cursor"></span></div>';
		$output .= '<div class="l3-review-author l3-ghost-author-wrapper" style="margin-top: auto;">';
		$output .= '<img class="l3-review-avatar" src="' . get_stylesheet_directory_uri() . '/assets/images/avatar-juan.jpg" alt="Avatar" loading="lazy">';
		$output .= '<div class="l3-review-meta"><div class="l3-review-name-row"><span class="l3-review-name">Juan C Jiménez G</span><span class="l3-review-linkedin-badge"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></span></div>';
		$output .= '<span class="l3-review-title">Director Jurídico en Corporación Alpha</span>';
		$output .= '<span class="l3-review-date">23 mayo, 2026</span></div></div>';
		$output .= '</div>';

		// Tarjeta central de invitación
		$output .= '<div class="l3-review-card l3-invitation-card">';
		$output .= '<div class="l3-empty-review-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></div>';
		$output .= '<p class="l3-empty-review-text">Su perspectiva es fundamental para nuestra excelencia. Le invitamos a compartir su experiencia trabajando junto a Línea 3 Estudio Legal.</p>';
		$output .= '<div class="l3-review-cta-wrap" style="margin-top: 24px; text-align: center;">';
		$output .= '<button id="l3-open-review-modal" class="l3-review-cta-btn">DEJAR MI RESEÑA</button>';
		$output .= '</div>';
		$output .= '</div>';

		// Ghost card derecho
		$output .= '<div class="l3-review-card l3-ghost-card" id="l3-ghost-right" data-text="La atención al detalle y el profundo conocimiento en derecho corporativo marcaron la diferencia. Totalmente recomendados para procesos complejos.">';
		$output .= '<div class="l3-review-rating-header" style="margin-bottom: 18px;">';
		$output .= '<span class="l3-review-rating-score l3-ghost-rating-score">5.0</span>';
		$output .= '<div class="l3-review-stars-wrapper" style="display: flex; flex-direction: column; padding-top: 3px;"><div class="l3-review-stars l3-stars-perfect l3-ghost-stars" style="margin-bottom: 2px !important;">';
		for($i=0; $i<5; $i++) {
			$output .= '<svg viewBox="0 0 24 24"><path d="M12 .587l3.668 7.431 8.2 1.191-5.934 5.787 1.4 8.168L12 18.896l-7.334 3.857 1.4-8.168L.132 9.209l8.2-1.191L12 .587z"/></svg>';
		}
		$output .= '</div><div class="l3-review-rating-label l3-ghost-stars" style="margin-bottom: 0 !important;">Excelente servicio</div></div></div>';
		$output .= '<div class="l3-review-quote"><span class="l3-ghost-quote-text"></span><span class="l3-ghost-cursor"></span></div>';
		$output .= '<div class="l3-review-author l3-ghost-author-wrapper" style="margin-top: auto;">';
		$output .= '<img class="l3-review-avatar" src="' . get_stylesheet_directory_uri() . '/assets/images/avatar-eva.jpg" alt="Avatar" loading="lazy">';
		$output .= '<div class="l3-review-meta"><div class="l3-review-name-row"><span class="l3-review-name">Eva Sofía Gutiérrez</span><span class="l3-review-linkedin-badge"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></span></div>';
		$output .= '<span class="l3-review-title">CEO en BETA CORP</span>';
		$output .= '<span class="l3-review-date">24 mayo, 2026</span></div></div>';
		$output .= '</div>';

		$output .= '</div>'; // End track
		$output .= '</div>'; // End viewport

		// JavaScript para orquestar la animación Ghost
		$output .= '<script>
		document.addEventListener("DOMContentLoaded", function() {
			const leftCard = document.getElementById("l3-ghost-left");
			const rightCard = document.getElementById("l3-ghost-right");
			if (!leftCard || !rightCard) return;

			function typeText(element, text, speed, callback) {
				let i = 0;
				element.innerHTML = "";
				function typeNext() {
					if (i < text.length) {
						element.innerHTML += text.charAt(i);
						i++;
						setTimeout(typeNext, speed);
					} else {
						if (callback) callback();
					}
				}
				typeNext();
			}

			function animateCard(card, callback) {
				const score = card.querySelector(".l3-ghost-rating-score");
				const stars = card.querySelectorAll(".l3-ghost-stars");
				const quoteText = card.querySelector(".l3-ghost-quote-text");
				const cursor = card.querySelector(".l3-ghost-cursor");
				const author = card.querySelector(".l3-ghost-author-wrapper");
				const text = card.getAttribute("data-text");

				// Reset state
				score.classList.remove("l3-ghost-element-visible");
				stars.forEach(s => s.classList.remove("l3-ghost-element-visible"));
				quoteText.innerHTML = "";
				quoteText.classList.add("l3-ghost-element-visible");
				cursor.classList.add("is-typing");
				cursor.style.display = "inline-block";
				author.classList.remove("l3-ghost-element-visible");

				// Start sequence
				setTimeout(() => {
					score.classList.add("l3-ghost-element-visible");
					setTimeout(() => {
						stars.forEach(s => s.classList.add("l3-ghost-element-visible"));
						setTimeout(() => {
							typeText(quoteText, text, 35, () => {
								cursor.classList.remove("is-typing");
								setTimeout(() => {
									author.classList.add("l3-ghost-element-visible");
									setTimeout(callback, 4000); // Wait 4s reading time before next
								}, 600);
							});
						}, 600);
					}, 400);
				}, 600);
			}

			function runLoop() {
				animateCard(leftCard, () => {
					// Hide left cursor when right starts typing
					const leftCursor = leftCard.querySelector(".l3-ghost-cursor");
					leftCursor.style.display = "none";
					
					animateCard(rightCard, () => {
						const rightCursor = rightCard.querySelector(".l3-ghost-cursor");
						rightCursor.style.display = "none";

						// Restart loop
						setTimeout(() => {
							runLoop();
						}, 500);
					});
				});
			}

			// Initial start
			runLoop();
		});
		</script>';
	} else {
		// Botón anterior (solo si hay más de 3 reseñas o items en total)
		if ($total_reviews + 1 > 3) {
			$output .= '<button class="l3-slider-btn prev" aria-label="Anterior"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg></button>';
		}
		
		$output .= '<div class="l3-reviews-slider-viewport">';
	    $output .= '<div class="l3-reviews-slider-track">';
	
	global $post;
	foreach ($final_posts as $post) {
		setup_postdata($post);
		$post_id = $post->ID;
		
		// Obtener campos de la reseña
		$nombre        = get_post_meta($post_id, '_l3_resena_nombre', true);
		$contenido     = get_post_meta($post_id, '_l3_resena_contenido', true);
		$rating        = intval(get_post_meta($post_id, '_l3_resena_rating', true));
		$via_linkedin    = get_post_meta($post_id, '_l3_resena_via_linkedin', true);
		$empresa         = get_post_meta($post_id, '_l3_resena_empresa', true);
		$cargo           = get_post_meta($post_id, '_l3_resena_cargo', true);
		$foto_url        = get_post_meta($post_id, '_l3_resena_foto', true);
		$linkedin_url    = get_post_meta($post_id, '_l3_resena_linkedin_url', true);
		$red_social_tipo = get_post_meta($post_id, '_l3_resena_red_social_tipo', true);
		$red_social_url  = get_post_meta($post_id, '_l3_resena_red_social_url', true);
		
		// Fallbacks
		if (empty($nombre)) {
			$nombre = get_the_title();
		}
		if (empty($contenido)) {
			$contenido = get_the_content();
		}
		// Limitar contenido a un tamaño sensato si es muy largo, para mantener homogeneidad
		if (mb_strlen($contenido) > 180) {
			$contenido = mb_substr($contenido, 0, 177) . '...';
		}
		if ($rating < 0 || $rating > 5) {
			$rating = 0;
		}
		if (empty($foto_url)) {
			$foto_url = 'https://secure.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=150&d=mm&r=g';
		}
		if (empty($cargo)) {
			$cargo = 'Cliente';
		}
		
		$output .= '<div class="l3-review-card">';
		
		// Header de Calificación (Puntaje + Estrellas/Etiqueta)
		$output .= '<div class="l3-review-rating-header" style="display: flex; align-items: flex-start; margin-bottom: 18px;">';
		$formatted_rating = number_format((float)$rating, 1, '.', '');
		$output .= '<span class="l3-review-rating-score">' . esc_html($formatted_rating) . '</span>';
		
		$output .= '<div class="l3-review-stars-wrapper" style="display: flex; flex-direction: column; padding-top: 3px;">';
		$stars_class = ($rating >= 5) ? 'l3-review-stars l3-stars-perfect' : 'l3-review-stars';
		$output .= '<div class="' . $stars_class . '" style="margin-bottom: 2px !important;">';
		for ($i = 0; $i < 5; $i++) {
			if ($i < $rating) {
				// Estrella rellena
				$output .= '<svg viewBox="0 0 24 24"><path d="M12 .587l3.668 7.431 8.2 1.191-5.934 5.787 1.4 8.168L12 18.896l-7.334 3.857 1.4-8.168L.132 9.209l8.2-1.191L12 .587z"/></svg>';
			} else {
				// Estrella vacía
				$output .= '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
			}
		}
		$output .= '</div>';
		
		// Etiqueta de texto de la calificación
		$rating_labels = array(
			1 => 'Muy insatisfecho',
			2 => 'Insatisfecho',
			3 => 'Satisfecho',
			4 => 'Muy satisfecho',
			5 => 'Excelente servicio'
		);
		$rating_label_text = isset($rating_labels[$rating]) ? $rating_labels[$rating] : '';
		if (!empty($rating_label_text)) {
			$output .= '<div class="l3-review-rating-label" style="margin-bottom: 0 !important;">' . esc_html($rating_label_text) . '</div>';
		}
		$output .= '</div>'; // End l3-review-stars-wrapper
		$output .= '</div>'; // End l3-review-rating-header
		
		// Cita de opinión
		$output .= '<div class="l3-review-quote">';
		$output .= esc_html($contenido);
		$output .= '</div>';
		
		// Autor e información profesional
		$output .= '<div class="l3-review-author">';
		$output .= '<img class="l3-review-avatar" src="' . esc_url($foto_url) . '" alt="' . esc_attr($nombre) . '" loading="lazy">';
		
		$output .= '<div class="l3-review-meta">';
		
		// Nombre + Insignia de LinkedIn
		$output .= '<div class="l3-review-name-row">';
		$output .= '<span class="l3-review-name">' . esc_html($nombre) . '</span>';
		
		$social_type = '';
		$social_link = '';
		if ($via_linkedin) {
			$social_type = 'linkedin';
			$social_link = $linkedin_url;
		} elseif (!empty($red_social_tipo)) {
			$social_type = strtolower($red_social_tipo);
			$social_link = $red_social_url;
		}

		if (!empty($social_type)) {
			if (!empty($social_link)) {
				$output .= '<a href="' . esc_url($social_link) . '" target="_blank" rel="noopener noreferrer" class="l3-review-linkedin-badge" aria-label="Perfil de ' . esc_attr(ucfirst($social_type)) . ' de ' . esc_attr($nombre) . '">';
			} else {
				$output .= '<span class="l3-review-linkedin-badge">';
			}
			
			if ($social_type === 'linkedin') {
				$output .= '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>';
			} elseif ($social_type === 'facebook') {
				$output .= '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>';
			} elseif ($social_type === 'instagram') {
				$output .= '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>';
			}
			
			if (!empty($social_link)) {
				$output .= '</a>';
			} else {
				$output .= '</span>';
			}
		}
		
		$output .= '</div>'; // End name row
		
		// Cargo + Empresa
		$title_display = esc_html($cargo);
		if (!empty($empresa)) {
			$title_display .= ' en ' . esc_html($empresa);
		}
		$output .= '<span class="l3-review-title">' . $title_display . '</span>';
		
		// Fecha de la reseña
		$post_date = get_the_date('j F, Y', $post_id);
		$output .= '<span class="l3-review-date">' . esc_html($post_date) . '</span>';
		
		$output .= '</div>'; // End meta
		$output .= '</div>'; // End author
		
		$output .= '</div>'; // End card
	}
	wp_reset_postdata();
	
	// Añadir siempre la tarjeta de invitación como el último elemento del track
	$output .= '<div class="l3-review-card l3-invitation-card">';
	$output .= '<div class="l3-empty-review-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></div>';
	$output .= '<p class="l3-empty-review-text">Su perspectiva es fundamental para nuestra excelencia. Le invitamos a compartir su experiencia trabajando junto a Línea 3 Estudio Legal.</p>';
	$output .= '<div class="l3-review-cta-wrap" style="margin-top: 24px; text-align: center;">';
	$output .= '<button id="l3-open-review-modal" class="l3-review-cta-btn">DEJAR MI RESEÑA</button>';
	$output .= '</div>';
	$output .= '</div>';

	// Si solo hay 1 reseña real, la fila queda coja (Reseña + Invitación = 2). 
	// Inyectamos 1 tarjeta fantasma animada para completar el diseño perfecto de 3 columnas.
	if ($total_reviews === 1) {
		$output .= '<div class="l3-review-card l3-ghost-card" id="l3-ghost-fill" data-text="La atención al detalle y el profundo conocimiento en derecho corporativo marcaron la diferencia. Totalmente recomendados para procesos complejos.">';
		$output .= '<div class="l3-review-rating-header" style="margin-bottom: 18px;">';
		$output .= '<span class="l3-review-rating-score l3-ghost-rating-score">5.0</span>';
		$output .= '<div class="l3-review-stars-wrapper" style="display: flex; flex-direction: column; padding-top: 3px;"><div class="l3-review-stars l3-stars-perfect l3-ghost-stars" style="margin-bottom: 2px !important;">';
		for($i=0; $i<5; $i++) {
			$output .= '<svg viewBox="0 0 24 24"><path d="M12 .587l3.668 7.431 8.2 1.191-5.934 5.787 1.4 8.168L12 18.896l-7.334 3.857 1.4-8.168L.132 9.209l8.2-1.191L12 .587z"/></svg>';
		}
		$output .= '</div><div class="l3-review-rating-label l3-ghost-stars" style="margin-bottom: 0 !important;">Excelente servicio</div></div></div>';
		$output .= '<div class="l3-review-quote"><span class="l3-ghost-quote-text"></span><span class="l3-ghost-cursor"></span></div>';
		$output .= '<div class="l3-review-author l3-ghost-author-wrapper" style="margin-top: auto;">';
		$output .= '<img class="l3-review-avatar" src="' . get_stylesheet_directory_uri() . '/assets/images/avatar-eva.jpg" alt="Avatar" loading="lazy">';
		$output .= '<div class="l3-review-meta"><div class="l3-review-name-row"><span class="l3-review-name">Eva Sofía Gutiérrez</span><span class="l3-review-linkedin-badge"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></span></div>';
		$output .= '<span class="l3-review-title">CEO en BETA CORP</span>';
		$output .= '<span class="l3-review-date">24 mayo, 2026</span></div></div>';
		$output .= '</div>';
        
		$output .= '<script>
		document.addEventListener("DOMContentLoaded", function() {
			const ghostFill = document.getElementById("l3-ghost-fill");
			if (!ghostFill) return;

			function typeText(element, text, speed, callback) {
				let i = 0;
				element.innerHTML = "";
				function typeNext() {
					if (i < text.length) {
						element.innerHTML += text.charAt(i);
						i++;
						setTimeout(typeNext, speed);
					} else {
						if (callback) callback();
					}
				}
				typeNext();
			}

			function animateCard(card, callback) {
				const score = card.querySelector(".l3-ghost-rating-score");
				const stars = card.querySelectorAll(".l3-ghost-stars");
				const quoteText = card.querySelector(".l3-ghost-quote-text");
				const cursor = card.querySelector(".l3-ghost-cursor");
				const author = card.querySelector(".l3-ghost-author-wrapper");
				const text = card.getAttribute("data-text");

				score.classList.remove("l3-ghost-element-visible");
				stars.forEach(s => s.classList.remove("l3-ghost-element-visible"));
				quoteText.innerHTML = "";
				quoteText.classList.add("l3-ghost-element-visible");
				cursor.classList.add("is-typing");
				cursor.style.display = "inline-block";
				author.classList.remove("l3-ghost-element-visible");

				setTimeout(() => {
					score.classList.add("l3-ghost-element-visible");
					setTimeout(() => {
						stars.forEach(s => s.classList.add("l3-ghost-element-visible"));
						setTimeout(() => {
							typeText(quoteText, text, 35, () => {
								cursor.classList.remove("is-typing");
								setTimeout(() => {
									author.classList.add("l3-ghost-element-visible");
									setTimeout(callback, 4000);
								}, 600);
							});
						}, 600);
					}, 400);
				}, 600);
			}

			function runLoop() {
				animateCard(ghostFill, () => {
					const fillCursor = ghostFill.querySelector(".l3-ghost-cursor");
					fillCursor.style.display = "none";
					setTimeout(() => {
						runLoop();
					}, 1000);
				});
			}

			runLoop();
		});
		</script>';
	}

	$output .= '</div>'; // End track
	$output .= '</div>'; // End viewport
	
	
		// Botón siguiente (solo si hay más de 3 reseñas o items en total)
		if ($total_reviews + 1 > 3) {
			$output .= '<button class="l3-slider-btn next" aria-label="Siguiente"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg></button>';
		}
	} // Fin del else (total_reviews > 0)
		
	$output .= '</div>'; // End container

	// Modal de Selección de Flujo (Se imprime siempre)
	$output .= '
	<div id="l3-review-choice-modal" class="l3-custom-modal-overlay">
		<div class="l3-custom-modal-box">
			<div class="l3-custom-modal-header">
				<button type="button" class="l3-custom-modal-close" id="l3-close-choice-modal">&times;</button>
				<h3>Escribir una Reseña</h3>
				<p>Comparte tu testimonio profesional con nosotros. Tu experiencia ayuda a respaldar el prestigio de nuestra firma.</p>
			</div>
			<div class="l3-custom-modal-body">
				<div id="l3-resenas-form-container" class="l3-resenas-container" style="padding: 0; box-shadow: none; border: none; background: transparent; margin: 0; max-width: 100%; overflow: visible;">
					
					<!-- Paso 0: Selección Inicial de Flujo -->
					<div id="l3-step-welcome" class="l3-resenas-step l3-active-step">
						<div class="l3-resenas-welcome" style="padding: 0; border: none; background: transparent; box-shadow: none;">
							<h4 style="font-size: 1.15rem; margin-top: 0; margin-bottom: 12px; font-weight: 600;">¿Cómo deseas registrar tu reseña?</h4>
							<p style="margin-bottom: 24px; font-size: 14px; line-height: 1.5;">
								Te recomendamos conectarte vía <strong>LinkedIn</strong> para verificar tu perfil al instante. Alternativamente, puedes registrar tus datos manualmente.
							</p>
							
							<div class="l3-custom-modal-buttons" style="display: flex; flex-direction: column; gap: 12px; width: 100%; box-sizing: border-box;">
								<button type="button" id="l3-trigger-linkedin" class="l3-custom-btn-flow l3-custom-btn-flow--linkedin" style="cursor: pointer; font-size: 14px; display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%;">
									<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg> Conectar con mi LinkedIn
								</button>
								
								<button type="button" id="l3-trigger-manual" class="l3-custom-btn-flow l3-custom-btn-flow--manual" style="cursor: pointer; font-size: 14px; display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%;">
									<span class="dashicons dashicons-edit"></span> Registro Manual
								</button>
							</div>
						</div>
					</div>

					<!-- Inputs de control ocultos globales -->
					<input type="hidden" name="resena_rating" value="0">
					<input type="hidden" name="resena_via_linkedin" value="0">

					<!-- Paso 1A: Formulario Flujo LinkedIn (Verificado) -->
					<div id="l3-step-linkedin-flow" class="l3-resenas-step" style="display: none;">
						<form id="l3-form-linkedin" class="l3-resenas-form" method="post" enctype="multipart/form-data">
							
							<!-- Tarjeta Perfil Verificado de LinkedIn -->
							<div class="l3-linkedin-card">
								<img id="l3-card-avatar" class="l3-linkedin-avatar" src="" alt="avatar">
								<div class="l3-linkedin-info">
									<div class="l3-linkedin-name">
										<span id="l3-card-name">Nombre</span>
										<span class="l3-linkedin-verified-badge" title="Perfil verificado con OAuth">✓</span>
									</div>
									<a id="l3-card-profile-url" class="l3-linkedin-profile-url" href="" target="_blank" rel="noopener noreferrer">perfil</a>
								</div>
							</div>

							<!-- Inputs ocultos de perfil recuperados -->
							<input type="hidden" id="resena_linkedin_nombre" name="nombre" value="">
							<input type="hidden" id="resena_linkedin_avatar" name="foto_url" value="">

							<!-- Campo: URL del perfil de LinkedIn -->
							<div class="l3-form-group">
								<label for="resena_linkedin_url">Confirma tu perfil LinkedIn <span style="color: #ef4444;">*</span></label>
								<input type="text" id="resena_linkedin_url" name="linkedin_url" placeholder="linkedin.com/in/tu-perfil" required class="l3-resena-input">
							</div>

							<!-- Fila: Empresa / Cargo -->
							<div class="l3-form-grid-2">
								<div class="l3-form-group">
									<label for="resena_empresa_a">Empresa <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Opcional)</span></label>
									<input type="text" id="resena_empresa_a" name="empresa" placeholder="Ej: Línea 3 Legal">
								</div>
								<div class="l3-form-group">
									<label for="resena_cargo_a">Cargo <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Obligatorio si introduces empresa)</span></label>
									<input type="text" id="resena_cargo_a" name="cargo" placeholder="Ej: Director Jurídico">
								</div>
							</div>

							<!-- Campo: Calificación por estrellas -->
							<div class="l3-form-group">
								<label>Tu Calificación</label>
								<div class="l3-star-rating-wrapper" style="position: relative; display: inline-flex; align-items: center; gap: 12px; margin-top: 4px;">
									<div class="l3-star-rating-container" style="position: relative; display: inline-block; width: max-content;">
										<!-- Capa base de estrellas (vacías) -->
										<div class="l3-stars-empty" style="display: flex; gap: 4px; color: rgba(255, 255, 255, 0.2);">
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
										</div>
										<!-- Capa superpuesta de estrellas (doradas) -->
										<div class="l3-stars-filled" style="display: flex; gap: 4px; position: absolute; top: 0; left: 0; overflow: hidden; width: 0%; color: #ce9e50; pointer-events: none;">
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
										</div>
										<!-- Input range para controlar la calificación decimal -->
										<input type="range" class="l3-rating-range" min="0" max="5" step="0.1" value="0" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; margin: 0;">
									</div>
									<span class="l3-stars-text">Sin calificación</span>
								</div>
							</div>

							<!-- Campo: Reseña (Máx 240) -->
							<div class="l3-form-group">
								<label for="resena_contenido_a">Tu Reseña <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Máximo 240 caracteres)</span></label>
								<div class="l3-textarea-wrapper">
									<textarea id="resena_contenido_a" name="contenido" rows="3" placeholder="Describe tu experiencia con nosotros..." maxlength="240" class="l3-resena-textarea"></textarea>
									<div class="l3-char-counter"><span>0</span> / 240</div>
								</div>
							</div>

							<!-- Checkbox: Autorizo a publicar en LinkedIn -->
							<div class="l3-form-group l3-form-group--checkbox">
								<label for="resena_linkedin_auth">
									<input type="checkbox" id="resena_linkedin_auth" name="linkedin_auth" value="1" checked>
									<span>Autorizo a publicar esta recomendación en mi perfil personal de LinkedIn una vez sea validada por el administrador.</span>
								</label>
							</div>

							<!-- Footer del Formulario -->
							<div class="l3-form-footer">
								<button type="button" class="l3-btn l3-btn-back">
									<span class="dashicons dashicons-arrow-left-alt2"></span> Volver
								</button>
								<button type="submit" class="l3-btn l3-btn-submit">
									<span>Enviar Reseña</span>
									<span class="l3-btn-spinner"></span>
								</button>
							</div>

						</form>
					</div>

					<!-- Paso 1B: Formulario Flujo Manual (Sin LinkedIn) -->
					<div id="l3-step-manual-flow" class="l3-resenas-step" style="display: none;">
						<form id="l3-form-manual" class="l3-resenas-form" method="post" enctype="multipart/form-data">
							
							<!-- Fila: Nombre Completo -->
							<div class="l3-form-group">
								<label for="resena_nombre_b">Nombre Completo <span style="color: #ef4444;">*</span></label>
								<input type="text" id="resena_nombre_b" name="nombre" placeholder="Ej: Carlos Rodríguez" required>
							</div>

							<!-- Fila: Empresa / Cargo -->
							<div class="l3-form-grid-2">
								<div class="l3-form-group">
									<label for="resena_empresa_b">Empresa <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Opcional)</span></label>
									<input type="text" id="resena_empresa_b" name="empresa" placeholder="Ej: Cardenas Labs">
								</div>
								<div class="l3-form-group">
									<label for="resena_cargo_b">Cargo <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Obligatorio si introduces empresa)</span></label>
									<input type="text" id="resena_cargo_b" name="cargo" placeholder="Ej: CEO">
								</div>
							</div>

							<!-- Zona de Carga: Drag & Drop Foto de Perfil -->
							<div class="l3-form-group">
								<label>Foto de Perfil <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Opcional - Máx 4MB)</span></label>
								<div id="l3-upload-zone" class="l3-upload-zone">
									<span class="dashicons dashicons-admin-media l3-upload-icon"></span>
									<div class="l3-upload-text">
										Arrastra tu imagen aquí o <strong>selecciona un archivo</strong>
									</div>
									<input type="file" id="resena_foto_file" name="foto_file" class="l3-file-input" accept="image/jpeg,image/png,image/webp">
								</div>
								
								<!-- Previsualizador de Imagen Subida -->
								<div id="l3-avatar-preview-wrap" class="l3-avatar-upload-preview" style="display: none;">
									<img src="" alt="previsualización">
									<span>archivo.jpg</span>
								</div>
							</div>

							<!-- Fila: Tipo de Red Social y URL vinculada -->
							<div class="l3-form-grid-2">
								<div class="l3-form-group">
									<label for="resena_red_social_tipo">Red Social Vinculada <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Opcional)</span></label>
									<select id="resena_red_social_tipo" name="red_social_tipo">
										<option value="">Ninguna</option>
										<option value="linkedin">LinkedIn</option>
										<option value="instagram">Instagram</option>
										<option value="facebook">Facebook</option>
									</select>
								</div>
								<div class="l3-form-group">
									<label for="resena_red_social_url">Enlace al Perfil de Red Social</label>
									<input type="url" id="resena_red_social_url" name="red_social_url" placeholder="https://instagram.com/tu_perfil">
								</div>
							</div>

							<!-- Campo: Calificación por estrellas -->
							<div class="l3-form-group">
								<label>Tu Calificación</label>
								<div class="l3-star-rating-wrapper" style="position: relative; display: inline-flex; align-items: center; gap: 12px; margin-top: 4px;">
									<div class="l3-star-rating-container" style="position: relative; display: inline-block; width: max-content;">
										<!-- Capa base de estrellas (vacías) -->
										<div class="l3-stars-empty" style="display: flex; gap: 4px; color: rgba(255, 255, 255, 0.2);">
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
										</div>
										<!-- Capa superpuesta de estrellas (doradas) -->
										<div class="l3-stars-filled" style="display: flex; gap: 4px; position: absolute; top: 0; left: 0; overflow: hidden; width: 0%; color: #ce9e50; pointer-events: none;">
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
											<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
										</div>
										<!-- Input range para controlar la calificación decimal -->
										<input type="range" class="l3-rating-range" min="0" max="5" step="0.1" value="0" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; margin: 0;">
									</div>
									<span class="l3-stars-text">Sin calificación</span>
								</div>
							</div>

							<!-- Campo: Reseña (Máx 240) -->
							<div class="l3-form-group">
								<label for="resena_contenido_b">Tu Reseña <span style="font-weight: normal; color: var(--l3-text-muted); font-size: 12px;">(Máximo 240 caracteres)</span></label>
								<div class="l3-textarea-wrapper">
									<textarea id="resena_contenido_b" name="contenido" rows="3" placeholder="Describe tu experiencia con nosotros..." maxlength="240" class="l3-resena-textarea"></textarea>
									<div class="l3-char-counter"><span>0</span> / 240</div>
								</div>
							</div>

							<!-- Footer del Formulario -->
							<div class="l3-form-footer">
								<button type="button" class="l3-btn l3-btn-back">
									<span class="dashicons dashicons-arrow-left-alt2"></span> Volver
								</button>
								<button type="submit" class="l3-btn l3-btn-submit">
									<span>Enviar Reseña</span>
									<span class="l3-btn-spinner"></span>
								</button>
							</div>

						</form>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- Modal de Conexión Real LinkedIn OAuth -->
	<div id="l3-linkedin-modal" class="l3-linkedin-modal-overlay">
		<div class="l3-linkedin-modal">
			<div class="l3-linkedin-modal-header">
				<h4>Conectar con tu cuenta</h4>
				<button type="button" class="l3-linkedin-close" aria-label="Cerrar">&times;</button>
			</div>
			<div class="l3-linkedin-modal-body" style="text-align: center; padding: 24px;">
				<span class="dashicons dashicons-linkedin l3-linkedin-modal-logo" style="font-size: 48px; width: 48px; height: 48px; color: #0077b5; margin-bottom: 15px; display: inline-block;"></span>
				<h3 style="font-size: 18px; margin: 0 0 10px 0; color: var(--l3-blue-dark); font-weight: 600;">Verificación con LinkedIn</h3>
				<p style="font-size: 14px; color: var(--l3-text-muted); line-height: 1.6; margin-bottom: 24px;">
					Para garantizar la autenticidad de tu reseña, inicia sesión con tu perfil verificado de LinkedIn. Únicamente leeremos tu nombre de perfil y foto de perfil.
				</p>
				<div class="l3-linkedin-connect-btn-wrapper">
					<a href="#" id="l3-real-linkedin-btn" class="l3-btn-flow l3-btn-flow--linkedin" style="display: inline-flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; width: 100%; box-sizing: border-box; background: #0077b5; color: #fff; border-radius: 4px; padding: 12px; font-weight: 500; transition: background 0.2s;">
						<span class="dashicons dashicons-linkedin" style="margin-top: 1px;"></span>
						Iniciar sesión con LinkedIn
					</a>
				</div>
			</div>
		</div>
	</div>';

	// JavaScript para el Slider y la Ventana Emergente de Testimonios
	$output .= "
	<script>
	document.addEventListener('DOMContentLoaded', function() {
		
		// Slider Logic
		(function(){
			const container = document.getElementById('" . $slider_id . "');
			if (!container) return;

			const track = container.querySelector('.l3-reviews-slider-track');
		const viewport = container.querySelector('.l3-reviews-slider-viewport');
		const btnPrev = container.querySelector('.l3-slider-btn.prev');
		const btnNext = container.querySelector('.l3-slider-btn.next');
		
		let index = 0;
		let autoplayInterval;
		const totalReviews = parseInt(container.getAttribute('data-total-reviews')) || 0;

		function getVisibleCards() {
			const cards = container.querySelectorAll('.l3-review-card');
			if (cards.length === 0) return 1;
			const cardWidth = cards[0].offsetWidth + 20; // 20 is gap
			return Math.max(1, Math.round(viewport.offsetWidth / cardWidth));
		}

		function updateSlider() {
			const cards = container.querySelectorAll('.l3-review-card');
			if (cards.length === 0) return;
			const cardWidth = cards[0].offsetWidth + 20;
			const maxIndex = cards.length - getVisibleCards();
			
			if (index > maxIndex) index = 0;
			if (index < 0) index = maxIndex > 0 ? maxIndex : 0;

			const offset = index * cardWidth;
			track.style.transform = 'translateX(-' + offset + 'px)';
		}

		function nextSlide() {
			index++;
			updateSlider();
		}

		function prevSlide() {
			index--;
			updateSlider();
		}

		function startAutoplay() {
			stopAutoplay();
			if (totalReviews + 1 > 3) {
				autoplayInterval = setInterval(nextSlide, 5000);
			}
		}

		function stopAutoplay() {
			if (autoplayInterval) clearInterval(autoplayInterval);
		}

		if (btnNext) {
			btnNext.addEventListener('click', () => {
				nextSlide();
				startAutoplay();
			});
		}

		if (btnPrev) {
			btnPrev.addEventListener('click', () => {
				prevSlide();
				startAutoplay();
			});
		}

		// Hover triggers to pause/play autoplay
		container.addEventListener('mouseenter', stopAutoplay);
		container.addEventListener('mouseleave', startAutoplay);

		// Touch swipe events for mobile devices
		let touchStartX = 0;
		viewport.addEventListener('touchstart', (e) => {
			touchStartX = e.touches[0].clientX;
			stopAutoplay();
		}, { passive: true });

		viewport.addEventListener('touchend', (e) => {
			const touchEndX = e.changedTouches[0].clientX;
			if (touchStartX - touchEndX > 50) nextSlide();
			if (touchStartX - touchEndX < -50) prevSlide();
			startAutoplay();
		}, { passive: true });

		window.addEventListener('resize', updateSlider);
		
		// Initial setup
		setTimeout(updateSlider, 200);
		startAutoplay();
		
	})();
	
		// Lógica del modal de selección (Fuera del bloque del slider)
		const openBtn = document.getElementById('l3-open-review-modal');
		const closeBtn = document.getElementById('l3-close-choice-modal');
		const modalOverlay = document.getElementById('l3-review-choice-modal');

		if (openBtn) {
			if (modalOverlay) {
				openBtn.addEventListener('click', function(e) {
					e.preventDefault();
					modalOverlay.classList.add('is-visible');
					document.body.classList.add('l3-modal-open-lock');
				});
			}
		}

		if (closeBtn) {
			if (modalOverlay) {
				closeBtn.addEventListener('click', function(e) {
					e.preventDefault();
					modalOverlay.classList.remove('is-visible');
					document.body.classList.remove('l3-modal-open-lock');
				});
			}
		}

		if (modalOverlay) {
			modalOverlay.addEventListener('click', function(e) {
				if (e.target === modalOverlay) {
					document.body.classList.remove('l3-modal-open-lock');
				}
			});
		}
	});
	</script>";

	return $output;
}
add_shortcode('antigravity_reviews_slider', 'l3_reviews_slider_shortcode');

/**
 * 18. Personalizar el pie de página del panel de administración (Quitar mensajes de WordPress)
 */
add_filter('admin_footer_text', '__return_empty_string');
add_filter('update_footer', '__return_empty_string', 11);
